/// <reference types="react" />
import { r as __name } from "./rolldown-runtime-DnkiqaRY.js";
import { JSX as JSX$1 } from "react/jsx-runtime";
import ReactExports, { AriaRole, ButtonHTMLAttributes, CSSProperties, Component, ComponentType, DOMAttributes, DependencyList, DetailedHTMLProps, EffectCallback, ErrorInfo, FC, FunctionComponent, HTMLAttributes, JSX as JSX$2, MouseEvent as MouseEvent$1, PropsWithChildren, Provider, ReactNode, RefObject, SVGAttributes, SVGProps, WheelEvent, useEffect, useLayoutEffect } from "react";
import { BBox, ComputedNodeStyle, EdgeId, ElementShape, ExclusiveUnion, Fqn, MarkdownOrString, NodeId, ProjectId, ViewId } from "@likec4/core";
import { BBox as BBox$1 } from "@likec4/core/geometry";
import { LikeC4Styles as LikeC4Styles$1 } from "@likec4/core/styles";
import * as t from "@likec4/core/types";
import { Any, AutoLayoutDirection, BBox as BBox$2, Color, ComputedNodeStyle as ComputedNodeStyle$1, DeploymentFqn, DiagramEdge, DiagramNode, DiagramNodeDriftReason, DiagramView, DynamicViewDisplayVariant, DynamicViewFlow, EdgeId as EdgeId$1, ElementKind, ElementShape as ElementShape$1, ElementShape as ElementShape$2, ElementStyle, ExclusiveUnion as ExclusiveUnion$1, Fqn as Fqn$1, IconUrl, LayoutType, LayoutedView, MarkdownOrString as MarkdownOrString$1, NodeId as NodeId$1, NodeNotation, NonEmptyArray, NonEmptyReadonlyArray, ProjectId as ProjectId$1, RelationId, RelationshipArrowType, RelationshipLineType, RichTextOrEmpty, StepPath, UnknownLayouted, ViewChange, ViewId as ViewId$1, WhereOperator, WhereOperator as WhereOperator$1, aux } from "@likec4/core/types";
import { LikeC4Model, LikeC4ViewModel, NodeModel } from "@likec4/core/model";
import { LayoutedProjectsView } from "@likec4/core/compute-view";
import { ZoomTransform } from "d3-zoom";
import { CamelCasedProperties, Except, NonEmptyObject, OptionalKeysOf, PartialDeep, SetRequired, Simplify, SimplifyDeep } from "type-fest";
//#region ../../node_modules/.pnpm/@xyflow+system@0.0.83/node_modules/@xyflow/system/dist/esm/types/changes.d.ts
type NodeDimensionChange = {
  id: string;
  type: 'dimensions';
  dimensions?: Dimensions;
  resizing?: boolean;
  setAttributes?: boolean | 'width' | 'height';
};
type NodePositionChange = {
  id: string;
  type: 'position';
  position?: XYPosition;
  positionAbsolute?: XYPosition;
  dragging?: boolean;
};
type NodeSelectionChange = {
  id: string;
  type: 'select';
  selected: boolean;
};
type NodeRemoveChange = {
  id: string;
  type: 'remove';
};
type NodeAddChange<NodeType extends NodeBase = NodeBase> = {
  item: NodeType;
  type: 'add';
  index?: number;
};
type NodeReplaceChange<NodeType extends NodeBase = NodeBase> = {
  id: string;
  item: NodeType;
  type: 'replace';
};
/**
 * The [`onNodesChange`](/api-reference/react-flow#on-nodes-change) callback takes
 *an array of `NodeChange` objects that you should use to update your flow's state.
 *The `NodeChange` type is a union of six different object types that represent that
 *various ways an node can change in a flow.
 * @public
 */
type NodeChange<NodeType extends NodeBase = NodeBase> = NodeDimensionChange | NodePositionChange | NodeSelectionChange | NodeRemoveChange | NodeAddChange<NodeType> | NodeReplaceChange<NodeType>;
type EdgeSelectionChange = NodeSelectionChange;
type EdgeRemoveChange = NodeRemoveChange;
type EdgeAddChange<EdgeType extends EdgeBase = EdgeBase> = {
  item: EdgeType;
  type: 'add';
  index?: number;
};
type EdgeReplaceChange<EdgeType extends EdgeBase = EdgeBase> = {
  id: string;
  item: EdgeType;
  type: 'replace';
};
/**
 * The [`onEdgesChange`](/api-reference/react-flow#on-edges-change) callback takes
 *an array of `EdgeChange` objects that you should use to update your flow's state.
 *The `EdgeChange` type is a union of four different object types that represent that
 *various ways an edge can change in a flow.
 *
 * @public
 */
type EdgeChange<EdgeType extends EdgeBase = EdgeBase> = EdgeSelectionChange | EdgeRemoveChange | EdgeAddChange<EdgeType> | EdgeReplaceChange<EdgeType>;
//#endregion
//#region ../../node_modules/.pnpm/@xyflow+system@0.0.83/node_modules/@xyflow/system/dist/esm/types/utils.d.ts
/**
 * While [`PanelPosition`](/api-reference/types/panel-position) can be used to place a
 * component in the corners of a container, the `Position` enum is less precise and used
 * primarily in relation to edges and handles.
 *
 * @public
 */
declare enum Position {
  Left = "left",
  Top = "top",
  Right = "right",
  Bottom = "bottom"
}
/**
 * All positions are stored in an object with x and y coordinates.
 *
 * @public
 */
type XYPosition = {
  x: number;
  y: number;
};
type Dimensions = {
  width: number;
  height: number;
};
type Rect = Dimensions & XYPosition;
type Transform = [number, number, number];
/**
 * A coordinate extent represents two points in a coordinate system: one in the top
 * left corner and one in the bottom right corner. It is used to represent the
 * bounds of nodes in the flow or the bounds of the viewport.
 *
 * @public
 *
 * @remarks Props that expect a `CoordinateExtent` usually default to `[[-∞, -∞], [+∞, +∞]]`
 * to represent an unbounded extent.
 */
type CoordinateExtent = [[number, number], [number, number]];
//#endregion
//#region ../../node_modules/.pnpm/@xyflow+system@0.0.83/node_modules/@xyflow/system/dist/esm/utils/types.d.ts
type Optional<T, K extends keyof T> = Pick<Partial<T>, K> & Omit<T, K>;
//#endregion
//#region ../../node_modules/.pnpm/@xyflow+system@0.0.83/node_modules/@xyflow/system/dist/esm/types/nodes.d.ts
/**
 * Framework independent node data structure.
 *
 * @inline
 * @typeParam NodeData - type of the node data
 * @typeParam NodeType - type of the node
 */
type NodeBase<NodeData extends Record<string, unknown> = Record<string, unknown>, NodeType extends string | undefined = string | undefined> = {
  /** Unique id of a node. */
  id: string;
  /**
   * Position of a node on the pane.
   * @example { x: 0, y: 0 }
   */
  position: XYPosition;
  /** Arbitrary data passed to a node. */
  data: NodeData;
  /**
   * Only relevant for default, source, target nodeType. Controls source position.
   * @example 'right', 'left', 'top', 'bottom'
   */
  sourcePosition?: Position;
  /**
   * Only relevant for default, source, target nodeType. Controls target position.
   * @example 'right', 'left', 'top', 'bottom'
   */
  targetPosition?: Position;
  /** Whether or not the node should be visible on the canvas. */
  hidden?: boolean;
  selected?: boolean;
  /** Whether or not the node is currently being dragged. */
  dragging?: boolean;
  /** Whether or not the node is able to be dragged. */
  draggable?: boolean;
  selectable?: boolean;
  connectable?: boolean;
  deletable?: boolean;
  /**
   * A class name that can be applied to elements inside the node that allows those elements to act
   * as drag handles, letting the user drag the node by clicking and dragging on those elements.
   */
  dragHandle?: string;
  width?: number;
  height?: number;
  initialWidth?: number;
  initialHeight?: number;
  /** Parent node id, used for creating sub-flows. */
  parentId?: string;
  zIndex?: number;
  /**
   * Boundary a node can be moved in.
   * @example 'parent' or [[0, 0], [100, 100]]
   */
  extent?: 'parent' | CoordinateExtent | null;
  /**
   * When `true`, the parent node will automatically expand if this node is dragged to the edge of
   * the parent node's bounds.
   */
  expandParent?: boolean;
  ariaLabel?: string;
  /**
   * Origin of the node relative to its position.
   * @example
   * [0.5, 0.5] // centers the node
   * [0, 0] // top left
   * [1, 1] // bottom right
   */
  origin?: NodeOrigin;
  handles?: NodeHandle[];
  measured?: {
    width?: number;
    height?: number;
  };
} & (undefined extends NodeType ? {
  /** Type of node defined in nodeTypes */
  type?: string | undefined;
} : {
  /** Type of node defined in nodeTypes */
  type: NodeType;
});
type InternalNodeBase<NodeType extends NodeBase = NodeBase> = Omit<NodeType, 'measured'> & {
  measured: {
    width?: number;
    height?: number;
  };
  internals: {
    positionAbsolute: XYPosition;
    z: number;
    rootParentIndex?: number;
    /**
     * Holds a reference to the original node object provided by the user.
     * Used as an optimization to avoid certain operations.
     */
    userNode: NodeType;
    handleBounds?: NodeHandleBounds;
    bounds?: NodeBounds;
  };
};
/**
 * The node data structure that gets used for the custom nodes props.
 *
 * @public
 */
type NodeProps$2<NodeType extends NodeBase> = Pick<NodeType, 'id' | 'data' | 'width' | 'height' | 'sourcePosition' | 'targetPosition' | 'dragHandle' | 'parentId'> & Required<Pick<NodeType, 'type' | 'dragging' | 'zIndex' | 'selectable' | 'deletable' | 'selected' | 'draggable'>> & {
  /** Whether a node is connectable or not. */
  isConnectable: boolean;
  /** Position absolute x value. */
  positionAbsoluteX: number;
  /** Position absolute y value. */
  positionAbsoluteY: number;
};
type NodeHandleBounds = {
  source: Handle[] | null;
  target: Handle[] | null;
};
type InternalNodeUpdate = {
  id: string;
  nodeElement: HTMLDivElement;
  force?: boolean;
};
type NodeBounds = XYPosition & {
  width: number | null;
  height: number | null;
};
type NodeDragItem = {
  id: string;
  position: XYPosition;
  distance: XYPosition;
  measured: {
    width: number;
    height: number;
  };
  internals: {
    positionAbsolute: XYPosition;
  };
} & Pick<InternalNodeBase, 'extent' | 'parentId' | 'origin' | 'expandParent' | 'dragging'>;
/**
 * The origin of a Node determines how it is placed relative to its own coordinates.
 * `[0, 0]` places it at the top left corner, `[0.5, 0.5]` right in the center and
 * `[1, 1]` at the bottom right of its position.
 *
 * @public
 */
type NodeOrigin = [number, number];
type OnSelectionDrag<NodeType extends NodeBase = NodeBase> = (event: MouseEvent, nodes: NodeType[]) => void;
/**
 * Type for the handles of a node
 *
 * @public
 */
type NodeHandle = Omit<Optional<Handle, 'width' | 'height'>, 'nodeId'>;
type Align = 'center' | 'start' | 'end';
type NodeLookup<NodeType extends InternalNodeBase = InternalNodeBase> = Map<string, NodeType>;
type ParentLookup<NodeType extends InternalNodeBase = InternalNodeBase> = Map<string, Map<string, NodeType>>;
//#endregion
//#region ../../node_modules/.pnpm/@xyflow+system@0.0.83/node_modules/@xyflow/system/dist/esm/types/handles.d.ts
/**
 * @inline
 */
type HandleType = 'source' | 'target';
type Handle = {
  id?: string | null;
  nodeId: string;
  x: number;
  y: number;
  position: Position;
  type: HandleType;
  width: number;
  height: number;
};
//#endregion
//#region ../../node_modules/.pnpm/@xyflow+system@0.0.83/node_modules/@xyflow/system/dist/esm/types/panzoom.d.ts
type OnTransformChange = (transform: Transform) => void;
type PanZoomTransformOptions = {
  duration?: number;
  ease?: (t: number) => number;
  interpolate?: 'smooth' | 'linear';
};
type PanZoomUpdateOptions = {
  noWheelClassName: string;
  noPanClassName: string;
  onPaneContextMenu?: (event: MouseEvent) => void;
  preventScrolling: boolean;
  panActivationKeyPressed?: boolean;
  panOnScroll: boolean;
  panOnDrag: boolean | number[];
  panOnScrollMode: PanOnScrollMode;
  panOnScrollSpeed: number;
  userSelectionActive: boolean;
  zoomOnPinch: boolean;
  zoomOnScroll: boolean;
  zoomOnDoubleClick: boolean;
  zoomActivationKeyPressed: boolean;
  lib: string;
  onTransformChange: OnTransformChange;
  connectionInProgress: boolean;
  paneClickDistance: number;
  selectionOnDrag?: boolean;
};
type PanZoomInstance = {
  update: (params: PanZoomUpdateOptions) => void;
  destroy: () => void;
  getViewport: () => Viewport;
  setViewport: (viewport: Viewport, options?: PanZoomTransformOptions) => Promise<ZoomTransform | undefined>;
  setViewportConstrained: (viewport: Viewport, extent: CoordinateExtent, translateExtent: CoordinateExtent) => Promise<ZoomTransform | undefined>;
  setScaleExtent: (scaleExtent: [number, number]) => void;
  setTranslateExtent: (translateExtent: CoordinateExtent) => void;
  scaleTo: (scale: number, options?: PanZoomTransformOptions) => Promise<boolean>;
  scaleBy: (factor: number, options?: PanZoomTransformOptions) => Promise<boolean>;
  syncViewport: (viewport: Viewport) => void;
  setClickDistance: (distance: number) => void;
};
//#endregion
//#region ../../node_modules/.pnpm/@xyflow+system@0.0.83/node_modules/@xyflow/system/dist/esm/types/general.d.ts
/**
 * This type is used to define the `onMove` handler.
 */
type OnMove = (event: MouseEvent | TouchEvent | null, viewport: Viewport) => void;
type OnMoveStart = OnMove;
type OnMoveEnd = OnMove;
/**
 * @inline
 */
type ZoomInOut = (options?: ViewportHelperFunctionOptions) => Promise<boolean>;
/**
 * @inline
 */
type ZoomTo = (zoomLevel: number, options?: ViewportHelperFunctionOptions) => Promise<boolean>;
/**
 * @inline
 */
type GetZoom = () => number;
/**
 * @inline
 */
type GetViewport = () => Viewport;
/**
 * The `SetViewport` function is used to set the viewport of the flow.
 *
 * @inline
 * @param viewport - The viewport to set.
 * @param options - Optional parameters to control the animation and easing of the viewport change.
 */
type SetViewport = (viewport: Viewport, options?: ViewportHelperFunctionOptions) => Promise<boolean>;
/**
 * The `SetCenter` function is used to set the center of the flow viewport to a specific position
 *
 * @inline
 * @param x - x coordinate
 * @param y - y coordinate
 * @param options - Optional parameters to control the animation and easing of the viewport change.
 */
type SetCenter = (x: number, y: number, options?: SetCenterOptions) => Promise<boolean>;
/**
 * The `FitBounds` function is used to fit the flow viewport to the bounds of the nodes.
 *
 * @inline
 * @param bounds - The bounds to fit the viewport to.
 * @param options - Optional parameters to control the animation and easing of the viewport change.
 */
type FitBounds = (bounds: Rect, options?: FitBoundsOptions) => Promise<boolean>;
/**
 * The `Connection` type is the basic minimal description of an [`Edge`](/api-reference/types/edge)
 * between two nodes. The [`addEdge`](/api-reference/utils/add-edge) util can be used to upgrade
 * a `Connection` to an [`Edge`](/api-reference/types/edge).
 *
 * @public
 */
type Connection = {
  /** The id of the node this connection originates from. */
  source: string;
  /** The id of the node this connection terminates at. */
  target: string;
  /** When not `null`, the id of the handle on the source node that this connection originates from. */
  sourceHandle: string | null;
  /** When not `null`, the id of the handle on the target node that this connection terminates at. */
  targetHandle: string | null;
};
/**
 * The `HandleConnection` type is an extension of a basic [Connection](/api-reference/types/connection) that includes the `edgeId`.
 */
type HandleConnection = Connection & {
  edgeId: string;
};
/**
 * The `NodeConnection` type is an extension of a basic [Connection](/api-reference/types/connection) that includes the `edgeId`.
 *
 */
type NodeConnection = Connection & {
  edgeId: string;
};
/**
 * The `ConnectionMode` is used to set the mode of connection between nodes.
 * The `Strict` mode is the default one and only allows source to target edges.
 * `Loose` mode allows source to source and target to target edges as well.
 *
 * @public
 */
declare enum ConnectionMode {
  Strict = "strict",
  Loose = "loose"
}
type OnConnectStartParams = {
  nodeId: string | null;
  handleId: string | null;
  handleType: HandleType | null;
};
type OnConnectStart = (event: MouseEvent | TouchEvent, params: OnConnectStartParams) => void;
type OnConnect = (connection: Connection) => void;
type OnConnectEnd<NodeType extends NodeBase = NodeBase> = (event: MouseEvent | TouchEvent, connectionState: FinalConnectionState<InternalNodeBase<NodeType>>) => void;
type OnReconnect<EdgeType extends EdgeBase = EdgeBase> = (oldEdge: EdgeType, newConnection: Connection) => void;
type PaddingUnit$1 = 'px' | '%';
type PaddingWithUnit$1 = `${number}${PaddingUnit$1}` | number;
type Padding = PaddingWithUnit$1 | {
  top?: PaddingWithUnit$1;
  right?: PaddingWithUnit$1;
  bottom?: PaddingWithUnit$1;
  left?: PaddingWithUnit$1;
  x?: PaddingWithUnit$1;
  y?: PaddingWithUnit$1;
};
/**
 * @inline
 */
type FitViewOptionsBase<NodeType extends NodeBase = NodeBase> = {
  padding?: Padding;
  includeHiddenNodes?: boolean;
  minZoom?: number;
  maxZoom?: number;
  duration?: number;
  ease?: (t: number) => number;
  interpolate?: 'smooth' | 'linear';
  nodes?: (NodeType | {
    id: string;
  })[];
};
/**
 * Internally, React Flow maintains a coordinate system that is independent of the
 * rest of the page. The `Viewport` type tells you where in that system your flow
 * is currently being display at and how zoomed in or out it is.
 *
 * @public
 * @remarks A `Transform` has the same properties as the viewport, but they represent
 * different things. Make sure you don't get them muddled up or things will start
 * to look weird!
 *
 */
type Viewport = {
  x: number;
  y: number;
  zoom: number;
};
type KeyCode = string | Array<string>;
type SnapGrid = [number, number];
/**
 * This enum is used to set the different modes of panning the viewport when the
 * user scrolls. The `Free` mode allows the user to pan in any direction by scrolling
 * with a device like a trackpad. The `Vertical` and `Horizontal` modes restrict
 * scroll panning to only the vertical or horizontal axis, respectively.
 *
 * @public
 */
declare enum PanOnScrollMode {
  Free = "free",
  Vertical = "vertical",
  Horizontal = "horizontal"
}
/**
 * @inline
 */
type ViewportHelperFunctionOptions = {
  duration?: number;
  ease?: (t: number) => number;
  interpolate?: 'smooth' | 'linear';
};
/**
 * @inline
 */
type SetCenterOptions = ViewportHelperFunctionOptions & {
  zoom?: number;
};
/**
 * @inline
 */
type FitBoundsOptions = ViewportHelperFunctionOptions & {
  padding?: number;
};
type OnViewportChange = (viewport: Viewport) => void;
/**
 * This type is mostly used to help position things on top of the flow viewport. For
 * example both the [`<MiniMap />`](/api-reference/components/minimap) and
 * [`<Controls />`](/api-reference/components/controls) components take a `position`
 * prop of this type.
 *
 * @public
 */
type PanelPosition = 'top-left' | 'top-center' | 'top-right' | 'bottom-left' | 'bottom-center' | 'bottom-right' | 'center-left' | 'center-right';
declare enum SelectionMode {
  Partial = "partial",
  Full = "full"
}
type SelectionRect = Rect & {
  startX: number;
  startY: number;
};
type OnError = (id: string, message: string) => void;
type UpdateNodePositions<NodeType extends InternalNodeBase = InternalNodeBase> = (dragItems: Map<string, NodeDragItem | NodeType>, dragging?: boolean) => void;
type PanBy = (delta: XYPosition) => Promise<boolean>;
type NoConnection = {
  inProgress: false;
  isValid: null;
  from: null;
  fromHandle: null;
  fromPosition: null;
  fromNode: null;
  to: null;
  toHandle: null;
  toPosition: null;
  toNode: null;
  pointer: null;
};
type ConnectionInProgress<NodeType extends InternalNodeBase = InternalNodeBase> = {
  /** Indicates whether a connection is currently in progress. */
  inProgress: true;
  /**
   * If an ongoing connection is above a handle or inside the connection radius, this will be `true`
   * or `false`, otherwise `null`.
   */
  isValid: boolean | null;
  /** Returns the xy start position or `null` if no connection is in progress. */
  from: XYPosition;
  /** Returns the start handle or `null` if no connection is in progress. */
  fromHandle: Handle;
  /** Returns the side (called position) of the start handle or `null` if no connection is in progress. */
  fromPosition: Position;
  /** Returns the start node or `null` if no connection is in progress. */
  fromNode: NodeType;
  /** Returns the xy end position or `null` if no connection is in progress. */
  to: XYPosition;
  /** Returns the end handle or `null` if no connection is in progress. */
  toHandle: Handle | null;
  /** Returns the side (called position) of the end handle or `null` if no connection is in progress. */
  toPosition: Position;
  /** Returns the end node or `null` if no connection is in progress. */
  toNode: NodeType | null;
  /** Returns the pointer position or `null` if no connection is in progress. */
  pointer: XYPosition;
};
/**
 * The `ConnectionState` type bundles all information about an ongoing connection.
 * It is returned by the [`useConnection`](/api-reference/hooks/use-connection) hook.
 *
 * @public
 */
type ConnectionState<NodeType extends InternalNodeBase = InternalNodeBase> = ConnectionInProgress<NodeType> | NoConnection;
type FinalConnectionState<NodeType extends InternalNodeBase = InternalNodeBase> = (Omit<ConnectionInProgress<NodeType>, 'inProgress' | 'toPosition'> & {
  toPosition: Position | null;
}) | Omit<NoConnection, 'inProgress'>;
type UpdateConnection<NodeType extends InternalNodeBase = InternalNodeBase> = (params: ConnectionState<NodeType>) => void;
type ColorModeClass = 'light' | 'dark';
type ColorMode = ColorModeClass | 'system';
type ConnectionLookup = Map<string, Map<string, HandleConnection>>;
type OnBeforeDeleteBase<NodeType extends NodeBase = NodeBase, EdgeType extends EdgeBase = EdgeBase> = ({ nodes, edges }: {
  nodes: NodeType[];
  edges: EdgeType[];
}) => Promise<boolean | {
  nodes: NodeType[];
  edges: EdgeType[];
}>;
/**
 * The `ZIndexMode` type is used to define how z-indexing is calculated for nodes and edges.
 * `auto` mode will automatically manage z-indexing for selections and sub flows.
 * `basic` mode will only manage z-indexing for selections.
 * `manual` mode does not apply any automatic z-indexing.
 *
 * @public
 */
type ZIndexMode = 'auto' | 'basic' | 'manual';
//#endregion
//#region ../../node_modules/.pnpm/@xyflow+system@0.0.83/node_modules/@xyflow/system/dist/esm/types/edges.d.ts
type EdgeBase<EdgeData extends Record<string, unknown> = Record<string, unknown>, EdgeType extends string | undefined = string | undefined> = {
  /** Unique id of an edge. */
  id: string;
  /** Type of edge defined in `edgeTypes`. */
  type?: EdgeType;
  /** Id of source node. */
  source: string;
  /** Id of target node. */
  target: string;
  /** Id of source handle, only needed if there are multiple handles per node. */
  sourceHandle?: string | null;
  /** Id of target handle, only needed if there are multiple handles per node. */
  targetHandle?: string | null;
  animated?: boolean;
  hidden?: boolean;
  deletable?: boolean;
  selectable?: boolean;
  /** Arbitrary data passed to an edge. */
  data?: EdgeData;
  selected?: boolean;
  /**
   * Set the marker on the beginning of an edge.
   * @example 'arrow', 'arrowclosed' or custom marker
   */
  markerStart?: EdgeMarkerType;
  /**
   * Set the marker on the end of an edge.
   * @example 'arrow', 'arrowclosed' or custom marker
   */
  markerEnd?: EdgeMarkerType;
  zIndex?: number;
  ariaLabel?: string;
  /**
   * ReactFlow renders an invisible path around each edge to make them easier to click or tap on.
   * This property sets the width of that invisible path.
   */
  interactionWidth?: number;
};
/**
 * @inline
 */
type DefaultEdgeOptionsBase<EdgeType extends EdgeBase> = Omit<EdgeType, 'id' | 'source' | 'target' | 'sourceHandle' | 'targetHandle' | 'selected'>;
/**
 * If you set the `connectionLineType` prop on your [`<ReactFlow />`](/api-reference/react-flow#connection-connectionLineType)
 *component, it will dictate the style of connection line rendered when creating
 *new edges.
 *
 * @public
 *
 * @remarks If you choose to render a custom connection line component, this value will be
 *passed to your component as part of its [`ConnectionLineComponentProps`](/api-reference/types/connection-line-component-props).
 */
declare enum ConnectionLineType {
  Bezier = "default",
  Straight = "straight",
  Step = "step",
  SmoothStep = "smoothstep",
  SimpleBezier = "simplebezier"
}
/**
 * Edges can optionally have markers at the start and end of an edge. The `EdgeMarker`
 *type is used to configure those markers! Check the docs for [`MarkerType`](/api-reference/types/marker-type)
 *for details on what types of edge marker are available.
 *
 * @public
 */
type EdgeMarker = {
  type: MarkerType | `${MarkerType}`;
  color?: string | null;
  width?: number;
  height?: number;
  markerUnits?: string;
  orient?: string;
  strokeWidth?: number;
};
type EdgeMarkerType = string | EdgeMarker;
/**
 * Edges may optionally have a marker on either end. The MarkerType type enumerates
 * the options available to you when configuring a given marker.
 *
 * @public
 */
declare enum MarkerType {
  Arrow = "arrow",
  ArrowClosed = "arrowclosed"
}
/**
 * @inline
 */
type EdgePosition = {
  sourceX: number;
  sourceY: number;
  targetX: number;
  targetY: number;
  sourcePosition: Position;
  targetPosition: Position;
};
type EdgeLookup<EdgeType extends EdgeBase = EdgeBase> = Map<string, EdgeType>;
//#endregion
//#region ../../node_modules/.pnpm/@xyflow+system@0.0.83/node_modules/@xyflow/system/dist/esm/constants.d.ts
declare const defaultAriaLabelConfig: {
  'node.a11yDescription.default': string;
  'node.a11yDescription.keyboardDisabled': string;
  'node.a11yDescription.ariaLiveMessage': ({ direction, x, y }: {
    direction: string;
    x: number;
    y: number;
  }) => string;
  'edge.a11yDescription.default': string;
  'controls.ariaLabel': string;
  'controls.zoomIn.ariaLabel': string;
  'controls.zoomOut.ariaLabel': string;
  'controls.fitView.ariaLabel': string;
  'controls.interactive.ariaLabel': string;
  'minimap.ariaLabel': string;
  'handle.ariaLabel': string;
};
type AriaLabelConfig = typeof defaultAriaLabelConfig;
//#endregion
//#region ../../node_modules/.pnpm/@xyflow+system@0.0.83/node_modules/@xyflow/system/dist/esm/utils/general.d.ts
/**
 * Polyfill for Promise.withResolvers until we can use it in all browsers
 * @internal
 */
declare function withResolvers<T>(): {
  promise: Promise<T>;
  resolve: (value: T | PromiseLike<T>) => void;
  reject: (reason?: unknown) => void;
};
//#endregion
//#region ../../node_modules/.pnpm/@xyflow+react@12.12.0_@types+react-dom@19.3.0_@types+react@19.3.0__@types+react@19.3.0__d76e2522285783b135d2a1abc7fbff33/node_modules/@xyflow/react/dist/esm/types/general.d.ts
/**
 * This type can be used to type the `onNodesChange` function with a custom node type.
 *
 * @public
 *
 * @example
 *
 * ```ts
 * const onNodesChange: OnNodesChange<MyNodeType> = useCallback((changes) => {
 *  setNodes((nodes) => applyNodeChanges(nodes, changes));
 * },[]);
 * ```
 */
type OnNodesChange<NodeType extends Node$1 = Node$1> = (changes: NodeChange<NodeType>[]) => void;
/**
 * This type can be used to type the `onEdgesChange` function with a custom edge type.
 *
 * @public
 *
 * @example
 *
 * ```ts
 * const onEdgesChange: OnEdgesChange<MyEdgeType> = useCallback((changes) => {
 *  setEdges((edges) => applyEdgeChanges(edges, changes));
 * },[]);
 * ```
 */
type OnEdgesChange<EdgeType extends Edge$1 = Edge$1> = (changes: EdgeChange<EdgeType>[]) => void;
type OnNodesDelete<NodeType extends Node$1 = Node$1> = (nodes: NodeType[]) => void;
type OnEdgesDelete<EdgeType extends Edge$1 = Edge$1> = (edges: EdgeType[]) => void;
/**
 * This type can be used to type the `onDelete` function with a custom node and edge type.
 *
 * @public
 */
type OnDelete<NodeType extends Node$1 = Node$1, EdgeType extends Edge$1 = Edge$1> = (params: {
  nodes: NodeType[];
  edges: EdgeType[];
}) => void;
type NodeTypes = Record<string, ComponentType<NodeProps$1 & {
  data: any;
  type: any;
}>>;
type EdgeTypes = Record<string, ComponentType<EdgeProps$1 & {
  data: any;
  type: any;
}>>;
type UnselectNodesAndEdgesParams<NodeType extends Node$1 = Node$1, EdgeType extends Edge$1 = Edge$1> = {
  nodes?: NodeType[];
  edges?: EdgeType[];
};
type OnSelectionChangeParams<NodeType extends Node$1 = Node$1, EdgeType extends Edge$1 = Edge$1> = {
  nodes: NodeType[];
  edges: EdgeType[];
};
type OnSelectionChangeFunc<NodeType extends Node$1 = Node$1, EdgeType extends Edge$1 = Edge$1> = (params: OnSelectionChangeParams<NodeType, EdgeType>) => void;
/**
 * When calling [`fitView`](/api-reference/types/react-flow-instance#fitview) these options
 * can be used to customize the behaviour. For example, the `duration` option can be used to
 * transform the viewport smoothly over a given amount of time.
 *
 * @public
 * @inline
 */
type FitViewOptions<NodeType extends Node$1 = Node$1> = FitViewOptionsBase<NodeType>;
/**
 * @inline
 */
type FitView<NodeType extends Node$1 = Node$1> = (fitViewOptions?: FitViewOptions<NodeType>) => Promise<boolean>;
/**
 * @inline
 */
type OnInit<NodeType extends Node$1 = Node$1, EdgeType extends Edge$1 = Edge$1> = (reactFlowInstance: ReactFlowInstance<NodeType, EdgeType>) => void;
/**
 * @inline
 */
type ViewportHelperFunctions = {
  /**
   * Zooms viewport in by 1.2.
   *
   * @param options.duration - optional duration. If set, a transition will be applied
   */
  zoomIn: ZoomInOut;
  /**
   * Zooms viewport out by 1 / 1.2.
   *
   * @param options.duration - optional duration. If set, a transition will be applied
   */
  zoomOut: ZoomInOut;
  /**
   * Zoom the viewport to a given zoom level. Passing in a `duration` will animate the viewport to
   * the new zoom level.
   *
   * @param zoomLevel - the zoom level to set
   * @param options.duration - optional duration. If set, a transition will be applied
   */
  zoomTo: ZoomTo;
  /**
   * Get the current zoom level of the viewport.
   *
   * @returns current zoom as a number
   */
  getZoom: GetZoom;
  /**
   * Sets the current viewport.
   *
   * @param viewport - the viewport to set
   * @param options.duration - optional duration. If set, a transition will be applied
   * @param options.ease - optional ease function.
   */
  setViewport: SetViewport;
  /**
   * Returns the current viewport.
   *
   * @returns Viewport
   */
  getViewport: GetViewport;
  /**
   * Center the viewport on a given position. Passing in a `duration` will animate the viewport to
   * the new position.
   *
   * @param x - x position
   * @param y - y position
   * @param options.zoom - optional zoom
   * @param options.duration - optional duration. If set, a transition will be applied
   * @param options.ease - optional ease function.
   */
  setCenter: SetCenter;
  /**
   * A low-level utility function to fit the viewport to a given rectangle. By passing in a
   * `duration`, the viewport will animate from its current position to the new position. The
   * `padding` option can be used to add space around the bounds.
   *
   * @param bounds - the bounds ({ x: number, y: number, width: number, height: number }) to fit the view to
   * @param options.padding - optional padding
   * @param options.duration - optional duration. If set, a transition will be applied
   * @param options.ease - optional ease function.
   */
  fitBounds: FitBounds;
  /**
   * With this function you can translate a screen pixel position to a flow position. It is useful
   * for implementing drag and drop from a sidebar for example.
   *
   * @param clientPosition - the screen / client position. When you are working with events you can use event.clientX and event.clientY
   * @param options.snapToGrid - if true, the converted position will be snapped to the grid
   * @returns position as { x: number, y: number }
   *
   * @example
   * const flowPosition = screenToFlowPosition({ x: event.clientX, y: event.clientY })
   */
  screenToFlowPosition: (clientPosition: XYPosition, options?: {
    snapToGrid?: boolean;
    snapGrid?: SnapGrid;
  }) => XYPosition;
  /**
   * Translate a position inside the flow's canvas to a screen pixel position.
   *
   * @param flowPosition - the screen / client position. When you are working with events you can use event.clientX and event.clientY
   * @returns position as { x: number, y: number }
   *
   * @example
   * const clientPosition = flowToScreenPosition({ x: node.position.x, y: node.position.y })
   */
  flowToScreenPosition: (flowPosition: XYPosition) => XYPosition;
};
type OnBeforeDelete<NodeType extends Node$1 = Node$1, EdgeType extends Edge$1 = Edge$1> = OnBeforeDeleteBase<NodeType, EdgeType>;
/**
 *  This type can be used to type the `isValidConnection` function.
 *  If the function returns `true`, the connection is valid and can be created.
 */
type IsValidConnection<EdgeType extends Edge$1 = Edge$1> = (edge: EdgeType | Connection) => boolean;
/**
 * React Flow is independent and entirely funded by its users.
 * If you hide the attribution, please support our work by subscribing to React Flow Pro: https://reactflow.dev/remove-attribution
 * */
type ProOptions = {
  account?: string;
  /** If you hide the attribution, please support our work with a subscription. */
  hideAttribution: boolean;
};
//#endregion
//#region ../../node_modules/.pnpm/@xyflow+react@12.12.0_@types+react-dom@19.3.0_@types+react@19.3.0__@types+react@19.3.0__d76e2522285783b135d2a1abc7fbff33/node_modules/@xyflow/react/dist/esm/types/nodes.d.ts
/**
 * The `Node` type represents everything React Flow needs to know about a given node.
 * Whenever you want to update a certain attribute of a node, you need to create a new
 * node object.
 *
 * @public
 */
type Node$1<NodeData extends Record<string, unknown> = Record<string, unknown>, NodeType extends string | undefined = string | undefined> = NodeBase<NodeData, NodeType> & {
  style?: CSSProperties;
  className?: string;
  resizing?: boolean;
  focusable?: boolean;
  /**
   * The ARIA role attribute for the node element, used for accessibility.
   * @default "group"
   */
  ariaRole?: AriaRole;
  /**
   * General escape hatch for adding custom attributes to the node's DOM element.
   */
  domAttributes?: Omit<HTMLAttributes<HTMLDivElement>, 'id' | 'style' | 'className' | 'draggable' | 'role' | 'aria-label' | 'defaultValue' | 'dangerouslySetInnerHTML' | keyof DOMAttributes<HTMLDivElement>>;
};
/**
 * The `InternalNode` type is identical to the base [`Node`](/api-references/types/node)
 * type but is extended with some additional properties used internally.
 * Some functions and callbacks that return nodes may return an `InternalNode`.
 *
 * @public
 */
type InternalNode<NodeType extends Node$1 = Node$1> = InternalNodeBase<NodeType>;
type NodeMouseHandler<NodeType extends Node$1 = Node$1> = (event: MouseEvent$1, node: NodeType) => void;
type SelectionDragHandler<NodeType extends Node$1 = Node$1> = (event: MouseEvent$1, nodes: NodeType[]) => void;
type OnNodeDrag<NodeType extends Node$1 = Node$1> = (event: MouseEvent | TouchEvent, node: NodeType, nodes: NodeType[]) => void;
/**
 * When you implement a [custom node](/learn/customization/custom-nodes) it is
 * wrapped in a component that enables basic functionality like selection and
 * dragging. Your custom node receives `NodeProps` as props.
 *
 * @public
 * @example
 * ```tsx
 *import { useState } from 'react';
 *import { NodeProps, Node } from '@xyflow/react';
 *
 *export type CounterNode = Node<{ initialCount?: number }, 'counter'>;
 *
 *export default function CounterNode(props: NodeProps<CounterNode>) {
 *  const [count, setCount] = useState(props.data?.initialCount ?? 0);
 *
 *  return (
 *    <div>
 *      <p>Count: {count}</p>
 *      <button className="nodrag" onClick={() => setCount(count + 1)}>
 *        Increment
 *      </button>
 *    </div>
 *  );
 *}
 *```
 */
type NodeProps$1<NodeType extends Node$1 = Node$1> = NodeProps$2<NodeType>;
//#endregion
//#region ../../node_modules/.pnpm/@xyflow+react@12.12.0_@types+react-dom@19.3.0_@types+react@19.3.0__@types+react@19.3.0__d76e2522285783b135d2a1abc7fbff33/node_modules/@xyflow/react/dist/esm/types/edges.d.ts
/**
 * @inline
 */
type EdgeLabelOptions = {
  /**
   * The label or custom element to render along the edge. This is commonly a text label or some
   * custom controls.
   */
  label?: ReactNode;
  /**
   * Custom styles to apply to the label.
   */
  labelStyle?: CSSProperties;
  labelShowBg?: boolean;
  labelBgStyle?: CSSProperties;
  labelBgPadding?: [number, number];
  labelBgBorderRadius?: number;
};
/**
 * An `Edge` is the complete description with everything React Flow needs
 * to know in order to render it.
 * @public
 */
type Edge$1<EdgeData extends Record<string, unknown> = Record<string, unknown>, EdgeType extends string | undefined = string | undefined> = EdgeBase<EdgeData, EdgeType> & EdgeLabelOptions & {
  style?: CSSProperties;
  className?: string;
  /**
   * Determines whether the edge can be updated by dragging the source or target to a new node.
   * This property will override the default set by the `edgesReconnectable` prop on the
   * `<ReactFlow />` component.
   */
  reconnectable?: boolean | HandleType;
  focusable?: boolean;
  /**
   * The ARIA role attribute for the edge, used for accessibility.
   * @default "group"
   */
  ariaRole?: AriaRole;
  /**
   * General escape hatch for adding custom attributes to the edge's DOM element.
   */
  domAttributes?: Omit<SVGAttributes<SVGGElement>, 'id' | 'style' | 'className' | 'role' | 'aria-label' | 'dangerouslySetInnerHTML'>;
};
type EdgeMouseHandler<EdgeType extends Edge$1 = Edge$1> = (event: MouseEvent$1, edge: EdgeType) => void;
/**
 * Many properties on an [`Edge`](/api-reference/types/edge) are optional. When a new edge is created,
 * the properties that are not provided will be filled in with the default values
 * passed to the `defaultEdgeOptions` prop of the [`<ReactFlow />`](/api-reference/react-flow#defaultedgeoptions) component.
 */
type DefaultEdgeOptions = DefaultEdgeOptionsBase<Edge$1>;
/**
 * When you implement a custom edge it is wrapped in a component that enables some
 * basic functionality. The `EdgeProps` type is the props that are passed to this.
 * @public
 * @expand
 */
type EdgeProps$1<EdgeType extends Edge$1 = Edge$1> = Pick<EdgeType, 'id' | 'type' | 'animated' | 'data' | 'style' | 'selected' | 'source' | 'target' | 'selectable' | 'deletable'> & EdgePosition & EdgeLabelOptions & {
  sourceHandleId?: string | null;
  targetHandleId?: string | null;
  markerStart?: string;
  markerEnd?: string;
  pathOptions?: any;
  interactionWidth?: number;
};
/**
 * If you want to render a custom component for connection lines, you can set the
 * `connectionLineComponent` prop on the [`<ReactFlow />`](/api-reference/react-flow#connection-connectionLineComponent)
 * component. The `ConnectionLineComponentProps` are passed to your custom component.
 *
 * @public
 */
type ConnectionLineComponentProps<NodeType extends Node$1 = Node$1> = {
  connectionLineStyle?: CSSProperties;
  connectionLineType: ConnectionLineType;
  /** The node the connection line originates from. */
  fromNode: InternalNode<NodeType>;
  /** The handle on the `fromNode` that the connection line originates from. */
  fromHandle: Handle;
  fromX: number;
  fromY: number;
  toX: number;
  toY: number;
  fromPosition: Position;
  toPosition: Position;
  /**
   * If there is an `isValidConnection` callback, this prop will be set to `"valid"` or `"invalid"`
   * based on the return value of that callback. Otherwise, it will be `null`.
   */
  connectionStatus: 'valid' | 'invalid' | null;
  toNode: InternalNode<NodeType> | null;
  toHandle: Handle | null;
  pointer: XYPosition;
};
type ConnectionLineComponent<NodeType extends Node$1 = Node$1> = ComponentType<ConnectionLineComponentProps<NodeType>>;
//#endregion
//#region ../../node_modules/.pnpm/@xyflow+react@12.12.0_@types+react-dom@19.3.0_@types+react@19.3.0__@types+react@19.3.0__d76e2522285783b135d2a1abc7fbff33/node_modules/@xyflow/react/dist/esm/types/component-props.d.ts
/**
 * ReactFlow component props.
 * @public
 */
interface ReactFlowProps<NodeType extends Node$1 = Node$1, EdgeType extends Edge$1 = Edge$1> extends Omit<HTMLAttributes<HTMLDivElement>, 'onError'> {
  /**
   * An array of nodes to render in a controlled flow.
   * @default []
   * @example
   * const nodes = [
   *  {
   *    id: 'node-1',
   *    type: 'input',
   *    data: { label: 'Node 1' },
   *    position: { x: 250, y: 50 }
   *  }
   * ];
   */
  nodes?: NodeType[];
  /**
   * An array of edges to render in a controlled flow.
   * @default []
   * @example
   * const edges = [
   *  {
   *    id: 'edge-1-2',
   *    source: 'node-1',
   *    target: 'node-2',
   *  }
   * ];
   */
  edges?: EdgeType[];
  /** The initial nodes to render in an uncontrolled flow. */
  defaultNodes?: NodeType[];
  /** The initial edges to render in an uncontrolled flow. */
  defaultEdges?: EdgeType[];
  /**
   * Defaults to be applied to all new edges that are added to the flow.
   * Properties on a new edge will override these defaults if they exist.
   * @example
   * const defaultEdgeOptions = {
   *  type: 'customEdgeType',
   *  animated: true
   * }
   */
  defaultEdgeOptions?: DefaultEdgeOptions;
  /** This event handler is called when a user clicks on a node. */
  onNodeClick?: NodeMouseHandler<NodeType>;
  /** This event handler is called when a user double-clicks on a node. */
  onNodeDoubleClick?: NodeMouseHandler<NodeType>;
  /** This event handler is called when mouse of a user enters a node. */
  onNodeMouseEnter?: NodeMouseHandler<NodeType>;
  /** This event handler is called when mouse of a user moves over a node. */
  onNodeMouseMove?: NodeMouseHandler<NodeType>;
  /** This event handler is called when mouse of a user leaves a node. */
  onNodeMouseLeave?: NodeMouseHandler<NodeType>;
  /** This event handler is called when a user right-clicks on a node. */
  onNodeContextMenu?: NodeMouseHandler<NodeType>;
  /** This event handler is called when a user starts to drag a node. */
  onNodeDragStart?: OnNodeDrag<NodeType>;
  /** This event handler is called when a user drags a node. */
  onNodeDrag?: OnNodeDrag<NodeType>;
  /** This event handler is called when a user stops dragging a node. */
  onNodeDragStop?: OnNodeDrag<NodeType>;
  /** This event handler is called when a user clicks on an edge. */
  onEdgeClick?: (event: MouseEvent$1, edge: EdgeType) => void;
  /** This event handler is called when a user right-clicks on an edge. */
  onEdgeContextMenu?: EdgeMouseHandler<EdgeType>;
  /** This event handler is called when mouse of a user enters an edge. */
  onEdgeMouseEnter?: EdgeMouseHandler<EdgeType>;
  /** This event handler is called when mouse of a user moves over an edge. */
  onEdgeMouseMove?: EdgeMouseHandler<EdgeType>;
  /** This event handler is called when mouse of a user leaves an edge. */
  onEdgeMouseLeave?: EdgeMouseHandler<EdgeType>;
  /** This event handler is called when a user double-clicks on an edge. */
  onEdgeDoubleClick?: EdgeMouseHandler<EdgeType>;
  /**
   * This handler is called when the source or target of a reconnectable edge is dragged from the
   * current node. It will fire even if the edge's source or target do not end up changing.
   * You can use the `reconnectEdge` utility to convert the connection to a new edge.
   */
  onReconnect?: OnReconnect<EdgeType>;
  /**
   * This event fires when the user begins dragging the source or target of an editable edge.
   */
  onReconnectStart?: (event: MouseEvent$1, edge: EdgeType, handleType: HandleType) => void;
  /**
   * This event fires when the user releases the source or target of an editable edge. It is called
   * even if an edge update does not occur.
   */
  onReconnectEnd?: (event: MouseEvent | TouchEvent, edge: EdgeType, handleType: HandleType, connectionState: FinalConnectionState) => void;
  /**
   * Use this event handler to add interactivity to a controlled flow.
   * It is called on node drag, select, and move.
   * @example // Use NodesState hook to create edges and get onNodesChange handler
   * import ReactFlow, { useNodesState } from '@xyflow/react';
   * const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
   *
   * return (<ReactFlow onNodeChange={onNodeChange} {...rest} />)
   * @example // Use helper function to update node
   * import ReactFlow, { applyNodeChanges } from '@xyflow/react';
   *
   * const onNodeChange = useCallback(
   *  (changes) => setNode((nds) => applyNodeChanges(changes, nds)),
   *  [],
   * );
   *
   * return (<ReactFlow onNodeChange={onNodeChange} {...rest} />)
   */
  onNodesChange?: OnNodesChange<NodeType>;
  /**
   * Use this event handler to add interactivity to a controlled flow. It is called on edge select
   * and remove.
   * @example // Use EdgesState hook to create edges and get onEdgesChange handler
   * import ReactFlow, { useEdgesState } from '@xyflow/react';
   * const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);
   *
   * return (<ReactFlow onEdgesChange={onEdgesChange} {...rest} />)
   * @example // Use helper function to update edge
   * import ReactFlow, { applyEdgeChanges } from '@xyflow/react';
   *
   * const onEdgesChange = useCallback(
   *  (changes) => setEdges((eds) => applyEdgeChanges(changes, eds)),
   *  [],
   * );
   *
   * return (<ReactFlow onEdgesChange={onEdgesChange} {...rest} />)
   */
  onEdgesChange?: OnEdgesChange<EdgeType>;
  /** This event handler gets called when a node is deleted. */
  onNodesDelete?: OnNodesDelete<NodeType>;
  /** This event handler gets called when an edge is deleted. */
  onEdgesDelete?: OnEdgesDelete<EdgeType>;
  /** This event handler gets called when a node or edge is deleted. */
  onDelete?: OnDelete<NodeType, EdgeType>;
  /** This event handler gets called when a user starts to drag a selection box. */
  onSelectionDragStart?: SelectionDragHandler<NodeType>;
  /** This event handler gets called when a user drags a selection box. */
  onSelectionDrag?: SelectionDragHandler<NodeType>;
  /** This event handler gets called when a user stops dragging a selection box. */
  onSelectionDragStop?: SelectionDragHandler<NodeType>;
  onSelectionStart?: (event: MouseEvent$1) => void;
  onSelectionEnd?: (event: MouseEvent$1) => void;
  /**
   * This event handler is called when a user right-clicks on a node selection.
   */
  onSelectionContextMenu?: (event: MouseEvent$1, nodes: NodeType[]) => void;
  /**
   * When a connection line is completed and two nodes are connected by the user, this event fires with the new connection.
   * You can use the `addEdge` utility to convert the connection to a complete edge.
   * @example // Use helper function to update edges onConnect
   * import ReactFlow, { addEdge } from '@xyflow/react';
   *
   * const onConnect = useCallback(
   *  (params) => setEdges((eds) => addEdge(params, eds)),
   *  [],
   * );
   *
   * return (<ReactFlow onConnect={onConnect} {...rest} />)
   */
  onConnect?: OnConnect;
  /** This event handler gets called when a user starts to drag a connection line. */
  onConnectStart?: OnConnectStart;
  /**
   * This callback will fire regardless of whether a valid connection could be made or not. You can
   * use the second `connectionState` parameter to have different behavior when a connection was
   * unsuccessful.
   */
  onConnectEnd?: OnConnectEnd;
  onClickConnectStart?: OnConnectStart;
  onClickConnectEnd?: OnConnectEnd;
  /**
   * The `onInit` callback is called when the viewport is initialized. At this point you can use the
   * instance to call methods like `fitView` or `zoomTo`.
   */
  onInit?: OnInit<NodeType, EdgeType>;
  /** This event handler is called while the user is either panning or zooming the viewport. */
  onMove?: OnMove;
  /** This event handler is called when the user begins to pan or zoom the viewport. */
  onMoveStart?: OnMoveStart;
  /**
   * This event handler is called when panning or zooming viewport movement stops.
   * If the movement is not user-initiated, the event parameter will be `null`.
   */
  onMoveEnd?: OnMoveEnd;
  /** This event handler gets called when a user changes group of selected elements in the flow. */
  onSelectionChange?: OnSelectionChangeFunc<NodeType, EdgeType>;
  /** This event handler gets called when user scroll inside the pane. */
  onPaneScroll?: (event?: WheelEvent) => void;
  /** This event handler gets called when user clicks inside the pane. */
  onPaneClick?: (event: MouseEvent$1) => void;
  /** This event handler gets called when user right clicks inside the pane. */
  onPaneContextMenu?: (event: MouseEvent$1 | MouseEvent) => void;
  /** This event handler gets called when mouse enters the pane. */
  onPaneMouseEnter?: (event: MouseEvent$1) => void;
  /** This event handler gets called when mouse moves over the pane. */
  onPaneMouseMove?: (event: MouseEvent$1) => void;
  /** This event handler gets called when mouse leaves the pane. */
  onPaneMouseLeave?: (event: MouseEvent$1) => void;
  /**
   * Distance that the mouse can move between mousedown/up that will trigger a click.
   * @default 0
   */
  paneClickDistance?: number;
  /**
   * Distance that the mouse can move between mousedown/up that will trigger a click.
   * @default 0
   */
  nodeClickDistance?: number;
  /**
   * This handler is called before nodes or edges are deleted, allowing the deletion to be aborted
   * by returning `false` or modified by returning updated nodes and edges.
   */
  onBeforeDelete?: OnBeforeDelete<NodeType, EdgeType>;
  /**
   * Custom node types to be available in a flow.
   * React Flow matches a node's type to a component in the `nodeTypes` object.
   * @default {
   *   input: InputNode,
   *   default: DefaultNode,
   *   output: OutputNode,
   *   group: GroupNode
   * }
   * @example
   * import CustomNode from './CustomNode';
   *
   * const nodeTypes = { nameOfNodeType: CustomNode };
   */
  nodeTypes?: NodeTypes;
  /**
   * Custom edge types to be available in a flow.
   * React Flow matches an edge's type to a component in the `edgeTypes` object.
   * @default {
   *   default: BezierEdge,
   *   straight: StraightEdge,
   *   step: StepEdge,
   *   smoothstep: SmoothStepEdge,
   *   simplebezier: SimpleBezier
   * }
   * @example
   * import CustomEdge from './CustomEdge';
   *
   * const edgeTypes = { nameOfEdgeType: CustomEdge };
   */
  edgeTypes?: EdgeTypes;
  /**
   * The type of edge path to use for connection lines.
   * Although created edges can be of any type, React Flow needs to know what type of path to render for the connection line before the edge is created!
   * @default ConnectionLineType.Bezier
   */
  connectionLineType?: ConnectionLineType;
  /** Styles to be applied to the connection line. */
  connectionLineStyle?: CSSProperties;
  /** React Component to be used as a connection line. */
  connectionLineComponent?: ConnectionLineComponent<NodeType>;
  /** Styles to be applied to the container of the connection line. */
  connectionLineContainerStyle?: CSSProperties;
  /**
   * A loose connection mode will allow you to connect handles with differing types, including
   * source-to-source connections. However, it does not support target-to-target connections. Strict
   * mode allows only connections between source handles and target handles.
   * @default 'strict'
   */
  connectionMode?: ConnectionMode;
  /**
   * If set, pressing the key or chord will delete any selected nodes and edges. Passing an array
   * represents multiple keys that can be pressed.
   * For example, `["Delete", "Backspace"]` will delete selected elements when either key is pressed.
   * @default 'Backspace'
   */
  deleteKeyCode?: KeyCode | null;
  /**
   * If set, holding this key will let you click and drag to draw a selection box around multiple
   * nodes and edges. Passing an array represents multiple keys that can be pressed.
   *
   * For example, `["Shift", "Meta"]` will allow you to draw a selection box when either key is
   * pressed.
   * @default 'Shift'
   */
  selectionKeyCode?: KeyCode | null;
  /**
   * Select multiple elements with a selection box, without pressing down `selectionKey`.
   * @default false
   */
  selectionOnDrag?: boolean;
  /**
   * When set to `"partial"`, when the user creates a selection box by click and dragging nodes that
   * are only partially in the box are still selected.
   * @default 'full'
   */
  selectionMode?: SelectionMode;
  /**
   * If a key is set, you can pan the viewport while that key is held down even if `panOnScroll`
   * is set to `false`.
   *
   * By setting this prop to `null` you can disable this functionality.
   * @default 'Space'
   */
  panActivationKeyCode?: KeyCode | null;
  /**
   * Pressing down this key you can select multiple elements by clicking.
   * @default "Meta" for macOS, "Control" for other systems
   */
  multiSelectionKeyCode?: KeyCode | null;
  /**
   * If a key is set, you can zoom the viewport while that key is held down even if `panOnScroll`
   * is set to `false`.
   *
   * By setting this prop to `null` you can disable this functionality.
   * @default "Meta" for macOS, "Control" for other systems
   *
   */
  zoomActivationKeyCode?: KeyCode | null;
  /** When enabled, nodes will snap to the grid when dragged. */
  snapToGrid?: boolean;
  /**
   * If `snapToGrid` is enabled, this prop configures the grid that nodes will snap to.
   * @example [20, 20]
   */
  snapGrid?: SnapGrid;
  /**
   * You can enable this optimisation to instruct React Flow to only render nodes and edges that would be visible in the viewport.
   *
   * This might improve performance when you have a large number of nodes and edges but also adds an overhead.
   * @default false
   */
  onlyRenderVisibleElements?: boolean;
  /**
   * Controls whether all nodes should be draggable or not. Individual nodes can override this
   * setting by setting their `draggable` prop. If you want to use the mouse handlers on
   * non-draggable nodes, you need to add the `"nopan"` class to those nodes.
   * @default true
   */
  nodesDraggable?: boolean;
  /**
   * When `true`, the viewport will pan when a node is focused.
   * @default true
   */
  autoPanOnNodeFocus?: boolean;
  /**
   * Controls whether all nodes should be connectable or not. Individual nodes can override this
   * setting by setting their `connectable` prop.
   * @default true
   */
  nodesConnectable?: boolean;
  /**
   * When `true`, focus between nodes can be cycled with the `Tab` key and selected with the `Enter`
   * key. This option can be overridden by individual nodes by setting their `focusable` prop.
   * @default true
   */
  nodesFocusable?: boolean;
  /**
   * The origin of the node to use when placing it in the flow or looking up its `x` and `y`
   * position. An origin of `[0, 0]` means that a node's top left corner will be placed at the `x`
   * and `y` position.
   * @default [0, 0]
   * @example
   * [0, 0] // default, top left
   * [0.5, 0.5] // center
   * [1, 1] // bottom right
   */
  nodeOrigin?: NodeOrigin;
  /**
   * When `true`, focus between edges can be cycled with the `Tab` key and selected with the `Enter`
   * key. This option can be overridden by individual edges by setting their `focusable` prop.
   * @default true
   */
  edgesFocusable?: boolean;
  /**
   * Whether edges can be updated once they are created. When both this prop is `true` and an
   * `onReconnect` handler is provided, the user can drag an existing edge to a new source or
   * target. Individual edges can override this value with their reconnectable property.
   * @default true
   */
  edgesReconnectable?: boolean;
  /**
   * When `true`, elements (nodes and edges) can be selected by clicking on them. This option can be
   * overridden by individual elements by setting their `selectable` prop.
   * @default true
   */
  elementsSelectable?: boolean;
  /**
   * If `true`, nodes get selected on drag.
   * @default true
   */
  selectNodesOnDrag?: boolean;
  /**
   * Enabling this prop allows users to pan the viewport by clicking and dragging.
   * You can also set this prop to an array of numbers to limit which mouse buttons can activate panning.
   * Mouse button arrays do not disable touch panning; set this prop to `false` to disable all drag panning.
   * @default true
   * @example [0, 2] // allows panning with the left and right mouse buttons
   * [0, 1, 2, 3, 4] // allows panning with all mouse buttons
   */
  panOnDrag?: boolean | number[];
  /**
   * Minimum zoom level.
   * @default 0.5
   */
  minZoom?: number;
  /**
   * Maximum zoom level.
   * @default 2
   */
  maxZoom?: number;
  /**
   * When you pass a `viewport` prop, it's controlled, and you also need to pass `onViewportChange`
   * to handle internal changes.
   */
  viewport?: Viewport;
  /**
   * Sets the initial position and zoom of the viewport. If a default viewport is provided but
   * `fitView` is enabled, the default viewport will be ignored.
   * @default { x: 0, y: 0, zoom: 1 }
   * @example
   * const initialViewport = {
   *  zoom: 0.5,
   *  position: { x: 0, y: 0 }
   * };
   */
  defaultViewport?: Viewport;
  /**
   * Used when working with a controlled viewport for updating the user viewport state.
   */
  onViewportChange?: (viewport: Viewport) => void;
  /**
   * By default, the viewport extends infinitely. You can use this prop to set a boundary.
   * The first pair of coordinates is the top left boundary and the second pair is the bottom right.
   * @default [[-∞, -∞], [+∞, +∞]]
   * @example [[-1000, -10000], [1000, 1000]]
   */
  translateExtent?: CoordinateExtent;
  /**
   * Disabling this prop will allow the user to scroll the page even when their pointer is over the flow.
   * @default true
   */
  preventScrolling?: boolean;
  /**
   * By default, nodes can be placed on an infinite flow. You can use this prop to set a boundary.
   * The first pair of coordinates is the top left boundary and the second pair is the bottom right.
   * @example [[-1000, -10000], [1000, 1000]]
   */
  nodeExtent?: CoordinateExtent;
  /**
   * Color of edge markers.
   * You can pass `null` to use the CSS variable `--xy-edge-stroke` for the marker color.
   * @default '#b1b1b7'
   */
  defaultMarkerColor?: string | null;
  /**
   * Controls if the viewport should zoom by scrolling inside the container.
   * @default true
   */
  zoomOnScroll?: boolean;
  /**
   * Controls if the viewport should zoom by pinching on a touch screen.
   * @default true
   */
  zoomOnPinch?: boolean;
  /**
   * Controls if the viewport should pan by scrolling inside the container.
   * Can be limited to a specific direction with `panOnScrollMode`.
   * @default false
   */
  panOnScroll?: boolean;
  /**
   * Controls how fast viewport should be panned on scroll.
   * Use together with `panOnScroll` prop.
   * @default 0.5
   */
  panOnScrollSpeed?: number;
  /**
   * This prop is used to limit the direction of panning when `panOnScroll` is enabled.
   * The `"free"` option allows panning in any direction.
   * @default "free"
   * @example "horizontal" | "vertical"
   */
  panOnScrollMode?: PanOnScrollMode;
  /**
   * Controls if the viewport should zoom by double-clicking somewhere on the flow.
   * @default true
   */
  zoomOnDoubleClick?: boolean;
  /**
   * The radius around an edge connection that can trigger an edge reconnection.
   * @default 10
   */
  reconnectRadius?: number;
  /**
   * If a node is draggable, clicking and dragging that node will move it around the canvas. Adding
   * the `"nodrag"` class prevents this behavior and this prop allows you to change the name of that
   * class.
   * @default "nodrag"
   */
  noDragClassName?: string;
  /**
   * Typically, scrolling the mouse wheel when the mouse is over the canvas will zoom the viewport.
   * Adding the `"nowheel"` class to an element in the canvas will prevent this behavior and this prop
   * allows you to change the name of that class.
   * @default "nowheel"
   */
  noWheelClassName?: string;
  /**
   * If an element in the canvas does not stop mouse events from propagating, clicking and dragging
   * that element will pan the viewport. Adding the `"nopan"` class prevents this behavior and this
   * prop allows you to change the name of that class.
   * @default "nopan"
   */
  noPanClassName?: string;
  /** When `true`, the flow will be zoomed and panned to fit all the nodes initially provided. */
  fitView?: boolean;
  /**
   * When you typically call `fitView` on a `ReactFlowInstance`, you can provide an object of
   * options to customize its behavior. This prop lets you do the same for the initial `fitView`
   * call.
   * @example
   * const fitViewOptions = {
   *  padding: 0.1,
   *  includeHiddenNodes: false,
   *  minZoom: 0.1,
   *  maxZoom: 1,
   *  duration: 200,
   *  nodes: [{id: 'node-1'}, {id: 'node-2'}], // nodes to fit
   * };
   */
  fitViewOptions?: FitViewOptions;
  /**
   * The `connectOnClick` option lets you click or tap on a source handle to start a connection
   * and then click on a target handle to complete the connection.
   *
   * If you set this option to `false`, users will need to drag the connection line to the target
   * handle to create a connection.
   * @default true
   */
  connectOnClick?: boolean;
  /**
   * By default, React Flow will render a small attribution in the bottom right corner of the flow.
   *
   * You can use this prop to change its position in case you want to place something else there.
   * @default 'bottom-right'
   * @example 'top-left' | 'top-center' | 'top-right' | 'bottom-left' | 'bottom-center' | 'bottom-right'
   */
  attributionPosition?: PanelPosition;
  /**
   * By default, we render a small attribution in the corner of your flows that links back to the project.
   *
   * Please only remove the attribution if you have a React Flow subscription.
   * More information in the {@link https://reactflow.dev/remove-attribution | removing attribution guide}.
   */
  proOptions?: ProOptions;
  /**
   * Enabling this option will raise the z-index of nodes when they are selected.
   * @default true
   */
  elevateNodesOnSelect?: boolean;
  /**
   * Enabling this option will raise the z-index of edges when they are selected.
   * @default false
   */
  elevateEdgesOnSelect?: boolean;
  /**
   * You can use this prop to disable keyboard accessibility features such as selecting nodes or
   * moving selected nodes with the arrow keys.
   * @default false
   */
  disableKeyboardA11y?: boolean;
  /**
   * When `true`, the viewport will pan automatically when the cursor moves to the edge of the
   * viewport while dragging a node.
   * @default true
   */
  autoPanOnNodeDrag?: boolean;
  /**
   * When `true`, the viewport will pan automatically when the cursor moves to the edge of the
   * viewport while creating a connection.
   * @default true
   */
  autoPanOnConnect?: boolean;
  /**
   * When `true`, the viewport will pan automatically when the cursor moves to the edge of the
   * viewport while creating a selection box.
   * @default true
   */
  autoPanOnSelection?: boolean;
  /**
   * The speed at which the viewport pans while dragging a node or a selection box.
   * @default 15
   */
  autoPanSpeed?: number;
  /**
   * The radius around a handle where you drop a connection line to create a new edge.
   * @default 20
   */
  connectionRadius?: number;
  /**
   * Occasionally something may happen that causes React Flow to throw an error.
   *
   * Instead of exploding your application, we log a message to the console and then call this event handler.
   * You might use it for additional logging or to show a message to the user.
   */
  onError?: OnError;
  /**
   * This callback can be used to validate a new connection
   *
   * If you return `false`, the edge will not be added to your flow.
   * If you have custom connection logic its preferred to use this callback over the
   * `isValidConnection` prop on the handle component for performance reasons.
   */
  isValidConnection?: IsValidConnection<EdgeType>;
  /**
   * With a threshold greater than zero you can delay node drag events.
   * If threshold equals 1, you need to drag the node 1 pixel before a drag event is fired.
   * 1 is the default value, so that clicks don't trigger drag events.
   * @default 1
   */
  nodeDragThreshold?: number;
  /**
   * The threshold in pixels that the mouse must move before a connection line starts to drag.
   * This is useful to prevent accidental connections when clicking on a handle.
   * @default 1
   */
  connectionDragThreshold?: number;
  /** Sets a fixed width for the flow. */
  width?: number;
  /** Sets a fixed height for the flow. */
  height?: number;
  /**
   * Controls color scheme used for styling the flow.
   * @default 'light'
   * @example 'system' | 'light' | 'dark'
   */
  colorMode?: ColorMode;
  /**
   * If set `true`, some debug information will be logged to the console like which events are fired.
   * @default false
   */
  debug?: boolean;
  /**
   * Configuration for customizable labels, descriptions, and UI text. Provided keys will override the corresponding defaults.
   * Allows localization, customization of ARIA descriptions, control labels, minimap labels, and other UI strings.
   */
  ariaLabelConfig?: Partial<AriaLabelConfig>;
  /**
   * Used to define how z-indexing is calculated for nodes and edges.
   * 'auto' is for selections and sub flows, 'basic' for selections only, and 'manual' for no auto z-indexing.
   *
   * @default 'basic'
   */
  zIndexMode?: ZIndexMode;
}
//#endregion
//#region ../../node_modules/.pnpm/@xyflow+react@12.12.0_@types+react-dom@19.3.0_@types+react@19.3.0__@types+react@19.3.0__d76e2522285783b135d2a1abc7fbff33/node_modules/@xyflow/react/dist/esm/types/store.d.ts
type ReactFlowStore<NodeType extends Node$1 = Node$1, EdgeType extends Edge$1 = Edge$1> = {
  rfId: string;
  width: number;
  height: number;
  transform: Transform;
  nodes: NodeType[];
  nodesInitialized: boolean;
  nodeLookup: NodeLookup<InternalNode<NodeType>>;
  parentLookup: ParentLookup<InternalNode<NodeType>>;
  edges: EdgeType[];
  edgeLookup: EdgeLookup<EdgeType>;
  connectionLookup: ConnectionLookup;
  onNodesChange: OnNodesChange<NodeType> | null;
  onEdgesChange: OnEdgesChange<EdgeType> | null;
  hasDefaultNodes: boolean;
  hasDefaultEdges: boolean;
  domNode: HTMLDivElement | null;
  paneDragging: boolean;
  noPanClassName: string;
  panZoom: PanZoomInstance | null;
  minZoom: number;
  maxZoom: number;
  translateExtent: CoordinateExtent;
  nodeExtent: CoordinateExtent;
  nodeOrigin: NodeOrigin;
  nodeDragThreshold: number;
  connectionDragThreshold: number;
  nodesSelectionActive: boolean;
  userSelectionActive: boolean;
  userSelectionRect: SelectionRect | null;
  connection: ConnectionState<InternalNode<NodeType>>;
  connectionMode: ConnectionMode;
  connectionClickStartHandle: (Pick<Handle, 'nodeId' | 'id'> & Required<Pick<Handle, 'type'>>) | null;
  snapToGrid: boolean;
  snapGrid: SnapGrid;
  nodesDraggable: boolean;
  autoPanOnNodeFocus: boolean;
  nodesConnectable: boolean;
  nodesFocusable: boolean;
  edgesFocusable: boolean;
  edgesReconnectable: boolean;
  elementsSelectable: boolean;
  elevateNodesOnSelect: boolean;
  elevateEdgesOnSelect: boolean;
  selectNodesOnDrag: boolean;
  multiSelectionActive: boolean;
  onNodeDragStart: OnNodeDrag<NodeType> | undefined;
  onNodeDrag: OnNodeDrag<NodeType> | undefined;
  onNodeDragStop: OnNodeDrag<NodeType> | undefined;
  onSelectionDragStart: OnSelectionDrag | undefined;
  onSelectionDrag: OnSelectionDrag | undefined;
  onSelectionDragStop: OnSelectionDrag | undefined;
  onMoveStart: OnMoveStart | undefined;
  onMove: OnMove | undefined;
  onMoveEnd: OnMoveEnd | undefined;
  onConnect: OnConnect | undefined;
  onConnectStart: OnConnectStart | undefined;
  onConnectEnd: OnConnectEnd | undefined;
  onClickConnectStart: OnConnectStart | undefined;
  onClickConnectEnd: OnConnectEnd | undefined;
  connectOnClick: boolean;
  defaultEdgeOptions: DefaultEdgeOptions | undefined;
  fitViewQueued: boolean;
  fitViewOptions: FitViewOptions | undefined;
  fitViewResolver: ReturnType<typeof withResolvers<boolean>> | null;
  onNodesDelete: OnNodesDelete<NodeType> | undefined;
  onEdgesDelete: OnEdgesDelete<EdgeType> | undefined;
  onDelete: OnDelete | undefined;
  onError: OnError | undefined;
  onViewportChangeStart: OnViewportChange | undefined;
  onViewportChange: OnViewportChange | undefined;
  onViewportChangeEnd: OnViewportChange | undefined;
  onBeforeDelete: OnBeforeDelete<NodeType, EdgeType> | undefined;
  onSelectionChangeHandlers: OnSelectionChangeFunc<NodeType, EdgeType>[];
  ariaLiveMessage: string;
  autoPanOnConnect: boolean;
  autoPanOnNodeDrag: boolean;
  autoPanSpeed: number;
  connectionRadius: number;
  isValidConnection: IsValidConnection<EdgeType> | undefined;
  lib: string;
  debug: boolean;
  ariaLabelConfig: AriaLabelConfig;
  zIndexMode: ZIndexMode;
  onNodesChangeMiddlewareMap: Map<symbol, (changes: NodeChange<NodeType>[]) => NodeChange<NodeType>[]>;
  onEdgesChangeMiddlewareMap: Map<symbol, (changes: EdgeChange<EdgeType>[]) => EdgeChange<EdgeType>[]>;
};
type ReactFlowActions<NodeType extends Node$1, EdgeType extends Edge$1> = {
  setNodes: (nodes: NodeType[]) => void;
  setEdges: (edges: EdgeType[]) => void;
  setDefaultNodesAndEdges: (nodes?: NodeType[], edges?: EdgeType[]) => void;
  updateNodeInternals: (updates: Map<string, InternalNodeUpdate>, params?: {
    triggerFitView: boolean;
  }) => void;
  updateNodePositions: UpdateNodePositions;
  resetSelectedElements: () => void;
  unselectNodesAndEdges: (params?: UnselectNodesAndEdgesParams<NodeType, EdgeType>) => void;
  addSelectedNodes: (nodeIds: string[]) => void;
  addSelectedEdges: (edgeIds: string[]) => void;
  setMinZoom: (minZoom: number) => void;
  setMaxZoom: (maxZoom: number) => void;
  setTranslateExtent: (translateExtent: CoordinateExtent) => void;
  setNodeExtent: (nodeExtent: CoordinateExtent) => void;
  cancelConnection: () => void;
  updateConnection: UpdateConnection<InternalNode<NodeType>>;
  reset: () => void;
  triggerNodeChanges: (changes: NodeChange<NodeType>[]) => void;
  triggerEdgeChanges: (changes: EdgeChange<EdgeType>[]) => void;
  panBy: PanBy;
  setCenter: SetCenter;
};
type ReactFlowState<NodeType extends Node$1 = Node$1, EdgeType extends Edge$1 = Edge$1> = ReactFlowStore<NodeType, EdgeType> & ReactFlowActions<NodeType, EdgeType>;
//#endregion
//#region ../../node_modules/.pnpm/@xyflow+react@12.12.0_@types+react-dom@19.3.0_@types+react@19.3.0__@types+react@19.3.0__d76e2522285783b135d2a1abc7fbff33/node_modules/@xyflow/react/dist/esm/types/instance.d.ts
type ReactFlowJsonObject<NodeType extends Node$1 = Node$1, EdgeType extends Edge$1 = Edge$1> = {
  nodes: NodeType[];
  edges: EdgeType[];
  viewport: Viewport;
};
type DeleteElementsOptions = {
  nodes?: (Node$1 | {
    id: Node$1['id'];
  })[];
  edges?: (Edge$1 | {
    id: Edge$1['id'];
  })[];
};
/**
 * @inline
 */
type GeneralHelpers<NodeType extends Node$1 = Node$1, EdgeType extends Edge$1 = Edge$1> = {
  /**
   * Returns nodes.
   *
   * @returns nodes array
   */
  getNodes: () => NodeType[];
  /**
   * Set your nodes array to something else by either overwriting it with a new array or by passing
   * in a function to update the existing array. If using a function, it is important to make sure a
   * new array is returned instead of mutating the existing array. Calling this function will
   * trigger the `onNodesChange` handler in a controlled flow.
   *
   * @param payload - the nodes to set or a function that receives the current nodes and returns the new nodes
   */
  setNodes: (payload: NodeType[] | ((nodes: NodeType[]) => NodeType[])) => void;
  /**
   * Add one or many nodes to your existing nodes array. Calling this function will trigger the
   * `onNodesChange` handler in a controlled flow.
   *
   * @param payload - the nodes to add
   */
  addNodes: (payload: NodeType[] | NodeType) => void;
  /**
   * Returns a node by id.
   *
   * @param id - the node id
   * @returns the node or undefined if no node was found
   */
  getNode: (id: string) => NodeType | undefined;
  /**
   * Returns an internal node by id.
   *
   * @param id - the node id
   * @returns the internal node or undefined if no node was found
   */
  getInternalNode: (id: string) => InternalNode<NodeType> | undefined;
  /**
   * Returns edges.
   *
   * @returns edges array
   */
  getEdges: () => EdgeType[];
  /**
   * Set your edges array to something else by either overwriting it with a new array or by passing
   * in a function to update the existing array. If using a function, it is important to make sure a
   * new array is returned instead of mutating the existing array. Calling this function will
   * trigger the `onEdgesChange` handler in a controlled flow.
   *
   * @param payload - the edges to set or a function that receives the current edges and returns the new edges
   */
  setEdges: (payload: EdgeType[] | ((edges: EdgeType[]) => EdgeType[])) => void;
  /**
   * Add one or many edges to your existing edges array. Calling this function will trigger the
   * `onEdgesChange` handler in a controlled flow.
   *
   * @param payload - the edges to add
   */
  addEdges: (payload: EdgeType[] | EdgeType) => void;
  /**
   * Returns an edge by id.
   *
   * @param id - the edge id
   * @returns the edge or undefined if no edge was found
   */
  getEdge: (id: string) => EdgeType | undefined;
  /**
   * Returns the nodes, edges and the viewport as a JSON object.
   *
   * @returns the nodes, edges and the viewport as a JSON object
   */
  toObject: () => ReactFlowJsonObject<NodeType, EdgeType>;
  /**
   * Deletes nodes and edges.
   *
   * @param params.nodes - optional nodes array to delete
   * @param params.edges - optional edges array to delete
   *
   * @returns a promise that resolves with the deleted nodes and edges
   */
  deleteElements: (params: DeleteElementsOptions) => Promise<{
    deletedNodes: Node$1[];
    deletedEdges: Edge$1[];
  }>;
  /**
   * Find all the nodes currently intersecting with a given node or rectangle. The `partially`
   * parameter can be set to `true` to include nodes that are only partially intersecting.
   *
   * @param node - the node or rect to check for intersections
   * @param partially - true by default, if set to false, only nodes that are fully intersecting will be returned
   * @param nodes - optional nodes array to check for intersections
   *
   * @returns an array of intersecting nodes
   */
  getIntersectingNodes: (node: NodeType | {
    id: Node$1['id'];
  } | Rect, partially?: boolean, nodes?: NodeType[]) => NodeType[];
  /**
   * Determine if a given node or rectangle is intersecting with another rectangle. The `partially`
   * parameter can be set to true return `true` even if the node is only partially intersecting.
   *
   * @param node - the node or rect to check for intersections
   * @param area - the rect to check for intersections
   * @param partially - if true, the node is considered to be intersecting if it partially overlaps with the passed react
   *
   * @returns true if the node or rect intersects with the given area
   */
  isNodeIntersecting: (node: NodeType | {
    id: Node$1['id'];
  } | Rect, area: Rect, partially?: boolean) => boolean;
  /**
   * Updates a node.
   *
   * @param id - id of the node to update
   * @param nodeUpdate - the node update as an object or a function that receives the current node and returns the node update
   * @param options.replace - if true, the node is replaced with the node update, otherwise the changes get merged
   *
   * @example
   * updateNode('node-1', (node) => ({ position: { x: node.position.x + 10, y: node.position.y } }));
   */
  updateNode: (id: string, nodeUpdate: Partial<NodeType> | ((node: NodeType) => Partial<NodeType>), options?: {
    replace: boolean;
  }) => void;
  /**
   * Updates the data attribute of a node.
   *
   * @param id - id of the node to update
   * @param dataUpdate - the data update as an object or a function that receives the current data and returns the data update
   * @param options.replace - if true, the data is replaced with the data update, otherwise the changes get merged
   *
   * @example
   * updateNodeData('node-1', { label: 'A new label' });
   */
  updateNodeData: (id: string, dataUpdate: Partial<NodeType['data']> | ((node: NodeType) => Partial<NodeType['data']>), options?: {
    replace: boolean;
  }) => void;
  /**
   * Updates an edge.
   *
   * @param id - id of the edge to update
   * @param edgeUpdate - the edge update as an object or a function that receives the current edge and returns the edge update
   * @param options.replace - if true, the edge is replaced with the edge update, otherwise the changes get merged
   *
   * @example
   * updateEdge('edge-1', (edge) => ({ label: 'A new label' }));
   */
  updateEdge: (id: string, edgeUpdate: Partial<EdgeType> | ((edge: EdgeType) => Partial<EdgeType>), options?: {
    replace: boolean;
  }) => void;
  /**
   * Updates the data attribute of a edge.
   *
   * @param id - id of the edge to update
   * @param dataUpdate - the data update as an object or a function that receives the current data and returns the data update
   * @param options.replace - if true, the data is replaced with the data update, otherwise the changes get merged
   *
   * @example
   * updateEdgeData('edge-1', { label: 'A new label' });
   */
  updateEdgeData: (id: string, dataUpdate: Partial<EdgeType['data']> | ((edge: EdgeType) => Partial<EdgeType['data']>), options?: {
    replace: boolean;
  }) => void;
  /**
   * Returns the bounds of the given nodes or node ids.
   *
   * @param nodes - the nodes or node ids to calculate the bounds for
   *
   * @returns the bounds of the given nodes
   */
  getNodesBounds: (nodes: (NodeType | InternalNode | string)[]) => Rect;
  /**
   * Get all the connections of a handle belonging to a specific node. The type parameter be either
   * `'source'` or `'target'`.
   * @deprecated
   * @param type - handle type 'source' or 'target'
   * @param id - the handle id (this is only needed if you have multiple handles of the same type, meaning you have to provide a unique id for each handle)
   * @param nodeId - the node id the handle belongs to
   * @returns an array with handle connections
   */
  getHandleConnections: ({ type, id, nodeId }: {
    type: HandleType;
    nodeId: string;
    id?: string | null;
  }) => HandleConnection[];
  /**
   * Gets all connections to a node. Can be filtered by handle type and id.
   * @param type - handle type 'source' or 'target'
   * @param handleId - the handle id (this is only needed if you have multiple handles of the same type, meaning you have to provide a unique id for each handle)
   * @param nodeId - the node id the handle belongs to
   * @returns an array with handle connections
   */
  getNodeConnections: ({ type, handleId, nodeId }: {
    type?: HandleType;
    nodeId: string;
    handleId?: string | null;
  }) => NodeConnection[];
  /**
   * Fits the view based on the passed params. By default it fits the view to all nodes.
   *
   * @param options.padding - optional padding
   * @param options.nodes - optional nodes to fit the view to
   * @param options.minZoom - optional minZoom
   * @param options.maxZoom - optional maxZoom
   * @param options.duration - optional duration. If set, a transition will be applied
   * @param options.includeHiddenNodes - optional includeHiddenNodes
   */
  fitView: FitView<NodeType>;
};
/**
 * The `ReactFlowInstance` provides a collection of methods to query and manipulate
 * the internal state of your flow. You can get an instance by using the
 * [`useReactFlow`](/api-reference/hooks/use-react-flow) hook or attaching a listener
 * to the [`onInit`](/api-reference/react-flow#event-oninit) event.
 *
 * @public
 */
type ReactFlowInstance<NodeType extends Node$1 = Node$1, EdgeType extends Edge$1 = Edge$1> = GeneralHelpers<NodeType, EdgeType> & ViewportHelperFunctions & {
  /**
   * React Flow needs to mount the viewport to the DOM and initialize its zoom and pan behavior.
   * This property tells you when viewport is initialized.
   */
  viewportInitialized: boolean;
};
//#endregion
//#region ../../node_modules/.pnpm/@xyflow+react@12.12.0_@types+react-dom@19.3.0_@types+react@19.3.0__@types+react@19.3.0__d76e2522285783b135d2a1abc7fbff33/node_modules/@xyflow/react/dist/esm/components/ViewportPortal/index.d.ts
/**
 * The `<ViewportPortal />` component can be used to add components to the same viewport
 * of the flow where nodes and edges are rendered. This is useful when you want to render
 * your own components that are adhere to the same coordinate system as the nodes & edges
 * and are also affected by zooming and panning
 * @public
 * @example
 *
 * ```jsx
 *import React from 'react';
 *import { ViewportPortal } from '@xyflow/react';
 *
 *export default function () {
 *  return (
 *    <ViewportPortal>
 *      <div
 *        style={{ transform: 'translate(100px, 100px)', position: 'absolute' }}
 *      >
 *        This div is positioned at [100, 100] on the flow.
 *      </div>
 *    </ViewportPortal>
 *  );
 *}
 *```
 */
declare function ViewportPortal({ children }: {
  children: ReactNode;
}): import("react").ReactPortal | null;
//#endregion
//#region ../../node_modules/.pnpm/@xyflow+react@12.12.0_@types+react-dom@19.3.0_@types+react@19.3.0__@types+react@19.3.0__d76e2522285783b135d2a1abc7fbff33/node_modules/@xyflow/react/dist/esm/additional-components/Controls/types.d.ts
/**
 * @expand
 */
type ControlButtonProps = ButtonHTMLAttributes<HTMLButtonElement>;
//#endregion
//#region ../../node_modules/.pnpm/@xyflow+react@12.12.0_@types+react-dom@19.3.0_@types+react@19.3.0__@types+react@19.3.0__d76e2522285783b135d2a1abc7fbff33/node_modules/@xyflow/react/dist/esm/additional-components/Controls/ControlButton.d.ts
/**
 * You can add buttons to the control panel by using the `<ControlButton />` component
 * and pass it as a child to the [`<Controls />`](/api-reference/components/controls) component.
 *
 * @public
 * @example
 *```jsx
 *import { MagicWand } from '@radix-ui/react-icons'
 *import { ReactFlow, Controls, ControlButton } from '@xyflow/react'
 *
 *export default function Flow() {
 *  return (
 *    <ReactFlow nodes={[...]} edges={[...]}>
 *      <Controls>
 *        <ControlButton onClick={() => alert('Something magical just happened. ✨')}>
 *          <MagicWand />
 *        </ControlButton>
 *      </Controls>
 *    </ReactFlow>
 *  )
 *}
 *```
 */
declare function ControlButton({ children, className, ...rest }: ControlButtonProps): import("react/jsx-runtime").JSX.Element;
//#endregion
//#region ../../node_modules/.pnpm/@xyflow+react@12.12.0_@types+react-dom@19.3.0_@types+react@19.3.0__@types+react@19.3.0__d76e2522285783b135d2a1abc7fbff33/node_modules/@xyflow/react/dist/esm/additional-components/MiniMap/types.d.ts
type GetMiniMapNodeAttribute<NodeType extends Node$1 = Node$1> = (node: NodeType) => string;
/**
 * @expand
 */
type MiniMapProps<NodeType extends Node$1 = Node$1> = Omit<HTMLAttributes<SVGSVGElement>, 'onClick'> & {
  /**
   * Color of nodes on minimap.
   * @default "#e2e2e2"
   */
  nodeColor?: string | GetMiniMapNodeAttribute<NodeType>;
  /**
   * Stroke color of nodes on minimap.
   * @default "transparent"
   */
  nodeStrokeColor?: string | GetMiniMapNodeAttribute<NodeType>;
  /**
   * Class name applied to nodes on minimap.
   * @default ""
   */
  nodeClassName?: string | GetMiniMapNodeAttribute<NodeType>;
  /**
   * Border radius of nodes on minimap.
   * @default 5
   */
  nodeBorderRadius?: number;
  /**
   * Stroke width of nodes on minimap.
   * @default 2
   */
  nodeStrokeWidth?: number;
  /**
   * A custom component to render the nodes in the minimap. This component must render an SVG
   * element!
   */
  nodeComponent?: ComponentType<MiniMapNodeProps>;
  /** Background color of minimap. */
  bgColor?: string;
  /**
   * The color of the mask that covers the portion of the minimap not currently visible in the
   * viewport.
   * @default "rgba(240, 240, 240, 0.6)"
   */
  maskColor?: string;
  /**
   * Stroke color of mask representing viewport.
   * @default transparent
   */
  maskStrokeColor?: string;
  /**
   * Stroke width of mask representing viewport.
   * @default 1
   */
  maskStrokeWidth?: number;
  /**
   * Position of minimap on pane.
   * @default PanelPosition.BottomRight
   * @example PanelPosition.TopLeft, PanelPosition.TopRight,
   * PanelPosition.BottomLeft, PanelPosition.BottomRight
   */
  position?: PanelPosition;
  /** Callback called when minimap is clicked. */
  onClick?: (event: MouseEvent$1, position: XYPosition) => void;
  /** Callback called when node on minimap is clicked. */
  onNodeClick?: (event: MouseEvent$1, node: NodeType) => void;
  /**
   * Determines whether you can pan the viewport by dragging inside the minimap.
   * @default false
   */
  pannable?: boolean;
  /**
   * Determines whether you can zoom the viewport by scrolling inside the minimap.
   * @default false
   */
  zoomable?: boolean;
  /**
   * There is no text inside the minimap for a screen reader to use as an accessible name, so it's
   * important we provide one to make the minimap accessible. The default is sufficient, but you may
   * want to replace it with something more relevant to your app or product.
   * @default "Mini Map"
   */
  ariaLabel?: string | null;
  /** Invert direction when panning the minimap viewport. */
  inversePan?: boolean;
  /**
   * Step size for zooming in/out on minimap.
   * @default 10
   */
  zoomStep?: number;
  /**
   * Offset the viewport on the minimap, acts like a padding.
   * @default 5
   */
  offsetScale?: number;
};
/**
 * The props that are passed to the MiniMapNode component
 *
 * @public
 * @expand
 */
type MiniMapNodeProps = {
  id: string;
  x: number;
  y: number;
  width: number;
  height: number;
  borderRadius: number;
  className: string;
  color?: string;
  shapeRendering: string;
  strokeColor?: string;
  strokeWidth?: number;
  style?: CSSProperties;
  selected: boolean;
  onClick?: (event: MouseEvent$1, id: string) => void;
};
//#endregion
//#region ../../node_modules/.pnpm/@xyflow+react@12.12.0_@types+react-dom@19.3.0_@types+react@19.3.0__@types+react@19.3.0__d76e2522285783b135d2a1abc7fbff33/node_modules/@xyflow/react/dist/esm/additional-components/NodeToolbar/types.d.ts
/**
 * @expand
 */
type NodeToolbarProps = HTMLAttributes<HTMLDivElement> & {
  /**
   * By passing in an array of node id's you can render a single tooltip for a group or collection
   * of nodes.
   */
  nodeId?: string | string[];
  /** If `true`, node toolbar is visible even if node is not selected. */
  isVisible?: boolean;
  /**
   * Position of the toolbar relative to the node.
   * @default Position.Top
   * @example Position.TopLeft, Position.TopRight, Position.BottomLeft, Position.BottomRight
   */
  position?: Position;
  /**
   * The space between the node and the toolbar, measured in pixels.
   * @default 10
   */
  offset?: number;
  /**
   * Align the toolbar relative to the node.
   * @default "center"
   * @example Align.Start, Align.Center, Align.End
   */
  align?: Align;
};
//#endregion
//#region ../../node_modules/.pnpm/@xyflow+react@12.12.0_@types+react-dom@19.3.0_@types+react@19.3.0__@types+react@19.3.0__d76e2522285783b135d2a1abc7fbff33/node_modules/@xyflow/react/dist/esm/additional-components/NodeToolbar/NodeToolbar.d.ts
/**
 * This component can render a toolbar or tooltip to one side of a custom node. This
 * toolbar doesn't scale with the viewport so that the content is always visible.
 *
 * @public
 * @example
 * ```jsx
 *import { memo } from 'react';
 *import { Handle, Position, NodeToolbar } from '@xyflow/react';
 *
 *function CustomNode({ data }) {
 *  return (
 *    <>
 *      <NodeToolbar isVisible={data.toolbarVisible} position={data.toolbarPosition}>
 *        <button>delete</button>
 *        <button>copy</button>
 *        <button>expand</button>
 *      </NodeToolbar>
 *
 *      <div style={{ padding: '10px 20px' }}>
 *        {data.label}
 *      </div>
 *
 *      <Handle type="target" position={Position.Left} />
 *      <Handle type="source" position={Position.Right} />
 *    </>
 *  );
 *};
 *
 *export default memo(CustomNode);
 *```
 * @remarks By default, the toolbar is only visible when a node is selected. If multiple
 * nodes are selected it will not be visible to prevent overlapping toolbars or
 * clutter. You can override this behavior by setting the `isVisible` prop to `true`.
 */
declare function NodeToolbar({ nodeId, children, className, style, isVisible, position, offset, align, ...rest }: NodeToolbarProps): import("react/jsx-runtime").JSX.Element | null;
//#endregion
//#region ../diagram/dist/base/Base.d.mts
//#region src/base/Base.d.ts
type WithDimmed = {
  data: {
    dimmed?: Base.Dimmed;
  };
};
type WithHovered = {
  data: {
    hovered?: boolean;
  };
};
declare function setDimmed<T extends WithDimmed>(value: T, dimmed: 'immediate' | boolean): T;
declare function setDimmed(dimmed: 'immediate' | boolean): <T extends WithDimmed>(value: T) => T;
declare function setHovered<T extends WithHovered>(value: T, hovered: boolean): T;
declare function setHovered(hovered: boolean): <T extends WithHovered>(value: T) => T;
type WithData<D> = {
  data: D;
};
declare function setData<E extends WithData<any>>(value: E, data: Partial<E['data']>): E;
declare function setData<E extends WithData<any>>(state: Partial<NoInfer<E>['data']>): (value: E) => E;
export declare const Base: {
  setDimmed: typeof setDimmed;
  setHovered: typeof setHovered;
  setData: typeof setData;
};
export declare namespace Base {
  type Dimmed = 'immediate' | boolean;
}
//#endregion
//#endregion
//#region ../diagram/dist/base/types.d.mts
//#region src/base/types.d.ts
type BaseNodeData = {
  /**
   * Whether the cursor is hovering over the node
   */
  hovered?: boolean;
  /**
   * Whether the node is dimmed
   * 'immediate' means that the node is dimmed without delay
   */
  dimmed?: Base.Dimmed;
};
type BaseEdgeData = {
  /**
   * Whether the cursor is hovering over the edge
   */
  hovered?: boolean;
  /**
   * Whether the edge is active (animated and highlighted)
   */
  active?: boolean;
  /**
   * Whether the edge is dimmed
   * 'immediate' means that the edge is dimmed without delay
   */
  dimmed?: Base.Dimmed;
};
type BaseNode<Data extends Record<string, unknown> = Record<string, unknown>, NodeType extends string = string> = SetRequired<Node$1<Data & BaseNodeData, NodeType>, 'type' | 'initialWidth' | 'initialHeight'>;
interface BaseEdge<Data extends Record<string, unknown> = Record<string, unknown>, EdgeType extends string = string> extends SetRequired<Edge$1<Data & BaseEdgeData, EdgeType>, 'type' | 'data'> {}
/**
 * ReactFlow Base Node properties with BaseNodeData at least
 */
interface BaseNodeProps<N extends BaseNode = BaseNode> extends NodeProps$1<N> {}
type BaseNodePropsWithData<Data extends Record<string, unknown>> = BaseNodeProps<BaseNode<Data>>;
/**
 * ReactFlow Base Edge properties with BaseEdgeData at least
 */
interface BaseEdgeProps<E extends BaseEdge = BaseEdge> extends EdgeProps$1<E> {}
type BaseEdgePropsWithData<Data extends Record<string, unknown>> = BaseEdgeProps<BaseEdge<Data>>;
/**
 * To cooperate with `exactOptionalPropertyTypes` in `tsconfig.json`
 *
 * @example
 * interface User {
 * 	name: string;
 * 	surname?: string;
 * 	luckyNumber?: number;
 * }
 *
 * type NonOptionalUser = NonOptional<User>
 * // NonOptionalUser = {
 * //   name: string
 * //   surname: string | undefined
 * //   luckyNumber: number | undefined
 * // }
 */
type NonOptional<T extends object, Keys extends OptionalKeysOf<T> = OptionalKeysOf<T>> = Simplify<{ [P in Exclude<keyof T, Keys>]: T[P]; } & { [P in Keys]-?: T[P] | undefined; }>;
//#endregion
//#endregion
//#region ../diagram/dist/likec4diagram/types.d.mts
//#region src/likec4diagram/types.d.ts
declare namespace Types {
  type LeafNodeData = Simplify<BaseNodeData & NonOptional<Pick<DiagramNode, 'id' | 'title' | 'technology' | 'description' | 'notes' | 'color' | 'shape' | 'width' | 'level' | 'height' | 'style' | 'tags' | 'x' | 'y'>> & {
    /**
     * View layout direction, used by DefaultHandles to position node handles
     */
    viewLayoutDir?: AutoLayoutDirection | undefined;
    /**
     * View this node belongs to
     */
    viewId: ViewId$1;
    isMultiple?: boolean | undefined;
    icon: string | null;
    drifts: NonEmptyReadonlyArray<DiagramNodeDriftReason> | null;
  }>;
  /**
   * Represents element from logical model
   */
  type ElementNodeData = Simplify<LeafNodeData & {
    modelFqn: Fqn$1;
    deploymentFqn?: never;
    /**
     * If set - this node has navigation to another view and diagram has handler for this
     */
    navigateTo: ViewId$1 | null;
  }>;
  /**
   * Represents element from deployment model
   */
  type DeploymentElementNodeData = Simplify<LeafNodeData & {
    navigateTo: ViewId$1 | null;
    deploymentFqn: DeploymentFqn;
    modelFqn: Fqn$1 | null;
  }>;
  type SequenceActorNodePort = {
    id: string;
    cx: number;
    cy: number;
    height: number;
    type: 'target' | 'source';
    position: 'left' | 'right' | 'top' | 'bottom';
    hidden?: boolean;
  };
  type SequenceActorNodeData = Simplify<LeafNodeData & {
    navigateTo: ViewId$1 | null;
    modelFqn: Fqn$1 | null;
    ports: Array<SequenceActorNodePort>;
    viewHeight: number;
  }>;
  /**
   * Represents subflow area in the diagram
   * `try` and `alt` flows have special handling in the diagram
   */
  type SequenceSubflowData = LeafNodeData & {
    flowId: StepPath;
    title: string | undefined;
    /**
     * This is first subflow in current flow
     */
    isFirst?: boolean | undefined;
    /**
     * This is last subflow in current flow
     */
    isLast?: boolean | undefined;
    collapsed: boolean;
  } & ({
    flowType: Exclude<DynamicViewFlow.SubFlowType, 'try' | 'alt'>;
  } | SequenceSubflowData.AltOrTry);
  namespace SequenceSubflowData {
    type AltOrTry = {
      flowType: 'try' | 'alt';
      headerHeight: number;
    };
  }
  /**
   * @deprecated Use {@link SequenceSubflowData} instead
   */
  type SequenceParallelAreaData = Simplify<LeafNodeData & {
    parallelPrefix: string;
  }>;
  type CompoundNodeData = Simplify<BaseNodeData & NonOptional<Pick<DiagramNode, 'id' | 'title' | 'notes' | 'color' | 'shape' | 'style' | 'tags' | 'x' | 'y'>> & {
    /**
     * View layout direction, used by DefaultHandles to position node handles
     */
    viewLayoutDir?: AutoLayoutDirection | undefined;
    /**
     * View this node belongs to
     */
    viewId: ViewId$1;
    depth: number;
    icon?: IconUrl;
    drifts: NonEmptyReadonlyArray<DiagramNodeDriftReason> | null;
  }>;
  type CompoundElementNodeData = Simplify<CompoundNodeData & {
    modelFqn: Fqn$1;
    deploymentFqn?: never;
    /**
     * If set - this node has navigation to another view and diagram has handler for this
     */
    navigateTo: ViewId$1 | null;
  }>;
  type CompoundDeploymentNodeData = Simplify<CompoundNodeData & {
    deploymentFqn: DeploymentFqn;
    /**
     * If set - this node refers to a model element
     */
    modelFqn: Fqn$1 | null;
    /**
     * If set - this node has navigation to another view and diagram has handler for this
     */
    navigateTo: ViewId$1 | null;
  }>;
  type ViewGroupNodeData = Simplify<CompoundNodeData & {
    isViewGroup: true;
  }>;
  /**
   * Represents a leaf element rendered as a compact circle in "graph" display variant.
   * Shares {@link LeafNodeData}'s geometry fields (x/y/width/height/style) with the other
   * leaf node types, even though "graph" mode renders a fixed-size circle instead - this
   * keeps generic node utilities (bounds, drifts, notes, etc.) working across all node types.
   */
  type GraphElementNodeData = Simplify<LeafNodeData & {
    modelFqn: Fqn$1 | null;
    deploymentFqn: DeploymentFqn | null;
    navigateTo: ViewId$1 | null;
  }>;
  type ElementNode = BaseNode<ElementNodeData, 'element'>;
  type DeploymentElementNode = BaseNode<DeploymentElementNodeData, 'deployment'>;
  type GraphElementNode = BaseNode<GraphElementNodeData, 'graph-element'>;
  type SequenceActorNode = BaseNode<SequenceActorNodeData, 'seq-actor'>;
  type SequenceParallelArea = BaseNode<SequenceParallelAreaData, 'seq-parallel'>;
  type SequenceSubflowArea = BaseNode<SequenceSubflowData, 'seq-subflow'>;
  type CompoundElementNode = BaseNode<CompoundElementNodeData, 'compound-element'>;
  type CompoundDeploymentNode = BaseNode<CompoundDeploymentNodeData, 'compound-deployment'>;
  type ViewGroupNode = BaseNode<ViewGroupNodeData, 'view-group'>;
  type AnyNode = ElementNode | DeploymentElementNode | CompoundElementNode | CompoundDeploymentNode | ViewGroupNode | SequenceActorNode | SequenceParallelArea | SequenceSubflowArea | GraphElementNode;
  type NodeType = AnyNode['type'];
  type NodeData = ExclusiveUnion$1<{
    ElementNodeData: ElementNodeData;
    DeploymentElementNodeData: DeploymentElementNodeData;
    CompoundElementNodeData: CompoundElementNodeData;
    CompoundDeploymentNodeData: CompoundDeploymentNodeData;
    ViewGroupNodeData: ViewGroupNodeData;
    SequenceActorNodeData: SequenceActorNodeData;
    SequenceParallelAreaData: SequenceParallelAreaData;
    SequenceSubflowAreaData: SequenceSubflowData;
    GraphElementNodeData: GraphElementNodeData;
  }>;
  type Node<Type extends NodeType = NodeType> = Extract<AnyNode, {
    type: Type;
  }>;
  type NodeProps<Type extends NodeType = NodeType> = BaseNodeProps<Node<Type>>;
  type RelationshipEdgeData = Simplify<BaseEdgeData & NonOptional<Pick<DiagramEdge, 'id' | 'label' | 'labelBBox' | 'technology' | 'points' | 'dir' | 'color' | 'line' | 'head' | 'tail' | 'navigateTo' | 'astPath' | 'drifts'>> & {
    notes: MarkdownOrString$1 | null;
    labelXY: XYPosition | null;
    isLabelCustomized?: boolean | undefined;
    controlPoints: XYPosition[] | undefined | null;
    /**
     * When dynamic view in "diagram" variant
     * Edges are RelationshipEdgeData - stepnum is used to determine the step number
     * (backward compatibility)
     */
    stepnum?: number;
  }>;
  type SequenceStepEdgeData = Simplify<BaseEdgeData & NonOptional<Pick<DiagramEdge, 'label' | 'technology' | 'points' | 'dir' | 'color' | 'line' | 'head' | 'tail' | 'navigateTo' | 'astPath' | 'drifts'>> & {
    id: StepPath;
    state?: 'processed' | 'active' | 'skipped' | 'pending' | null;
    stepnum: number;
    parentFlow: null | {
      id: StepPath;
      type: DynamicViewFlow.SubFlowType;
    };
    notes: MarkdownOrString$1 | null;
    labelXY: XYPosition | null;
    labelBBox: BBox$2;
    isLabelCustomized?: boolean | undefined;
    controlPoints: XYPosition[] | undefined | null;
  }>;
  type RelationshipEdge = BaseEdge<RelationshipEdgeData, 'relationship'>;
  type SequenceStepEdge = BaseEdge<SequenceStepEdgeData, 'seq-step'>;
  type AnyEdge = RelationshipEdge | SequenceStepEdge;
  type EdgeType = AnyEdge['type'];
  type Edge<Type extends EdgeType = EdgeType> = Extract<AnyEdge, {
    type: Type;
  }>;
  type EdgeProps<Type extends EdgeType = EdgeType> = BaseEdgeProps<Edge<Type>>;
  type EdgeData = ExclusiveUnion$1<{
    RelationshipEdgeData: RelationshipEdgeData;
    SequenceStepEdgeData: SequenceStepEdgeData;
  }>;
  type NodeRenderer<T extends NodeType> = FunctionComponent<NodeProps<T>>;
  type NodeRenderers = { [T in NodeType]: NodeRenderer<T>; };
  type EdgeRenderer<T extends EdgeType> = FunctionComponent<EdgeProps<T>>;
  type EdgeRenderers = { [T in EdgeType]: EdgeRenderer<T>; };
}
//#endregion
//#endregion
//#region ../diagram/dist/editor/LikeC4EditorCallbacks.d.mts
//#region src/editor/LikeC4EditorCallbacks.d.ts
/**
 * Result of applying a change from the LikeC4 Editor.
 */
interface LikeC4EditorChangeResult {
  /**
   * Whether applying the change will publish a refreshed view to the diagram
   * that the editor should wait for.
   *
   * Returning no result from `handleChange` defaults this to `true`,
   * preserving the existing behavior for integrations that persist changes
   * through an external model service.
   */
  waitForViewSync: boolean;
}
/**
 * Callbacks from LikeC4 Editor.
 */
interface LikeC4EditorCallbacks {
  /**
   * Apply semantic layout to a view (if AI is available)
   * See vite-plugin settings for more details
   */
  applySemanticLayout?: undefined | ((viewId: t.ViewId) => Promise<void>);
  /**
   * Fetch a view by its ID and layout type.
   *
   * @param viewId - The ID of the view to fetch.
   * @param layout - The layout type to use when fetching the view.
   */
  fetchView(viewId: t.ViewId, layout?: t.LayoutType): t.LayoutedView | Promise<t.LayoutedView>;
  /**
   * Callback invoked when the view changes.
   *
   * Return `{ waitForViewSync: false }` when the integration applies the
   * change locally and will not publish a refreshed view. When changes are
   * batched, the editor waits if any callback invocation expects a refresh.
   */
  handleChange(viewId: t.ViewId, change: t.ViewChange): void | LikeC4EditorChangeResult | Promise<void | LikeC4EditorChangeResult>;
}
export declare function createLikeC4Editor(callbacks: LikeC4EditorCallbacks): LikeC4EditorCallbacks;
//#endregion
//#endregion
//#region ../diagram/dist/editor/LikeC4EditorProvider.d.mts
//#region src/editor/LikeC4EditorProvider.d.ts
type LikeC4EditorProviderProps = PropsWithChildren<{
  editor: LikeC4EditorCallbacks;
}>;
/**
 * Provider for the LikeC4 Editor.
 * @example
 * ```tsx
 *
 * // Not required to use memo for editor callbacks
 * const editor = createLikeC4Editor({
 *   fetchView: async (viewId, layout) => {
 *     // fetch view logic
 *   },
 *   handleChange: (viewId, change) => {
 *     // handle change logic
 *   }
 * })
 *
 * <LikeC4EditorProvider
 *  editor={editor}>
 *   <App />
 * </LikeC4EditorProvider>
 * ```
 */
export declare function LikeC4EditorProvider({ children, editor }: LikeC4EditorProviderProps): import("react").JSX.Element;
//#endregion
//#endregion
//#region ../diagram/dist/overlays/relationships-browser/_types.d.mts
//#region src/overlays/relationships-browser/_types.d.ts
declare namespace RelationshipsBrowserTypes {
  type Column = 'incomers' | 'subjects' | 'outgoers';
  /**
   * The node's incoming and outgoing ports
   */
  type Ports = {
    in: string[];
    out: string[];
  };
  type ElementNodeData = Simplify<BaseNodeData & NonOptional<Pick<DiagramNode, 'id' | 'title' | 'technology' | 'description' | 'color' | 'shape' | 'style' | 'width' | 'height' | 'tags' | 'navigateTo'>> & {
    column: Column;
    fqn: Fqn$1;
    icon: string | null;
    ports: Ports;
    existsInCurrentView: boolean;
  }>;
  type CompoundNodeData = Simplify<BaseNodeData & NonOptional<Pick<DiagramNode, 'id' | 'title' | 'color' | 'shape' | 'style'>> & {
    column: Column;
    fqn: Fqn$1;
    depth: number;
    icon: IconUrl;
    ports: Ports;
    existsInCurrentView: boolean;
  }>;
  type EmptyNodeData = BaseNodeData & {
    column: Column;
  };
  type ElementNode = BaseNode<ElementNodeData, 'element'>;
  type CompoundNode = BaseNode<CompoundNodeData, 'compound'>;
  type EmptyNode = BaseNode<EmptyNodeData, 'empty'>;
  type AnyNode = ElementNode | CompoundNode | EmptyNode;
  type NodeType = AnyNode['type'];
  type Node<T extends NodeType = NodeType> = Extract<AnyNode, {
    type: T;
  }>;
  type NodeProps<T extends NodeType = NodeType> = BaseNodeProps<Node<T>>;
  type NodeData = ExclusiveUnion$1<{
    ElementNodeData: ElementNodeData;
    CompoundNodeData: CompoundNodeData;
    EmptyNodeData: EmptyNodeData;
  }>;
  type NodeRenderer<T extends NodeType = NodeType> = FunctionComponent<NodeProps<T>>;
  type NodeRenderers = { [T in NodeType]: NodeRenderer<T>; };
  type EdgeData = Simplify<BaseEdgeData & {
    sourceFqn: Fqn$1;
    targetFqn: Fqn$1;
    relations: NonEmptyArray<RelationId>;
    color: Color;
    label: string | null;
    navigateTo: ViewId$1 | null;
    line: RelationshipLineType;
    head?: RelationshipArrowType;
    tail?: RelationshipArrowType;
    existsInCurrentView: boolean;
  }>;
  type Edge = BaseEdge<EdgeData, 'relationship'>;
  type EdgeProps = BaseEdgeProps<Edge>;
}
//#endregion
//#endregion
//#region ../diagram/dist/overlays/relationships-browser/layout.d.mts
//#region src/overlays/relationships-browser/layout.d.ts
type LayoutRelationshipsViewResult = {
  subject: Fqn$1;
  subjectExistsInScope: boolean;
  nodes: LayoutRelationshipsViewResult.Node[];
  edges: LayoutRelationshipsViewResult.Edge[];
  bounds: DiagramView['bounds'];
};
declare namespace LayoutRelationshipsViewResult {
  const Empty: ElementKind;
  type Node = Omit<DiagramNode, 'deploymentRef' | 'description' | 'inEdges' | 'outEdges'> & {
    description: MarkdownOrString$1 | null;
    column: RelationshipsBrowserTypes.Column;
    ports: RelationshipsBrowserTypes.Ports;
    existsInCurrentView: boolean;
  };
  type Edge = Omit<DiagramEdge, 'description'> & {
    sourceFqn: Fqn$1;
    targetFqn: Fqn$1;
    sourceHandle: string;
    targetHandle: string;
    existsInCurrentView: boolean;
  };
}
//#endregion
//#endregion
//#region ../../node_modules/.pnpm/xstate@5.33.2/node_modules/xstate/dist/declarations/src/inspection.d.ts
type InspectionEvent = InspectedSnapshotEvent | InspectedEventEvent | InspectedActorEvent | InspectedTransitionEvent | InspectedMicrostepEvent | InspectedActionEvent;
interface BaseInspectionEventProperties {
  rootId: string;
  /**
   * The relevant actorRef for the inspection event.
   *
   * - For snapshot events, this is the `actorRef` of the snapshot.
   * - For event events, this is the target `actorRef` (recipient of event).
   * - For actor events, this is the `actorRef` of the registered actor.
   */
  actorRef: ActorRefLike;
}
interface InspectedSnapshotEvent extends BaseInspectionEventProperties {
  type: '@xstate.snapshot';
  event: AnyEventObject;
  snapshot: Snapshot$1<unknown>;
}
interface InspectedTransitionEvent extends BaseInspectionEventProperties {
  type: '@xstate.transition';
  event: AnyEventObject;
  snapshot: Snapshot$1<unknown>;
}
interface InspectedMicrostepEvent extends BaseInspectionEventProperties {
  type: '@xstate.microstep';
  event: AnyEventObject;
  snapshot: Snapshot$1<unknown>;
  _transitions: AnyTransitionDefinition[];
}
interface InspectedActionEvent extends BaseInspectionEventProperties {
  type: '@xstate.action';
  action: {
    type: string;
    params: unknown;
  };
}
interface InspectedEventEvent extends BaseInspectionEventProperties {
  type: '@xstate.event';
  sourceRef: ActorRefLike | undefined;
  event: AnyEventObject;
}
interface InspectedActorEvent extends BaseInspectionEventProperties {
  type: '@xstate.actor';
}
//#endregion
//#region ../../node_modules/.pnpm/xstate@5.33.2/node_modules/xstate/dist/declarations/src/system.d.ts
interface ScheduledEvent {
  id: string;
  event: EventObject;
  startedAt: number;
  delay: number;
  source: AnyActorRef;
  target: AnyActorRef;
}
interface Clock {
  setTimeout(fn: (...args: any[]) => void, timeout: number): any;
  clearTimeout(id: any): void;
}
interface Scheduler {
  schedule(source: AnyActorRef, target: AnyActorRef, event: EventObject, delay: number, id: string | undefined): void;
  cancel(source: AnyActorRef, id: string): void;
  cancelAll(actorRef: AnyActorRef): void;
}
interface ActorSystem<T extends ActorSystemInfo> {
  get: <K extends keyof T['actors']>(key: K) => T['actors'][K] | undefined;
  getAll: () => Partial<T['actors']>;
  inspect: (observer: Observer<InspectionEvent> | ((inspectionEvent: InspectionEvent) => void)) => Subscription;
  scheduler: Scheduler;
  getSnapshot: () => {
    _scheduledEvents: Record<string, ScheduledEvent>;
  };
  start: () => void;
  _clock: Clock;
  _logger: (...args: any[]) => void;
}
type AnyActorSystem = ActorSystem<any>;
//#endregion
//#region ../../node_modules/.pnpm/xstate@5.33.2/node_modules/xstate/dist/declarations/src/StateMachine.d.ts
declare class StateMachine<TContext extends MachineContext, TEvent extends EventObject, TChildren extends Record<string, AnyActorRef | undefined>, TActor extends ProvidedActor, TAction extends ParameterizedObject, TGuard extends ParameterizedObject, TDelay extends string, TStateValue extends StateValue, TTag extends string, TInput, TOutput, TEmitted extends EventObject, TStateMeta extends MetaObject, TStateSchema extends StateSchema, TTransitionMeta extends MetaObject = TStateMeta> implements ActorLogic<MachineSnapshot<TContext, TEvent, TChildren, TStateValue, TTag, TOutput, TStateMeta, TStateSchema>, TEvent, TInput, AnyActorSystem, TEmitted> {
  /** The raw config used to create the machine. */
  config: MachineConfig<TContext, TEvent, any, any, any, any, any, any, TOutput, any // TEmitted
  , any // TStateMeta
  , any> & {
    schemas?: unknown;
  };
  /** The machine's own version. */
  version?: string;
  schemas: unknown;
  implementations: MachineImplementationsSimplified<TContext, TEvent>;
  /** Runtime options for machine execution. */
  options: MachineOptions;
  root: StateNode<TContext, TEvent, TStateMeta, TTransitionMeta>;
  id: string;
  states: StateNode<TContext, TEvent, TStateMeta, TTransitionMeta>['states'];
  events: Array<EventDescriptor<TEvent>>;
  constructor(
  /** The raw config used to create the machine. */
  config: MachineConfig<TContext, TEvent, any, any, any, any, any, any, TOutput, any // TEmitted
  , any // TStateMeta
  , any> & {
    schemas?: unknown;
  }, implementations?: MachineImplementationsSimplified<TContext, TEvent>);
  /**
   * Clones this state machine with the provided implementations.
   *
   * @param implementations Options (`actions`, `guards`, `actors`, `delays`) to
   *   recursively merge with the existing options.
   * @returns A new `StateMachine` instance with the provided implementations.
   */
  provide(implementations: InternalMachineImplementations<ResolvedStateMachineTypes<TContext, DoNotInfer<TEvent>, TActor, TAction, TGuard, TDelay, TTag, TEmitted>>): StateMachine<TContext, TEvent, TChildren, TActor, TAction, TGuard, TDelay, TStateValue, TTag, TInput, TOutput, TEmitted, TStateMeta, TStateSchema, TTransitionMeta>;
  resolveState(config: {
    value: StateValue;
    context?: TContext;
    historyValue?: HistoryValue<TContext, TEvent>;
    status?: SnapshotStatus;
    output?: TOutput;
    error?: unknown;
  } & (Equals<TContext, MachineContext> extends false ? {
    context: unknown;
  } : {})): MachineSnapshot<TContext, TEvent, TChildren, TStateValue, TTag, TOutput, TStateMeta, TStateSchema>;
  /**
   * Determines the next snapshot given the current `snapshot` and received
   * `event`. Calculates a full macrostep from all microsteps.
   *
   * @param snapshot The current snapshot
   * @param event The received event
   */
  transition(snapshot: MachineSnapshot<TContext, TEvent, TChildren, TStateValue, TTag, TOutput, TStateMeta, TStateSchema>, event: TEvent, actorScope: ActorScope<typeof snapshot, TEvent, AnyActorSystem, TEmitted>): MachineSnapshot<TContext, TEvent, TChildren, TStateValue, TTag, TOutput, TStateMeta, TStateSchema>;
  /**
   * Determines the next state given the current `state` and `event`. Calculates
   * a microstep.
   *
   * @param state The current state
   * @param event The received event
   */
  microstep(snapshot: MachineSnapshot<TContext, TEvent, TChildren, TStateValue, TTag, TOutput, TStateMeta, TStateSchema>, event: TEvent, actorScope: AnyActorScope): Array<MachineSnapshot<TContext, TEvent, TChildren, TStateValue, TTag, TOutput, TStateMeta, TStateSchema>>;
  getTransitionData(snapshot: MachineSnapshot<TContext, TEvent, TChildren, TStateValue, TTag, TOutput, TStateMeta, TStateSchema>, event: TEvent): Array<TransitionDefinition<TContext, TEvent, TTransitionMeta>>;
  /**
   * Returns the initial `State` instance, with reference to `self` as an
   * `ActorRef`.
   */
  getInitialSnapshot(actorScope: ActorScope<MachineSnapshot<TContext, TEvent, TChildren, TStateValue, TTag, TOutput, TStateMeta, TStateSchema>, TEvent, AnyActorSystem, TEmitted>, input?: TInput): MachineSnapshot<TContext, TEvent, TChildren, TStateValue, TTag, TOutput, TStateMeta, TStateSchema>;
  start(snapshot: MachineSnapshot<TContext, TEvent, TChildren, TStateValue, TTag, TOutput, TStateMeta, TStateSchema>): void;
  getStateNodeById(stateId: string): StateNode<TContext, TEvent, TStateMeta, TTransitionMeta>;
  get definition(): StateMachineDefinition<TContext, TEvent, TStateMeta, TTransitionMeta>;
  toJSON(): StateMachineDefinition<TContext, TEvent, TStateMeta, TTransitionMeta>;
  getPersistedSnapshot(snapshot: MachineSnapshot<TContext, TEvent, TChildren, TStateValue, TTag, TOutput, TStateMeta, TStateSchema>, options?: unknown): Snapshot$1<unknown>;
  restoreSnapshot(snapshot: Snapshot$1<unknown>, _actorScope: ActorScope<MachineSnapshot<TContext, TEvent, TChildren, TStateValue, TTag, TOutput, TStateMeta, TStateSchema>, TEvent, AnyActorSystem, TEmitted>): MachineSnapshot<TContext, TEvent, TChildren, TStateValue, TTag, TOutput, TStateMeta, TStateSchema>;
}
//#endregion
//#region ../../node_modules/.pnpm/xstate@5.33.2/node_modules/xstate/dist/declarations/src/StateNode.d.ts
interface StateNodeOptions<TContext extends MachineContext, TEvent extends EventObject, TStateMeta extends MetaObject, TTransitionMeta extends MetaObject> {
  _key: string;
  _parent?: StateNode<TContext, TEvent, TStateMeta, TTransitionMeta>;
  _machine: AnyStateMachine;
}
declare class StateNode<TContext extends MachineContext = MachineContext, TEvent extends EventObject = EventObject, TStateMeta extends MetaObject = MetaObject, TTransitionMeta extends MetaObject = TStateMeta> {
  /** The raw config used to create the machine. */
  config: StateNodeConfig<TContext, TEvent, TODO // actors
  , TODO // actions
  , TODO // guards
  , TODO // delays
  , TODO // tags
  , TODO // output
  , TODO // emitted
  , TStateMeta, TTransitionMeta>;
  /**
   * The relative key of the state node, which represents its location in the
   * overall state value.
   */
  key: string;
  /** The unique ID of the state node. */
  id: string;
  /**
   * The type of this state node:
   *
   * - `'atomic'` - no child state nodes
   * - `'compound'` - nested child state nodes (XOR)
   * - `'parallel'` - orthogonal nested child state nodes (AND)
   * - `'history'` - history state node
   * - `'final'` - final state node
   */
  type: 'atomic' | 'compound' | 'parallel' | 'final' | 'history';
  /** The string path from the root machine node to this node. */
  path: string[];
  /** The child state nodes. */
  states: StateNodesConfig<TContext, TEvent, TStateMeta, TTransitionMeta>;
  /**
   * The type of history on this state node. Can be:
   *
   * - `'shallow'` - recalls only top-level historical state value
   * - `'deep'` - recalls historical state value at all levels
   */
  history: false | 'shallow' | 'deep';
  /** The action(s) to be executed upon entering the state node. */
  entry: UnknownAction[];
  /** The action(s) to be executed upon exiting the state node. */
  exit: UnknownAction[];
  /** The parent state node. */
  parent?: StateNode<TContext, TEvent, TStateMeta, TTransitionMeta>;
  /** The root machine node. */
  machine: StateMachine<TContext, TEvent, any // children
  , any // actor
  , any // action
  , any // guard
  , any // delay
  , any // state value
  , any // tag
  , any // input
  , any // output
  , any // emitted
  , TStateMeta, any // state schema
  , TTransitionMeta>;
  /**
   * The meta data associated with this state node, which will be returned in
   * State instances.
   */
  meta?: TStateMeta;
  /**
   * The output data sent with the "xstate.done.state._id_" event if this is a
   * final state node.
   */
  output?: Mapper<MachineContext, EventObject, unknown, EventObject> | NonReducibleUnknown;
  /**
   * The order this state node appears. Corresponds to the implicit document
   * order.
   */
  order: number;
  description?: string;
  tags: string[];
  transitions: Map<string, TransitionDefinition<TContext, TEvent, TTransitionMeta>[]>;
  always?: Array<TransitionDefinition<TContext, TEvent, TTransitionMeta>>;
  constructor(
  /** The raw config used to create the machine. */
  config: StateNodeConfig<TContext, TEvent, TODO // actors
  , TODO // actions
  , TODO // guards
  , TODO // delays
  , TODO // tags
  , TODO // output
  , TODO // emitted
  , TStateMeta, TTransitionMeta>, options: StateNodeOptions<TContext, TEvent, TStateMeta, TTransitionMeta>);
  /** The well-structured state node definition. */
  get definition(): StateNodeDefinition<TContext, TEvent, TStateMeta, TTransitionMeta>;
  /** The logic invoked as actors by this state node. */
  get invoke(): Array<InvokeDefinition<TContext, TEvent, ProvidedActor, ParameterizedObject, ParameterizedObject, string, TODO // TEmitted
  , TTransitionMeta>>;
  /** The mapping of events to transitions. */
  get on(): TransitionDefinitionMap<TContext, TEvent, TTransitionMeta>;
  get after(): Array<DelayedTransitionDefinition<TContext, TEvent, TTransitionMeta>>;
  get initial(): InitialTransitionDefinition<TContext, TEvent, TTransitionMeta>;
  /** All the event types accepted by this state node and its descendants. */
  get events(): Array<EventDescriptor<TEvent>>;
  /**
   * All the events that have transitions directly from this state node.
   *
   * Excludes any inert events.
   */
  get ownEvents(): Array<EventDescriptor<TEvent>>;
}
//#endregion
//#region ../../node_modules/.pnpm/xstate@5.33.2/node_modules/xstate/dist/declarations/src/State.d.ts
type ToTestStateValue<TStateValue extends StateValue> = TStateValue extends string ? TStateValue : IsNever<keyof TStateValue> extends true ? never : keyof TStateValue | { [K in keyof TStateValue]?: ToTestStateValue<NonNullable<TStateValue[K]>>; };
interface MachineSnapshotBase<TContext extends MachineContext, TEvent extends EventObject, TChildren extends Record<string, AnyActorRef | undefined>, TStateValue extends StateValue, TTag extends string, TOutput, TMeta, TStateSchema extends StateSchema = StateSchema> {
  /** The state machine that produced this state snapshot. */
  machine: StateMachine<TContext, TEvent, TChildren, ProvidedActor, ParameterizedObject, ParameterizedObject, string, TStateValue, TTag, unknown, TOutput, EventObject // TEmitted
  , any // TMeta
  , TStateSchema>;
  /** The tags of the active state nodes that represent the current state value. */
  tags: Set<string>;
  /**
   * The current state value.
   *
   * This represents the active state nodes in the state machine.
   *
   * - For atomic state nodes, it is a string.
   * - For compound parent state nodes, it is an object where:
   *
   *   - The key is the parent state node's key
   *   - The value is the current state value of the active child state node(s)
   *
   * @example
   *
   * ```ts
   * // single-level state node
   * snapshot.value; // => 'yellow'
   *
   * // nested state nodes
   * snapshot.value; // => { red: 'wait' }
   * ```
   */
  value: TStateValue;
  /** The current status of this snapshot. */
  status: SnapshotStatus;
  error: unknown;
  context: TContext;
  historyValue: Readonly<HistoryValue<TContext, TEvent>>;
  /** The enabled state nodes representative of the state value. */
  _nodes: Array<StateNode<TContext, TEvent, any, any>>;
  /** An object mapping actor names to spawned/invoked actors. */
  children: TChildren;
  /**
   * Whether the current state value is a subset of the given partial state
   * value.
   *
   * @param partialStateValue
   */
  matches: (partialStateValue: ToTestStateValue<TStateValue>) => boolean;
  /**
   * Whether the current state nodes has a state node with the specified `tag`.
   *
   * @param tag
   */
  hasTag: (tag: TTag) => boolean;
  /**
   * Determines whether sending the `event` will cause a non-forbidden
   * transition to be selected, even if the transitions have no actions nor
   * change the state value.
   *
   * @param event The event to test
   * @returns Whether the event will cause a transition
   */
  can: (event: TEvent) => boolean;
  getMeta: () => Record<StateId<TStateSchema> & string, TMeta | undefined>;
  toJSON: () => unknown;
}
interface ActiveMachineSnapshot<TContext extends MachineContext, TEvent extends EventObject, TChildren extends Record<string, AnyActorRef | undefined>, TStateValue extends StateValue, TTag extends string, TOutput, TMeta extends MetaObject, TStateSchema extends StateSchema> extends MachineSnapshotBase<TContext, TEvent, TChildren, TStateValue, TTag, TOutput, TMeta, TStateSchema> {
  status: 'active';
  output: undefined;
  error: undefined;
}
interface DoneMachineSnapshot<TContext extends MachineContext, TEvent extends EventObject, TChildren extends Record<string, AnyActorRef | undefined>, TStateValue extends StateValue, TTag extends string, TOutput, TMeta extends MetaObject, TStateSchema extends StateSchema> extends MachineSnapshotBase<TContext, TEvent, TChildren, TStateValue, TTag, TOutput, TMeta, TStateSchema> {
  status: 'done';
  output: TOutput;
  error: undefined;
}
interface ErrorMachineSnapshot<TContext extends MachineContext, TEvent extends EventObject, TChildren extends Record<string, AnyActorRef | undefined>, TStateValue extends StateValue, TTag extends string, TOutput, TMeta extends MetaObject, TStateSchema extends StateSchema> extends MachineSnapshotBase<TContext, TEvent, TChildren, TStateValue, TTag, TOutput, TMeta, TStateSchema> {
  status: 'error';
  output: undefined;
  error: unknown;
}
interface StoppedMachineSnapshot<TContext extends MachineContext, TEvent extends EventObject, TChildren extends Record<string, AnyActorRef | undefined>, TStateValue extends StateValue, TTag extends string, TOutput, TMeta extends MetaObject, TStateSchema extends StateSchema> extends MachineSnapshotBase<TContext, TEvent, TChildren, TStateValue, TTag, TOutput, TMeta, TStateSchema> {
  status: 'stopped';
  output: undefined;
  error: undefined;
}
type MachineSnapshot<TContext extends MachineContext, TEvent extends EventObject, TChildren extends Record<string, AnyActorRef | undefined>, TStateValue extends StateValue, TTag extends string, TOutput, TMeta extends MetaObject, TStateSchema extends StateSchema> = ActiveMachineSnapshot<TContext, TEvent, TChildren, TStateValue, TTag, TOutput, TMeta, TStateSchema> | DoneMachineSnapshot<TContext, TEvent, TChildren, TStateValue, TTag, TOutput, TMeta, TStateSchema> | ErrorMachineSnapshot<TContext, TEvent, TChildren, TStateValue, TTag, TOutput, TMeta, TStateSchema> | StoppedMachineSnapshot<TContext, TEvent, TChildren, TStateValue, TTag, TOutput, TMeta, TStateSchema>;
//#endregion
//#region ../../node_modules/.pnpm/xstate@5.33.2/node_modules/xstate/dist/declarations/src/actors/promise.d.ts
type PromiseSnapshot<TOutput, TInput> = Snapshot$1<TOutput> & {
  input: TInput | undefined;
};
type PromiseActorLogic<TOutput, TInput = unknown, TEmitted extends EventObject = EventObject> = ActorLogic<PromiseSnapshot<TOutput, TInput>, {
  type: string;
  [k: string]: unknown;
}, TInput // input
, AnyActorSystem, TEmitted>;
//#endregion
//#region ../../node_modules/.pnpm/xstate@5.33.2/node_modules/xstate/dist/declarations/src/symbolObservable.d.ts
declare const symbolObservable: typeof Symbol.observable;
//#endregion
//#region ../../node_modules/.pnpm/xstate@5.33.2/node_modules/xstate/dist/declarations/src/createActor.d.ts
/**
 * An Actor is a running process that can receive events, send events and change
 * its behavior based on the events it receives, which can cause effects outside
 * of the actor. When you run a state machine, it becomes an actor.
 */
declare class Actor<TLogic extends AnyActorLogic> implements ActorRef<SnapshotFrom<TLogic>, EventFromLogic<TLogic>, EmittedFrom<TLogic>> {
  logic: TLogic;
  /** The current internal state of the actor. */
  private _snapshot;
  /**
   * The clock that is responsible for setting and clearing timeouts, such as
   * delayed events and transitions.
   */
  clock: Clock;
  options: Readonly<ActorOptions<TLogic>>;
  /** The unique identifier for this actor relative to its parent. */
  id: string;
  private mailbox;
  private observers;
  private eventListeners;
  private logger;
  _parent?: AnyActorRef;
  ref: ActorRef<SnapshotFrom<TLogic>, EventFromLogic<TLogic>, EmittedFrom<TLogic>>;
  private _actorScope;
  systemId: string | undefined;
  /** The globally unique process ID for this invocation. */
  sessionId: string;
  /** The system to which this actor belongs. */
  system: AnyActorSystem;
  private _doneEvent?;
  src: string | AnyActorLogic;
  /**
   * Creates a new actor instance for the given logic with the provided options,
   * if any.
   *
   * @param logic The logic to create an actor from
   * @param options Actor options
   */
  constructor(logic: TLogic, options?: ActorOptions<TLogic>);
  private _initState;
  private _deferred;
  private update;
  /**
   * Subscribe an observer to an actor’s snapshot values.
   *
   * @remarks
   * The observer will receive the actor’s snapshot value when it is emitted.
   * The observer can be:
   *
   * - A plain function that receives the latest snapshot, or
   * - An observer object whose `.next(snapshot)` method receives the latest
   *   snapshot
   *
   * @example
   *
   * ```ts
   * // Observer as a plain function
   * const subscription = actor.subscribe((snapshot) => {
   *   console.log(snapshot);
   * });
   * ```
   *
   * @example
   *
   * ```ts
   * // Observer as an object
   * const subscription = actor.subscribe({
   *   next(snapshot) {
   *     console.log(snapshot);
   *   },
   *   error(err) {
   *     // ...
   *   },
   *   complete() {
   *     // ...
   *   }
   * });
   * ```
   *
   * The return value of `actor.subscribe(observer)` is a subscription object
   * that has an `.unsubscribe()` method. You can call
   * `subscription.unsubscribe()` to unsubscribe the observer:
   *
   * @example
   *
   * ```ts
   * const subscription = actor.subscribe((snapshot) => {
   *   // ...
   * });
   *
   * // Unsubscribe the observer
   * subscription.unsubscribe();
   * ```
   *
   * When the actor is stopped, all of its observers will automatically be
   * unsubscribed.
   *
   * @param observer - Either a plain function that receives the latest
   *   snapshot, or an observer object whose `.next(snapshot)` method receives
   *   the latest snapshot
   */
  subscribe(observer: Observer<SnapshotFrom<TLogic>>): Subscription;
  subscribe(nextListener?: (snapshot: SnapshotFrom<TLogic>) => void, errorListener?: (error: any) => void, completeListener?: () => void): Subscription;
  on<TType extends EmittedFrom<TLogic>['type'] | '*'>(type: TType, handler: (emitted: EmittedFrom<TLogic> & (TType extends '*' ? unknown : {
    type: TType;
  })) => void): Subscription;
  select<TSelected>(selector: (snapshot: SnapshotFrom<TLogic>) => TSelected, equalityFn?: (a: TSelected, b: TSelected) => boolean): Readable<TSelected>;
  /** Starts the Actor from the initial state */
  start(): this;
  private _process;
  private _stop;
  /** Stops the Actor and unsubscribe all listeners. */
  stop(): this;
  private _complete;
  private _reportError;
  private _error;
  private _stopProcedure;
  /**
   * Sends an event to the running Actor to trigger a transition.
   *
   * @param event The event to send
   */
  send(event: EventFromLogic<TLogic>): void;
  private attachDevTools;
  toJSON(): {
    xstate$$type: number;
    id: string;
  };
  /**
   * Obtain the internal state of the actor, which can be persisted.
   *
   * @remarks
   * The internal state can be persisted from any actor, not only machines.
   *
   * Note that the persisted state is not the same as the snapshot from
   * {@link Actor.getSnapshot}. Persisted state represents the internal state of
   * the actor, while snapshots represent the actor's last emitted value.
   *
   * Can be restored with {@link ActorOptions.state}
   * @see https://stately.ai/docs/persistence
   */
  getPersistedSnapshot(): Snapshot$1<unknown>;
  [symbolObservable](): InteropSubscribable<SnapshotFrom<TLogic>>;
  /**
   * Read an actor’s snapshot synchronously.
   *
   * @remarks
   * The snapshot represent an actor's last emitted value.
   *
   * When an actor receives an event, its internal state may change. An actor
   * may emit a snapshot when a state transition occurs.
   *
   * Note that some actors, such as callback actors generated with
   * `fromCallback`, will not emit snapshots.
   * @see {@link Actor.subscribe} to subscribe to an actor’s snapshot values.
   * @see {@link Actor.getPersistedSnapshot} to persist the internal state of an actor (which is more than just a snapshot).
   */
  getSnapshot(): SnapshotFrom<TLogic>;
}
//#endregion
//#region ../../node_modules/.pnpm/xstate@5.33.2/node_modules/xstate/dist/declarations/src/guards.d.ts
type GuardPredicate<TContext extends MachineContext, TExpressionEvent extends EventObject, TParams extends ParameterizedObject['params'] | undefined, TGuard extends ParameterizedObject> = {
  (args: GuardArgs<TContext, TExpressionEvent>, params: TParams): boolean;
  _out_TGuard?: TGuard;
};
interface GuardArgs<TContext extends MachineContext, TExpressionEvent extends EventObject> {
  context: TContext;
  event: TExpressionEvent;
}
type Guard<TContext extends MachineContext, TExpressionEvent extends EventObject, TParams extends ParameterizedObject['params'] | undefined, TGuard extends ParameterizedObject> = NoRequiredParams<TGuard> | WithDynamicParams<TContext, TExpressionEvent, TGuard> | GuardPredicate<TContext, TExpressionEvent, TParams, TGuard>;
type UnknownGuard = UnknownReferencedGuard | UnknownInlineGuard;
type UnknownReferencedGuard = Guard<MachineContext, EventObject, ParameterizedObject['params'], ParameterizedObject>;
type UnknownInlineGuard = Guard<MachineContext, EventObject, undefined, ParameterizedObject>;
//#endregion
//#region ../../node_modules/.pnpm/xstate@5.33.2/node_modules/xstate/dist/declarations/src/types.d.ts
type GetParameterizedParams<T extends ParameterizedObject | undefined> = T extends any ? ('params' extends keyof T ? T['params'] : undefined) : never;
/**
 * @remarks
 * `T | unknown` reduces to `unknown` and that can be problematic when it comes
 * to contextual typing. It especially is a problem when the union has a
 * function member, like here:
 *
 * ```ts
 * declare function test(
 *   cbOrVal: ((arg: number) => unknown) | unknown
 * ): void;
 * test((arg) => {}); // oops, implicit any
 * ```
 *
 * This type can be used to avoid this problem. This union represents the same
 * value space as `unknown`.
 */
type NonReducibleUnknown = {} | null | undefined;
type AnyFunction = (...args: any[]) => any;
type ReturnTypeOrValue<T> = T extends AnyFunction ? ReturnType<T> : T;
type IsNever<T> = [T] extends [never] ? true : false;
type IsNotNever<T> = [T] extends [never] ? false : true;
type Compute<A> = { [K in keyof A]: A[K]; } & unknown;
type Values<T> = T[keyof T];
type Equals<A1, A2> = (<A>() => A extends A2 ? true : false) extends (<A>() => A extends A1 ? true : false) ? true : false;
type DoNotInfer<T> = [T][T extends any ? 0 : any];
type LowInfer<T> = T & NonNullable<unknown>;
type MetaObject = Record<string, any>;
/** The full definition of an event, with a string `type`. */
type EventObject = {
  /** The type of event that is sent. */
  type: string;
};
interface AnyEventObject extends EventObject {
  [key: string]: any;
}
interface ParameterizedObject {
  type: string;
  params?: NonReducibleUnknown;
}
interface UnifiedArg<TContext extends MachineContext, TExpressionEvent extends EventObject, TEvent extends EventObject> {
  context: TContext;
  event: TExpressionEvent;
  self: ActorRef<MachineSnapshot<TContext, TEvent, Record<string, AnyActorRef | undefined> // TODO: this should be replaced with `TChildren`
  , StateValue, string, unknown, TODO // TMeta
  , TODO>, TEvent, AnyEventObject>;
  system: AnyActorSystem;
}
type MachineContext = Record<string, any>;
interface ActionArgs<TContext extends MachineContext, TExpressionEvent extends EventObject, TEvent extends EventObject> extends UnifiedArg<TContext, TExpressionEvent, TEvent> {}
type InputFrom<T> = T extends StateMachine<infer _TContext, infer _TEvent, infer _TChildren, infer _TActor, infer _TAction, infer _TGuard, infer _TDelay, infer _TStateValue, infer _TTag, infer TInput, infer _TOutput, infer _TEmitted, infer _TMeta, infer _TStateSchema, infer _TTransitionMeta> ? TInput : T extends ActorLogic<infer _TSnapshot, infer _TEvent, infer TInput, infer _TSystem, infer _TEmitted> ? TInput : never;
type OutputFrom<T> = T extends ActorLogic<infer TSnapshot, infer _TEvent, infer _TInput, infer _TSystem, infer _TEmitted> ? (TSnapshot & {
  status: 'done';
})['output'] : T extends ActorRef<infer TSnapshot, infer _TEvent, infer _TEmitted> ? (TSnapshot & {
  status: 'done';
})['output'] : never;
type ActionFunction<TContext extends MachineContext, TExpressionEvent extends EventObject, TEvent extends EventObject, TParams extends ParameterizedObject['params'] | undefined, TActor extends ProvidedActor, TAction extends ParameterizedObject, TGuard extends ParameterizedObject, TDelay extends string, TEmitted extends EventObject> = {
  (args: ActionArgs<TContext, TExpressionEvent, TEvent>, params: TParams): void;
  _out_TEvent?: TEvent;
  _out_TActor?: TActor;
  _out_TAction?: TAction;
  _out_TGuard?: TGuard;
  _out_TDelay?: TDelay;
  _out_TEmitted?: TEmitted;
};
type NoRequiredParams<T extends ParameterizedObject> = T extends any ? undefined extends T['params'] ? T['type'] : never : never;
type ConditionalRequired<T, Condition extends boolean> = Condition extends true ? Required<T> : T;
type WithDynamicParams<TContext extends MachineContext, TExpressionEvent extends EventObject, T extends ParameterizedObject> = T extends any ? ConditionalRequired<{
  type: T['type'];
  params?: T['params'] | (({ context, event }: {
    context: TContext;
    event: TExpressionEvent;
  }) => T['params']);
}, undefined extends T['params'] ? false : true> : never;
type Action<TContext extends MachineContext, TExpressionEvent extends EventObject, TEvent extends EventObject, TParams extends ParameterizedObject['params'] | undefined, TActor extends ProvidedActor, TAction extends ParameterizedObject, TGuard extends ParameterizedObject, TDelay extends string, TEmitted extends EventObject> = NoRequiredParams<TAction> | WithDynamicParams<TContext, TExpressionEvent, TAction> | ActionFunction<TContext, TExpressionEvent, TEvent, TParams, TActor, TAction, TGuard, TDelay, TEmitted>;
type UnknownAction = Action<MachineContext, EventObject, EventObject, ParameterizedObject['params'] | undefined, ProvidedActor, ParameterizedObject, ParameterizedObject, string, EventObject>;
type Actions<TContext extends MachineContext, TExpressionEvent extends EventObject, TEvent extends EventObject, TParams extends ParameterizedObject['params'] | undefined, TActor extends ProvidedActor, TAction extends ParameterizedObject, TGuard extends ParameterizedObject, TDelay extends string, TEmitted extends EventObject> = SingleOrArray<Action<TContext, TExpressionEvent, TEvent, TParams, TActor, TAction, TGuard, TDelay, TEmitted>>;
interface StateValueMap {
  [key: string]: StateValue | undefined;
}
/**
 * The string or object representing the state value relative to the parent
 * state node.
 *
 * @remarks
 * - For a child atomic state node, this is a string, e.g., `"pending"`.
 * - For complex state nodes, this is an object, e.g., `{ success:
 *   "someChildState" }`.
 */
type StateValue = string | StateValueMap;
type TransitionTarget = SingleOrArray<string>;
interface TransitionConfig<TContext extends MachineContext, TExpressionEvent extends EventObject, TEvent extends EventObject, TActor extends ProvidedActor, TAction extends ParameterizedObject, TGuard extends ParameterizedObject, TDelay extends string, TEmitted extends EventObject = EventObject, TMeta extends MetaObject = MetaObject> {
  guard?: Guard<TContext, TExpressionEvent, undefined, TGuard>;
  actions?: Actions<TContext, TExpressionEvent, TEvent, undefined, TActor, TAction, TGuard, TDelay, TEmitted>;
  reenter?: boolean;
  target?: TransitionTarget | undefined;
  meta?: TMeta;
  description?: string;
}
interface InitialTransitionConfig<TContext extends MachineContext, TEvent extends EventObject, TActor extends ProvidedActor, TAction extends ParameterizedObject, TGuard extends ParameterizedObject, TDelay extends string, TEmitted extends EventObject = EventObject, TTransitionMeta extends MetaObject = MetaObject> extends TransitionConfig<TContext, TEvent, TEvent, TActor, TAction, TGuard, TDelay, TEmitted, TTransitionMeta> {
  target: string;
}
interface InvokeDefinition<TContext extends MachineContext, TEvent extends EventObject, TActor extends ProvidedActor, TAction extends ParameterizedObject, TGuard extends ParameterizedObject, TDelay extends string, TEmitted extends EventObject, TTransitionMeta extends MetaObject> {
  id: string;
  systemId: string | undefined;
  /** The source of the actor logic to be invoked */
  src: AnyActorLogic | string;
  input?: Mapper<TContext, TEvent, NonReducibleUnknown, TEvent> | NonReducibleUnknown;
  /**
   * The transition to take upon the invoked child machine reaching its final
   * top-level state.
   */
  onDone?: string | SingleOrArray<TransitionConfig<TContext, DoneActorEvent<unknown>, TEvent, TActor, TAction, TGuard, TDelay, TEmitted, TTransitionMeta>>;
  /**
   * The transition to take upon the invoked child machine sending an error
   * event.
   */
  onError?: string | SingleOrArray<TransitionConfig<TContext, ErrorActorEvent, TEvent, TActor, TAction, TGuard, TDelay, TEmitted, TTransitionMeta>>;
  onSnapshot?: string | SingleOrArray<TransitionConfig<TContext, SnapshotEvent, TEvent, TActor, TAction, TGuard, TDelay, TEmitted, TTransitionMeta>>;
  toJSON: () => Omit<InvokeDefinition<TContext, TEvent, TActor, TAction, TGuard, TDelay, TEmitted, TTransitionMeta>, 'onDone' | 'onError' | 'toJSON'>;
}
type Delay<TDelay extends string> = TDelay | number;
type DelayedTransitions<TContext extends MachineContext, TEvent extends EventObject, TActor extends ProvidedActor, TAction extends ParameterizedObject, TGuard extends ParameterizedObject, TDelay extends string, TEmitted extends EventObject = EventObject, TTransitionMeta extends MetaObject = MetaObject> = { [K in Delay<TDelay>]?: string | SingleOrArray<TransitionConfig<TContext, TEvent, TEvent, TActor, TAction, TGuard, TDelay, TEmitted, TTransitionMeta>>; };
type SingleOrArray<T> = readonly T[] | T;
type StateNodesConfig<TContext extends MachineContext, TEvent extends EventObject, TStateMeta extends MetaObject = MetaObject, TTransitionMeta extends MetaObject = TStateMeta> = { [K in string]: StateNode<TContext, TEvent, TStateMeta, TTransitionMeta>; };
type StatesConfig<TContext extends MachineContext, TEvent extends EventObject, TActor extends ProvidedActor, TAction extends ParameterizedObject, TGuard extends ParameterizedObject, TDelay extends string, TTag extends string, TOutput, TEmitted extends EventObject, TStateMeta extends MetaObject, TTransitionMeta extends MetaObject = TStateMeta> = { [K in string]: StateNodeConfig<TContext, TEvent, TActor, TAction, TGuard, TDelay, TTag, TOutput, TEmitted, TStateMeta, TTransitionMeta>; };
type StatesDefinition<TContext extends MachineContext, TEvent extends EventObject, TStateMeta extends MetaObject = MetaObject, TTransitionMeta extends MetaObject = TStateMeta> = { [K in string]: StateNodeDefinition<TContext, TEvent, TStateMeta, TTransitionMeta>; };
type TransitionConfigTarget = string | undefined;
type TransitionConfigOrTarget<TContext extends MachineContext, TExpressionEvent extends EventObject, TEvent extends EventObject, TActor extends ProvidedActor, TAction extends ParameterizedObject, TGuard extends ParameterizedObject, TDelay extends string, TEmitted extends EventObject, TTransitionMeta extends MetaObject> = SingleOrArray<TransitionConfigTarget | TransitionConfig<TContext, TExpressionEvent, TEvent, TActor, TAction, TGuard, TDelay, TEmitted, TTransitionMeta>>;
type TransitionsConfig<TContext extends MachineContext, TEvent extends EventObject, TActor extends ProvidedActor, TAction extends ParameterizedObject, TGuard extends ParameterizedObject, TDelay extends string, TEmitted extends EventObject, TTransitionMeta extends MetaObject> = { [K in EventDescriptor<TEvent>]?: TransitionConfigOrTarget<TContext, ExtractEvent<TEvent, K>, TEvent, TActor, TAction, TGuard, TDelay, TEmitted, TTransitionMeta>; };
type PartialEventDescriptor<TEventType extends string> = TEventType extends `${infer TLeading}.${infer TTail}` ? `${TLeading}.*` | `${TLeading}.${PartialEventDescriptor<TTail>}` : never;
type EventDescriptor<TEvent extends EventObject> = TEvent['type'] | PartialEventDescriptor<TEvent['type']> | '*';
type NormalizeDescriptor<TDescriptor extends string> = TDescriptor extends '*' ? string : TDescriptor extends `${infer TLeading}.*` ? `${TLeading}.${string}` : TDescriptor;
type IsLiteralString<T extends string> = string extends T ? false : true;
type DistributeActors<TContext extends MachineContext, TEvent extends EventObject, TActor extends ProvidedActor, TAction extends ParameterizedObject, TGuard extends ParameterizedObject, TDelay extends string, TEmitted extends EventObject, TTransitionMeta extends MetaObject, TSpecificActor extends ProvidedActor> = TSpecificActor extends {
  src: infer TSrc;
} ? Compute<{
  systemId?: string;
  /** The source of the machine to be invoked, or the machine itself. */
  src: TSrc;
  /**
   * The unique identifier for the invoked machine. If not specified,
   * this will be the machine's own `id`, or the URL (from `src`).
   */
  id?: TSpecificActor['id'];
  input?: Mapper<TContext, TEvent, InputFrom<TSpecificActor['logic']>, TEvent> | InputFrom<TSpecificActor['logic']>;
  /**
   * The transition to take upon the invoked child machine reaching
   * its final top-level state.
   */
  onDone?: string | SingleOrArray<TransitionConfigOrTarget<TContext, DoneActorEvent<OutputFrom<TSpecificActor['logic']>>, TEvent, TActor, TAction, TGuard, TDelay, TEmitted, TTransitionMeta>>;
  /**
   * The transition to take upon the invoked child machine sending an
   * error event.
   */
  onError?: string | SingleOrArray<TransitionConfigOrTarget<TContext, ErrorActorEvent, TEvent, TActor, TAction, TGuard, TDelay, TEmitted, TTransitionMeta>>;
  onSnapshot?: string | SingleOrArray<TransitionConfigOrTarget<TContext, SnapshotEvent<SnapshotFrom<TSpecificActor['logic']>>, TEvent, TActor, TAction, TGuard, TDelay, TEmitted, TTransitionMeta>>;
} & { [K in RequiredActorOptions<TSpecificActor>]: unknown; }> | {
  id?: never;
  systemId?: string;
  src: AnyActorLogic;
  input?: Mapper<TContext, TEvent, NonReducibleUnknown, TEvent> | NonReducibleUnknown;
  onDone?: string | SingleOrArray<TransitionConfigOrTarget<TContext, DoneActorEvent<unknown>, TEvent, TActor, TAction, TGuard, TDelay, TEmitted, TTransitionMeta>>;
  onError?: string | SingleOrArray<TransitionConfigOrTarget<TContext, ErrorActorEvent, TEvent, TActor, TAction, TGuard, TDelay, TEmitted, TTransitionMeta>>;
  onSnapshot?: string | SingleOrArray<TransitionConfigOrTarget<TContext, SnapshotEvent, TEvent, TActor, TAction, TGuard, TDelay, TEmitted, TTransitionMeta>>;
} : never;
type InvokeConfig<TContext extends MachineContext, TEvent extends EventObject, TActor extends ProvidedActor, TAction extends ParameterizedObject, TGuard extends ParameterizedObject, TDelay extends string, TEmitted extends EventObject, TTransitionMeta extends MetaObject> = IsLiteralString<TActor['src']> extends true ? DistributeActors<TContext, TEvent, TActor, TAction, TGuard, TDelay, TEmitted, TTransitionMeta, TActor> : {
  /**
   * The unique identifier for the invoked machine. If not specified, this
   * will be the machine's own `id`, or the URL (from `src`).
   */
  id?: string;
  systemId?: string;
  /** The source of the machine to be invoked, or the machine itself. */
  src: AnyActorLogic | string;
  input?: Mapper<TContext, TEvent, NonReducibleUnknown, TEvent> | NonReducibleUnknown;
  /**
   * The transition to take upon the invoked child machine reaching its
   * final top-level state.
   */
  onDone?: string | SingleOrArray<TransitionConfigOrTarget<TContext, DoneActorEvent<any> // TODO: consider replacing with `unknown`
  , TEvent, TActor, TAction, TGuard, TDelay, TEmitted, TTransitionMeta>>;
  /**
   * The transition to take upon the invoked child machine sending an
   * error event.
   */
  onError?: string | SingleOrArray<TransitionConfigOrTarget<TContext, ErrorActorEvent, TEvent, TActor, TAction, TGuard, TDelay, TEmitted, TTransitionMeta>>;
  onSnapshot?: string | SingleOrArray<TransitionConfigOrTarget<TContext, SnapshotEvent, TEvent, TActor, TAction, TGuard, TDelay, TEmitted, TTransitionMeta>>;
};
interface StateNodeConfig<TContext extends MachineContext, TEvent extends EventObject, TActor extends ProvidedActor, TAction extends ParameterizedObject, TGuard extends ParameterizedObject, TDelay extends string, TTag extends string, _TOutput, TEmitted extends EventObject, TStateMeta extends MetaObject, TTransitionMeta extends MetaObject = TStateMeta> {
  /** The initial state transition. */
  initial?: InitialTransitionConfig<TContext, TEvent, TActor, TAction, TGuard, TDelay, TEmitted, TTransitionMeta> | string | undefined;
  /**
   * The type of this state node:
   *
   * - `'atomic'` - no child state nodes
   * - `'compound'` - nested child state nodes (XOR)
   * - `'parallel'` - orthogonal nested child state nodes (AND)
   * - `'history'` - history state node
   * - `'final'` - final state node
   */
  type?: 'atomic' | 'compound' | 'parallel' | 'final' | 'history';
  /**
   * Indicates whether the state node is a history state node, and what type of
   * history: shallow, deep, true (shallow), false (none), undefined (none)
   */
  history?: 'shallow' | 'deep' | boolean | undefined;
  /**
   * The mapping of state node keys to their state node configurations
   * (recursive).
   */
  states?: StatesConfig<TContext, TEvent, TActor, TAction, TGuard, TDelay, TTag, NonReducibleUnknown, TEmitted, TStateMeta, TTransitionMeta> | undefined;
  /**
   * The services to invoke upon entering this state node. These services will
   * be stopped upon exiting this state node.
   */
  invoke?: SingleOrArray<InvokeConfig<TContext, TEvent, TActor, TAction, TGuard, TDelay, TEmitted, TTransitionMeta>>;
  /** The mapping of event types to their potential transition(s). */
  on?: TransitionsConfig<TContext, TEvent, TActor, TAction, TGuard, TDelay, TEmitted, TTransitionMeta>;
  /** The action(s) to be executed upon entering the state node. */
  entry?: Actions<TContext, TEvent, TEvent, undefined, TActor, TAction, TGuard, TDelay, TEmitted>;
  /** The action(s) to be executed upon exiting the state node. */
  exit?: Actions<TContext, TEvent, TEvent, undefined, TActor, TAction, TGuard, TDelay, TEmitted>;
  /**
   * The potential transition(s) to be taken upon reaching a final child state
   * node.
   *
   * This is equivalent to defining a `[done(id)]` transition on this state
   * node's `on` property.
   */
  onDone?: string | SingleOrArray<TransitionConfig<TContext, DoneStateEvent, TEvent, TActor, TAction, TGuard, TDelay, TEmitted, TTransitionMeta>> | undefined;
  /**
   * The mapping (or array) of delays (in milliseconds) to their potential
   * transition(s). The delayed transitions are taken after the specified delay
   * in an interpreter.
   */
  after?: DelayedTransitions<TContext, TEvent, TActor, TAction, TGuard, TDelay, TEmitted, TTransitionMeta>;
  /**
   * An eventless transition that is always taken when this state node is
   * active.
   */
  always?: TransitionConfigOrTarget<TContext, TEvent, TEvent, TActor, TAction, TGuard, TDelay, TEmitted, TTransitionMeta>;
  parent?: StateNode<TContext, TEvent, TStateMeta, TTransitionMeta>;
  /**
   * The meta data associated with this state node, which will be returned in
   * State instances.
   */
  meta?: TStateMeta;
  /**
   * The output data sent with the "xstate.done.state._id_" event if this is a
   * final state node.
   *
   * The output data will be evaluated with the current `context` and placed on
   * the `.data` property of the event.
   */
  output?: Mapper<TContext, TEvent, unknown, TEvent> | NonReducibleUnknown;
  /**
   * The unique ID of the state node, which can be referenced as a transition
   * target via the `#id` syntax.
   */
  id?: string | undefined;
  /**
   * The order this state node appears. Corresponds to the implicit document
   * order.
   */
  order?: number;
  /**
   * The tags for this state node, which are accumulated into the `state.tags`
   * property.
   */
  tags?: SingleOrArray<TTag>;
  /** A text description of the state node */
  description?: string;
  /** A default target for a history state */
  target?: string | undefined;
  route?: RouteTransitionConfig<TContext, TEvent, TEvent, TActor, TAction, TGuard, TDelay, TEmitted, TTransitionMeta>;
}
interface RouteTransitionConfig<TContext extends MachineContext, TExpressionEvent extends EventObject, TEvent extends EventObject, TActor extends ProvidedActor, TAction extends ParameterizedObject, TGuard extends ParameterizedObject, TDelay extends string, TEmitted extends EventObject, TTransitionMeta extends MetaObject = MetaObject> {
  guard?: Guard<TContext, TExpressionEvent, undefined, TGuard>;
  actions?: Actions<TContext, TExpressionEvent, TEvent, undefined, TActor, TAction, TGuard, TDelay, TEmitted>;
  meta?: TTransitionMeta;
  description?: string;
}
interface StateNodeDefinition<TContext extends MachineContext, TEvent extends EventObject, TStateMeta extends MetaObject = MetaObject, TTransitionMeta extends MetaObject = TStateMeta> {
  id: string;
  version?: string | undefined;
  key: string;
  type: 'atomic' | 'compound' | 'parallel' | 'final' | 'history';
  initial: InitialTransitionDefinition<TContext, TEvent, TTransitionMeta> | undefined;
  history: boolean | 'shallow' | 'deep' | undefined;
  states: StatesDefinition<TContext, TEvent, TStateMeta, TTransitionMeta>;
  on: TransitionDefinitionMap<TContext, TEvent, TTransitionMeta>;
  transitions: Array<TransitionDefinition<TContext, TEvent, TTransitionMeta>>;
  entry: UnknownAction[];
  exit: UnknownAction[];
  meta: TStateMeta | undefined;
  order: number;
  output?: StateNodeConfig<TContext, TEvent, ProvidedActor, ParameterizedObject, ParameterizedObject, string, string, unknown, EventObject // TEmitted
  , any // TStateMeta
  , any>['output'];
  invoke: Array<InvokeDefinition<TContext, TEvent, TODO, TODO, TODO, TODO, TODO // TEmitted
  , TTransitionMeta>>;
  description?: string;
  tags: string[];
}
interface StateMachineDefinition<TContext extends MachineContext, TEvent extends EventObject, TStateMeta extends MetaObject = MetaObject, TTransitionMeta extends MetaObject = TStateMeta> extends StateNodeDefinition<TContext, TEvent, TStateMeta, TTransitionMeta> {}
type AnyStateMachine = StateMachine<any // context
, any // event
, any // children
, any // actor
, any // action
, any // guard
, any // delay
, any // state value
, any // tag
, any // input
, any // output
, any // emitted
, any // TMeta
, any // TStateSchema
, any>;
type ActionFunctionMap<TContext extends MachineContext, TEvent extends EventObject, TActor extends ProvidedActor, TAction extends ParameterizedObject = ParameterizedObject, TGuard extends ParameterizedObject = ParameterizedObject, TDelay extends string = string, TEmitted extends EventObject = EventObject> = { [K in TAction['type']]?: ActionFunction<TContext, TEvent, TEvent, GetParameterizedParams<TAction extends {
  type: K;
} ? TAction : never>, TActor, TAction, TGuard, TDelay, TEmitted>; };
type GuardMap<TContext extends MachineContext, TEvent extends EventObject, TGuard extends ParameterizedObject> = { [K in TGuard['type']]?: GuardPredicate<TContext, TEvent, GetParameterizedParams<TGuard extends {
  type: K;
} ? TGuard : never>, TGuard>; };
type DelayFunctionMap<TContext extends MachineContext, TEvent extends EventObject, TAction extends ParameterizedObject> = Record<string, DelayConfig<TContext, TEvent, TAction['params'], TEvent>>;
type DelayConfig<TContext extends MachineContext, TExpressionEvent extends EventObject, TParams extends ParameterizedObject['params'] | undefined, TEvent extends EventObject> = number | DelayExpr<TContext, TExpressionEvent, TParams, TEvent>;
/** @ignore */
interface MachineImplementationsSimplified<TContext extends MachineContext, TEvent extends EventObject, TActor extends ProvidedActor = ProvidedActor, TAction extends ParameterizedObject = ParameterizedObject, TGuard extends ParameterizedObject = ParameterizedObject> {
  guards: GuardMap<TContext, TEvent, TGuard>;
  actions: ActionFunctionMap<TContext, TEvent, TActor, TAction>;
  actors: Record<string, AnyActorLogic | {
    src: AnyActorLogic;
    input: Mapper<TContext, TEvent, unknown, TEvent> | NonReducibleUnknown;
  }>;
  delays: DelayFunctionMap<TContext, TEvent, TAction>;
}
type MachineImplementationsActions<TTypes extends StateMachineTypes> = { [K in TTypes['actions']['type']]?: ActionFunction<TTypes['context'], TTypes['events'], TTypes['events'], GetConcreteByKey<TTypes['actions'], 'type', K>['params'], TTypes['actors'], TTypes['actions'], TTypes['guards'], TTypes['delays'], TTypes['emitted']>; };
type MachineImplementationsActors<TTypes extends StateMachineTypes> = { [K in TTypes['actors']['src']]?: GetConcreteByKey<TTypes['actors'], 'src', K>['logic']; };
type MachineImplementationsDelays<TTypes extends StateMachineTypes> = { [K in TTypes['delays']]?: DelayConfig<TTypes['context'], TTypes['events'], undefined, TTypes['events']>; };
type MachineImplementationsGuards<TTypes extends StateMachineTypes> = { [K in TTypes['guards']['type']]?: Guard<TTypes['context'], TTypes['events'], GetConcreteByKey<TTypes['guards'], 'type', K>['params'], TTypes['guards']>; };
type InternalMachineImplementations<TTypes extends StateMachineTypes> = {
  actions?: MachineImplementationsActions<TTypes>;
  actors?: MachineImplementationsActors<TTypes>;
  delays?: MachineImplementationsDelays<TTypes>;
  guards?: MachineImplementationsGuards<TTypes>;
};
type InitialContext<TContext extends MachineContext, TActor extends ProvidedActor, TInput, TEvent extends EventObject> = TContext | ContextFactory<TContext, TActor, TInput, TEvent>;
type ContextFactory<TContext extends MachineContext, TActor extends ProvidedActor, TInput, TEvent extends EventObject = EventObject> = ({ spawn, input, self }: {
  spawn: Spawner<TActor>;
  input: TInput;
  self: ActorRef<MachineSnapshot<TContext, TEvent, Record<string, AnyActorRef | undefined> // TODO: this should be replaced with `TChildren`
  , StateValue, string, unknown, TODO // TMeta
  , TODO>, TEvent, AnyEventObject>;
}) => TContext;
/**
 * Runtime options for state machine execution.
 *
 * @example
 *
 * ```ts
 * const machine = createMachine({
 *   // ... machine config
 *   options: {
 *     maxIterations: 5000
 *     // other runtime options can be added here
 *   }
 * });
 * ```
 */
interface MachineOptions {
  /**
   * Maximum number of microsteps allowed before throwing an infinite loop
   * error. Defaults to `Infinity` (no limit). Set to a finite number to enable
   * infinite loop detection.
   *
   * @default Infinity
   */
  maxIterations?: number;
}
type MachineConfig<TContext extends MachineContext, TEvent extends EventObject, TActor extends ProvidedActor = ProvidedActor, TAction extends ParameterizedObject = ParameterizedObject, TGuard extends ParameterizedObject = ParameterizedObject, TDelay extends string = string, TTag extends string = string, TInput = any, TOutput = unknown, TEmitted extends EventObject = EventObject, TStateMeta extends MetaObject = MetaObject, TTransitionMeta extends MetaObject = TStateMeta> = (Omit<StateNodeConfig<DoNotInfer<TContext>, DoNotInfer<TEvent>, DoNotInfer<TActor>, DoNotInfer<TAction>, DoNotInfer<TGuard>, DoNotInfer<TDelay>, DoNotInfer<TTag>, DoNotInfer<TOutput>, DoNotInfer<TEmitted>, DoNotInfer<TStateMeta>, DoNotInfer<TTransitionMeta>>, 'output'> & {
  /** The initial context (extended state) */
  /** The machine's own version. */
  version?: string;
  output?: Mapper<TContext, DoneStateEvent, TOutput, TEvent> | TOutput;
  /** Runtime options for machine execution. */
  options?: MachineOptions;
}) & (MachineContext extends TContext ? {
  context?: InitialContext<LowInfer<TContext>, TActor, TInput, TEvent>;
} : {
  context: InitialContext<LowInfer<TContext>, TActor, TInput, TEvent>;
});
interface ProvidedActor {
  src: string;
  logic: UnknownActorLogic;
  id?: string | undefined;
}
/** Maps history state IDs to recalled nodes, preserving TContext and TEvent with arbitrary metadata. */
type HistoryValue<TContext extends MachineContext, TEvent extends EventObject> = Record<string, Array<StateNode<TContext, TEvent, any, any>>>;
type StateFrom<T extends AnyStateMachine | ((...args: any[]) => AnyStateMachine)> = T extends AnyStateMachine ? ReturnType<T['transition']> : T extends ((...args: any[]) => AnyStateMachine) ? ReturnType<ReturnType<T>['transition']> : never;
interface DoneActorEvent<TOutput = unknown, TId extends string = string> extends EventObject {
  type: `xstate.done.actor.${TId}`;
  output: TOutput;
  actorId: TId;
}
interface ErrorActorEvent<TErrorData = unknown, TId extends string = string> extends EventObject {
  type: `xstate.error.actor.${TId}`;
  error: TErrorData;
  actorId: TId;
}
interface SnapshotEvent<TSnapshot extends Snapshot$1<unknown> = Snapshot$1<unknown>> extends EventObject {
  type: `xstate.snapshot.${string}`;
  snapshot: TSnapshot;
}
interface DoneStateEvent<TOutput = unknown> extends EventObject {
  type: `xstate.done.state.${string}`;
  output: TOutput;
}
type DelayExpr<TContext extends MachineContext, TExpressionEvent extends EventObject, TParams extends ParameterizedObject['params'] | undefined, TEvent extends EventObject> = (args: ActionArgs<TContext, TExpressionEvent, TEvent>, params: TParams) => number;
type Mapper<TContext extends MachineContext, TExpressionEvent extends EventObject, TResult, TEvent extends EventObject> = (args: {
  context: TContext;
  event: TExpressionEvent;
  self: ActorRef<MachineSnapshot<TContext, TEvent, Record<string, AnyActorRef> // TODO: this should be replaced with `TChildren`
  , StateValue, string, unknown, TODO // TMeta
  , TODO>, TEvent, AnyEventObject>;
}) => TResult;
interface TransitionDefinition<TContext extends MachineContext, TEvent extends EventObject, TTransitionMeta extends MetaObject = MetaObject> extends Omit<TransitionConfig<TContext, TEvent, TEvent, TODO, TODO, TODO, TODO, TODO // TEmitted
, TTransitionMeta>, 'target' | 'guard'> {
  target: ReadonlyArray<StateNode<TContext, TEvent, any, TTransitionMeta>> | undefined;
  source: StateNode<TContext, TEvent, any, TTransitionMeta>;
  actions: readonly UnknownAction[];
  reenter: boolean;
  guard?: UnknownGuard;
  eventType: EventDescriptor<TEvent>;
  toJSON: () => {
    target: string[] | undefined;
    source: string;
    actions: readonly UnknownAction[];
    guard?: UnknownGuard;
    eventType: EventDescriptor<TEvent>;
    meta?: TTransitionMeta;
  };
}
type AnyTransitionDefinition = TransitionDefinition<any, any, any>;
interface InitialTransitionDefinition<TContext extends MachineContext, TEvent extends EventObject, TTransitionMeta extends MetaObject = MetaObject> extends TransitionDefinition<TContext, TEvent, TTransitionMeta> {
  target: ReadonlyArray<StateNode<TContext, TEvent, any, TTransitionMeta>>;
  guard?: never;
}
type TransitionDefinitionMap<TContext extends MachineContext, TEvent extends EventObject, TTransitionMeta extends MetaObject = MetaObject> = { [K in EventDescriptor<TEvent>]: Array<TransitionDefinition<TContext, ExtractEvent<TEvent, K>, TTransitionMeta>>; };
interface DelayedTransitionDefinition<TContext extends MachineContext, TEvent extends EventObject, TTransitionMeta extends MetaObject = MetaObject> extends TransitionDefinition<TContext, TEvent, TTransitionMeta> {
  delay: number | string | DelayExpr<TContext, TEvent, undefined, TEvent>;
}
interface ActorOptions<TLogic extends AnyActorLogic> {
  /**
   * The clock that is responsible for setting and clearing timeouts, such as
   * delayed events and transitions.
   *
   * @remarks
   * You can create your own “clock”. The clock interface is an object with two
   * functions/methods:
   *
   * - `setTimeout` - same arguments as `window.setTimeout(fn, timeout)`
   * - `clearTimeout` - same arguments as `window.clearTimeout(id)`
   *
   * By default, the native `setTimeout` and `clearTimeout` functions are used.
   *
   * For testing, XState provides `SimulatedClock`.
   * @see {@link Clock}
   * @see {@link SimulatedClock}
   */
  clock?: Clock;
  /**
   * Specifies the logger to be used for `log(...)` actions. Defaults to the
   * native `console.log(...)` method.
   */
  logger?: (...args: any[]) => void;
  parent?: AnyActorRef;
  /** The custom `id` for referencing this service. */
  id?: string;
  /** @deprecated Use `inspect` instead. */
  devTools?: never;
  /** The system ID to register this actor under. */
  systemId?: string;
  /** The input data to pass to the actor. */
  input?: InputFrom<TLogic>;
  /**
   * Initializes actor logic from a specific persisted internal state.
   *
   * @remarks
   * If the state is compatible with the actor logic, when the actor is started
   * it will be at that persisted state. Actions from machine actors will not be
   * re-executed, because they are assumed to have been already executed.
   * However, invocations will be restarted, and spawned actors will be restored
   * recursively.
   *
   * Can be generated with {@link Actor.getPersistedSnapshot}.
   * @see https://stately.ai/docs/persistence
   */
  snapshot?: Snapshot$1<unknown>;
  /** @deprecated Use `snapshot` instead. */
  state?: Snapshot$1<unknown>;
  /** The source actor logic. */
  src?: string | AnyActorLogic;
  /**
   * A callback function or observer object which can be used to inspect actor
   * system updates.
   *
   * @remarks
   * If a callback function is provided, it can accept an inspection event
   * argument. The types of inspection events that can be observed include:
   *
   * - `@xstate.actor` - An actor ref has been created in the system
   * - `@xstate.event` - An event was sent from a source actor ref to a target
   *   actor ref in the system
   * - `@xstate.snapshot` - An actor ref emitted a snapshot due to a received
   *   event
   *
   * @example
   *
   * ```ts
   * import { createMachine } from 'xstate';
   *
   * const machine = createMachine({
   *   // ...
   * });
   *
   * const actor = createActor(machine, {
   *   inspect: (inspectionEvent) => {
   *     if (inspectionEvent.actorRef === actor) {
   *       // This event is for the root actor
   *     }
   *
   *     if (inspectionEvent.type === '@xstate.actor') {
   *       console.log(inspectionEvent.actorRef);
   *     }
   *
   *     if (inspectionEvent.type === '@xstate.event') {
   *       console.log(inspectionEvent.sourceRef);
   *       console.log(inspectionEvent.actorRef);
   *       console.log(inspectionEvent.event);
   *     }
   *
   *     if (inspectionEvent.type === '@xstate.snapshot') {
   *       console.log(inspectionEvent.actorRef);
   *       console.log(inspectionEvent.event);
   *       console.log(inspectionEvent.snapshot);
   *     }
   *   }
   * });
   * ```
   *
   * Alternately, an observer object (`{ next?, error?, complete? }`) can be
   * provided:
   *
   * @example
   *
   * ```ts
   * const actor = createActor(machine, {
   *   inspect: {
   *     next: (inspectionEvent) => {
   *       if (inspectionEvent.actorRef === actor) {
   *         // This event is for the root actor
   *       }
   *
   *       if (inspectionEvent.type === '@xstate.actor') {
   *         console.log(inspectionEvent.actorRef);
   *       }
   *
   *       if (inspectionEvent.type === '@xstate.event') {
   *         console.log(inspectionEvent.sourceRef);
   *         console.log(inspectionEvent.actorRef);
   *         console.log(inspectionEvent.event);
   *       }
   *
   *       if (inspectionEvent.type === '@xstate.snapshot') {
   *         console.log(inspectionEvent.actorRef);
   *         console.log(inspectionEvent.event);
   *         console.log(inspectionEvent.snapshot);
   *       }
   *     }
   *   }
   * });
   * ```
   */
  inspect?: Observer<InspectionEvent> | ((inspectionEvent: InspectionEvent) => void);
}
type Observer<T> = {
  next?: (value: T) => void;
  error?: (err: unknown) => void;
  complete?: () => void;
};
interface Subscription {
  unsubscribe(): void;
}
interface Readable<T> extends Subscribable<T> {
  get: () => T;
}
interface InteropObservable<T> {
  [Symbol.observable]: () => InteropSubscribable<T>;
}
interface InteropSubscribable<T> {
  subscribe(observer: Observer<T>): Subscription;
}
interface Subscribable<T> extends InteropSubscribable<T> {
  subscribe(observer: Observer<T>): Subscription;
  subscribe(next: (value: T) => void, error?: (error: any) => void, complete?: () => void): Subscription;
}
type EventDescriptorMatches<TEventType extends string, TNormalizedDescriptor> = TEventType extends TNormalizedDescriptor ? true : false;
type ExtractEvent<TEvent extends EventObject, TDescriptor extends EventDescriptor<TEvent>> = string extends TEvent['type'] ? TEvent : NormalizeDescriptor<TDescriptor> extends (infer TNormalizedDescriptor) ? TEvent extends any ? true extends EventDescriptorMatches<TEvent['type'], TNormalizedDescriptor> ? TEvent : never : never : never;
interface ActorRef<TSnapshot extends Snapshot$1<unknown>, TEvent extends EventObject, TEmitted extends EventObject = EventObject> extends Subscribable<TSnapshot>, InteropObservable<TSnapshot> {
  /** The unique identifier for this actor relative to its parent. */
  id: string;
  sessionId: string;
  send: (event: TEvent) => void;
  start: () => void;
  getSnapshot: () => TSnapshot;
  getPersistedSnapshot: () => Snapshot$1<unknown>;
  stop: () => void;
  toJSON?: () => any;
  _parent?: AnyActorRef;
  system: AnyActorSystem;
  src: string | AnyActorLogic;
  on: <TType extends TEmitted['type'] | '*'>(type: TType, handler: (emitted: TEmitted & (TType extends '*' ? unknown : {
    type: TType;
  })) => void) => Subscription;
  select<TSelected>(selector: (snapshot: TSnapshot) => TSelected, equalityFn?: (a: TSelected, b: TSelected) => boolean): Readable<TSelected>;
}
type AnyActorRef = ActorRef<any, any // TODO: shouldn't this be AnyEventObject?
, any>;
type ActorRefLike = Pick<AnyActorRef, 'sessionId' | 'send' | 'getSnapshot'>;
type ActorRefFromLogic<T extends AnyActorLogic> = ActorRef<SnapshotFrom<T>, EventFromLogic<T>, EmittedFrom<T>>;
interface ActorScope<TSnapshot extends Snapshot$1<unknown>, TEvent extends EventObject, TSystem extends AnyActorSystem = AnyActorSystem, TEmitted extends EventObject = EventObject> {
  self: ActorRef<TSnapshot, TEvent, TEmitted>;
  id: string;
  sessionId: string;
  logger: (...args: any[]) => void;
  defer: (fn: () => void) => void;
  emit: (event: TEmitted) => void;
  system: TSystem;
  stopChild: (child: AnyActorRef) => void;
  actionExecutor: ActionExecutor;
}
type AnyActorScope = ActorScope<any // TSnapshot
, any // TEvent
, AnyActorSystem, any>;
type SnapshotStatus = 'active' | 'done' | 'error' | 'stopped';
type Snapshot$1<TOutput> = {
  status: 'active';
  output: undefined;
  error: undefined;
} | {
  status: 'done';
  output: TOutput;
  error: undefined;
} | {
  status: 'error';
  output: undefined;
  error: unknown;
} | {
  status: 'stopped';
  output: undefined;
  error: undefined;
};
/**
 * Represents logic which can be used by an actor.
 *
 * @template TSnapshot - The type of the snapshot.
 * @template TEvent - The type of the event object.
 * @template TInput - The type of the input.
 * @template TSystem - The type of the actor system.
 */
interface ActorLogic<in out TSnapshot extends Snapshot$1<unknown> // it's invariant because it's also part of `ActorScope["self"]["getSnapshot"]`
, in out TEvent extends EventObject // it's invariant because it's also part of `ActorScope["self"]["send"]`
, in TInput = NonReducibleUnknown, TSystem extends AnyActorSystem = AnyActorSystem, in out TEmitted extends EventObject = EventObject> {
  /** The initial setup/configuration used to create the actor logic. */
  config?: unknown;
  /**
   * Transition function that processes the current state and an incoming event
   * to produce a new state.
   *
   * @param snapshot - The current state.
   * @param event - The incoming event.
   * @param actorScope - The actor scope.
   * @returns The new state.
   */
  transition: (snapshot: TSnapshot, event: TEvent, actorScope: ActorScope<TSnapshot, TEvent, TSystem, TEmitted>) => TSnapshot;
  /**
   * Called to provide the initial state of the actor.
   *
   * @param actorScope - The actor scope.
   * @param input - The input for the initial state.
   * @returns The initial state.
   */
  getInitialSnapshot: (actorScope: ActorScope<TSnapshot, TEvent, TSystem, TEmitted>, input: TInput) => TSnapshot;
  /**
   * Called when Actor is created to restore the internal state of the actor
   * given a persisted state. The persisted state can be created by
   * `getPersistedSnapshot`.
   *
   * @param persistedState - The persisted state to restore from.
   * @param actorScope - The actor scope.
   * @returns The restored state.
   */
  restoreSnapshot?: (persistedState: Snapshot$1<unknown>, actorScope: ActorScope<TSnapshot, TEvent, AnyActorSystem, TEmitted>) => TSnapshot;
  /**
   * Called when the actor is started.
   *
   * @param snapshot - The starting state.
   * @param actorScope - The actor scope.
   */
  start?: (snapshot: TSnapshot, actorScope: ActorScope<TSnapshot, TEvent, AnyActorSystem, TEmitted>) => void;
  /**
   * Obtains the internal state of the actor in a representation which can be be
   * persisted. The persisted state can be restored by `restoreSnapshot`.
   *
   * @param snapshot - The current state.
   * @returns The a representation of the internal state to be persisted.
   */
  getPersistedSnapshot: (snapshot: TSnapshot, options?: unknown) => Snapshot$1<unknown>;
}
type AnyActorLogic = ActorLogic<any // snapshot
, any // event
, any // input
, any // system
, any>;
type UnknownActorLogic = ActorLogic<any // snapshot
, any // event
, any // input
, AnyActorSystem, any>;
type SnapshotFrom<T> = ReturnTypeOrValue<T> extends (infer R) ? R extends ActorRef<infer TSnapshot, infer _, infer __> ? TSnapshot : R extends Actor<infer TLogic> ? SnapshotFrom<TLogic> : R extends ActorLogic<infer _TSnapshot, infer _TEvent, infer _TInput, infer _TEmitted, infer _TSystem> ? ReturnType<R['transition']> : R extends ActorScope<infer TSnapshot, infer _TEvent, infer _TEmitted, infer _TSystem> ? TSnapshot : never : never;
type EventFromLogic<TLogic extends AnyActorLogic> = TLogic extends ActorLogic<infer _TSnapshot, infer TEvent, infer _TInput, infer _TEmitted, infer _TSystem> ? TEvent : never;
type EmittedFrom<TLogic extends AnyActorLogic> = TLogic extends ActorLogic<infer _TSnapshot, infer _TEvent, infer _TInput, infer _TSystem, infer TEmitted> ? TEmitted : never;
type TODO = any;
type StateValueFrom<TMachine extends AnyStateMachine> = Parameters<StateFrom<TMachine>['matches']>[0];
interface ActorSystemInfo {
  actors: Record<string, AnyActorRef>;
}
type RequiredActorOptions<TActor extends ProvidedActor> = (undefined extends TActor['id'] ? never : 'id') | (undefined extends InputFrom<TActor['logic']> ? never : 'input');
type RequiredLogicInput<TLogic extends AnyActorLogic> = undefined extends InputFrom<TLogic> ? never : 'input';
type StateSchema = {
  id?: string;
  route?: unknown;
  states?: Record<string, StateSchema>;
  type?: unknown;
  invoke?: unknown;
  on?: unknown;
  entry?: unknown;
  exit?: unknown;
  onDone?: unknown;
  after?: unknown;
  always?: unknown;
  meta?: unknown;
  output?: unknown;
  tags?: unknown;
  description?: unknown;
};
type StateId<TSchema extends StateSchema, TKey extends string = '(machine)', TParentKey extends string | null = null> = (TSchema extends {
  id: string;
} ? TSchema['id'] : TParentKey extends null ? TKey : `${TParentKey}.${TKey}`) | (TSchema['states'] extends Record<string, any> ? Values<{ [K in keyof TSchema['states'] & string]: StateId<TSchema['states'][K], K, TParentKey extends string ? `${TParentKey}.${TKey}` : TSchema['id'] extends string ? TSchema['id'] : TKey>; }> : never);
interface StateMachineTypes {
  context: MachineContext;
  events: EventObject;
  actors: ProvidedActor;
  actions: ParameterizedObject;
  guards: ParameterizedObject;
  delays: string;
  tags: string;
  emitted: EventObject;
}
/** @deprecated */
interface ResolvedStateMachineTypes<TContext extends MachineContext, TEvent extends EventObject, TActor extends ProvidedActor, TAction extends ParameterizedObject, TGuard extends ParameterizedObject, TDelay extends string, TTag extends string, TEmitted extends EventObject = EventObject> {
  context: TContext;
  events: TEvent;
  actors: TActor;
  actions: TAction;
  guards: TGuard;
  delays: TDelay;
  tags: TTag;
  emitted: TEmitted;
}
type GetConcreteByKey<T, TKey extends keyof T, TValue extends T[TKey]> = T & Record<TKey, TValue>;
interface ExecutableActionObject {
  type: string;
  info: ActionArgs<MachineContext, EventObject, EventObject>;
  params: NonReducibleUnknown;
  exec: ((info: ActionArgs<any, any, any>, params: unknown) => void) | undefined;
}
type ActionExecutor = (actionToExecute: ExecutableActionObject) => void;
//#endregion
//#region ../../node_modules/.pnpm/xstate@5.33.2/node_modules/xstate/dist/declarations/src/spawn.d.ts
type SpawnOptions<TActor extends ProvidedActor, TSrc extends TActor['src']> = TActor extends {
  src: TSrc;
} ? ConditionalRequired<[options?: {
  id?: TActor['id'];
  systemId?: string;
  input?: InputFrom<TActor['logic']>;
  syncSnapshot?: boolean;
} & { [K in RequiredActorOptions<TActor>]: unknown; }], IsNotNever<RequiredActorOptions<TActor>>> : never;
type Spawner<TActor extends ProvidedActor> = IsLiteralString<TActor['src']> extends true ? {
  <TSrc extends TActor['src']>(logic: TSrc, ...[options]: SpawnOptions<TActor, TSrc>): ActorRefFromLogic<GetConcreteByKey<TActor, 'src', TSrc>['logic']>;
  <TLogic extends AnyActorLogic>(src: TLogic, ...[options]: ConditionalRequired<[options?: {
    id?: never;
    systemId?: string;
    input?: InputFrom<TLogic>;
    syncSnapshot?: boolean;
  } & { [K in RequiredLogicInput<TLogic>]: unknown; }], IsNotNever<RequiredLogicInput<TLogic>>>): ActorRefFromLogic<TLogic>;
} : <TLogic extends AnyActorLogic | string>(src: TLogic, ...[options]: ConditionalRequired<[options?: {
  id?: string;
  systemId?: string;
  input?: TLogic extends string ? unknown : InputFrom<TLogic>;
  syncSnapshot?: boolean;
} & (TLogic extends AnyActorLogic ? { [K in RequiredLogicInput<TLogic>]: unknown; } : {})], IsNotNever<TLogic extends AnyActorLogic ? RequiredLogicInput<TLogic> : never>>) => TLogic extends AnyActorLogic ? ActorRefFromLogic<TLogic> : AnyActorRef;
//#endregion
//#region ../../node_modules/.pnpm/xstate@5.33.2/node_modules/xstate/dist/declarations/src/actors/callback.d.ts
type CallbackSnapshot<TInput> = Snapshot$1<undefined> & {
  input: TInput;
};
type CallbackActorLogic<TEvent extends EventObject, TInput = NonReducibleUnknown, TEmitted extends EventObject = EventObject> = ActorLogic<CallbackSnapshot<TInput>, TEvent, TInput, AnyActorSystem, TEmitted>;
//#endregion
//#region ../../node_modules/.pnpm/xstate@5.33.2/node_modules/xstate/dist/declarations/src/index.d.ts
declare global {
  interface SymbolConstructor {
    readonly observable: symbol;
  }
}
//#endregion
//#region ../diagram/dist/overlays/relationships-browser/actor.d.mts
//#region src/overlays/relationships-browser/actor.d.ts
type XYFLowInstance$1 = ReactFlowInstance<RelationshipsBrowserTypes.AnyNode, RelationshipsBrowserTypes.Edge>;
type XYStoreState$2 = ReactFlowState<RelationshipsBrowserTypes.AnyNode, RelationshipsBrowserTypes.Edge>;
type XYStoreApi$2 = {
  getState: () => XYStoreState$2;
  setState: (state: XYStoreState$2) => void;
};
type Input$3 = {
  subject: Fqn;
  viewId: ViewId | null;
  scope: 'global' | 'view';
  closeable?: boolean;
  enableSelectSubject?: boolean;
  enableChangeScope?: boolean;
};
interface Context$4 {
  subject: Fqn;
  viewId: ViewId | null;
  scope: 'global' | 'view';
  closeable: boolean;
  enableSelectSubject: boolean;
  enableChangeScope: boolean;
  xyflow: XYFLowInstance$1 | null;
  xystore: XYStoreApi$2 | null;
  layouted: LayoutRelationshipsViewResult | null;
  navigateFromNode: string | null;
  xynodes: RelationshipsBrowserTypes.Node[];
  xyedges: RelationshipsBrowserTypes.Edge[];
}
type Events$4 = {
  type: 'xyflow.init';
  instance: XYFLowInstance$1;
  store: XYStoreApi$2;
} | {
  type: 'xyflow.nodeClick';
  node: RelationshipsBrowserTypes.Node;
} | {
  type: 'xyflow.edgeClick';
  edge: RelationshipsBrowserTypes.Edge;
} | {
  type: 'xyflow.applyNodeChanges';
  changes: NodeChange<RelationshipsBrowserTypes.Node>[];
} | {
  type: 'xyflow.applyEdgeChanges';
  changes: EdgeChange<RelationshipsBrowserTypes.Edge>[];
} | {
  type: 'xyflow.paneClick';
} | {
  type: 'xyflow.paneDblClick';
} | {
  type: 'xyflow.resized';
} | {
  type: 'xyflow.edgeMouseEnter';
  edge: RelationshipsBrowserTypes.Edge;
} | {
  type: 'xyflow.edgeMouseLeave';
  edge: RelationshipsBrowserTypes.Edge;
} | {
  type: 'xyflow.selectionChange';
  nodes: RelationshipsBrowserTypes.Node[];
  edges: RelationshipsBrowserTypes.Edge[];
} | {
  type: 'dim.nonhovered.edges';
} | {
  type: 'undim.edges';
} | {
  type: 'xyflow.updateNodeInternals';
} | {
  type: 'xyflow.unmount';
} | {
  type: 'fitDiagram';
  duration?: number;
  bounds?: BBox;
} | {
  type: 'navigate.to';
  subject: Fqn;
  fromNode?: string | undefined;
  viewId?: ViewId | undefined;
} | {
  type: 'update.xydata';
  xynodes: RelationshipsBrowserTypes.Node[];
  xyedges: RelationshipsBrowserTypes.Edge[];
} | {
  type: 'change.scope';
  scope: 'global' | 'view';
} | {
  type: 'update.view';
  layouted: LayoutRelationshipsViewResult;
} | {
  type: 'close';
};
type Tags$2 = 'active';
interface RelationshipsBrowserLogic extends StateMachine<Context$4, Events$4, {}, any, any, any, any, any, Tags$2, Input$3, any, any, any, any> {}
type RelationshipsBrowserSnapshot = SnapshotFrom<RelationshipsBrowserLogic>;
interface RelationshipsBrowserActorRef extends ActorRef<RelationshipsBrowserSnapshot, Events$4> {}
//#endregion
//#region ../diagram/dist/overlays/element-details/actor.d.mts
//#region src/overlays/element-details/actor.d.ts
type ElementDetailsInput = {
  subject: Fqn$1;
  currentView: DiagramView;
  initiatedFrom?: {
    node?: NodeId$1;
    clientRect?: Rect;
  };
};
type Context$3 = {
  subject: Fqn$1;
  currentView: DiagramView;
  initiatedFrom: {
    node: NodeId$1 | null;
    clientRect: Rect | null;
  };
};
type Events$3 = {
  type: 'change.subject';
  subject: Fqn$1;
} | {
  type: 'close';
};
interface ElementDetailsLogic extends StateMachine<Context$3, Events$3, {
  [key: `${string}-relationships`]: RelationshipsBrowserActorRef | undefined;
}, any, any, any, any, any, never, ElementDetailsInput, any, any, any, any> {}
type ElementDetailsSnapshot = SnapshotFrom<ElementDetailsLogic>;
interface ElementDetailsActorRef extends ActorRef<ElementDetailsSnapshot, Events$3> {}
//#endregion
//#endregion
//#region ../diagram/dist/overlays/relationship-details/_types.d.mts
//#region src/overlays/relationship-details/_types.d.ts
declare namespace RelationshipDetailsTypes {
  type Column = 'sources' | 'targets';
  /**
   * The node's incoming and outgoing ports
   */
  type Ports = {
    in: string[];
    out: string[];
  };
  type ElementNodeData = Simplify<BaseNodeData & NonOptional<Pick<DiagramNode, 'id' | 'title' | 'technology' | 'description' | 'color' | 'shape' | 'width' | 'height' | 'navigateTo' | 'style' | 'tags'>> & {
    column: Column;
    fqn: Fqn$1;
    icon: IconUrl;
    ports: Ports;
  }>;
  type CompoundNodeData = Simplify<BaseNodeData & NonOptional<Pick<DiagramNode, 'id' | 'title' | 'color' | 'style'>> & {
    column: Column;
    fqn: Fqn$1;
    depth: number;
    icon?: IconUrl;
    ports: Ports;
  }>;
  type ElementNode = BaseNode<ElementNodeData, 'element'>;
  type CompoundNode = BaseNode<CompoundNodeData, 'compound'>;
  type AnyNode = ElementNode | CompoundNode;
  type NodeType = AnyNode['type'];
  type Node<T extends NodeType = NodeType> = Extract<AnyNode, {
    type: T;
  }>;
  type NodeProps<T extends NodeType = NodeType> = BaseNodeProps<Node<T>>;
  type NodeData = ExclusiveUnion$1<{
    ElementNodeData: ElementNodeData;
    CompoundNodeData: CompoundNodeData;
  }>;
  type NodeRenderer<T extends NodeType = NodeType> = FunctionComponent<NodeProps<T>>;
  type NodeRenderers = {
    element: NodeRenderer<'element'>;
    compound: NodeRenderer<'compound'>;
  };
  type EdgeData = Simplify<BaseEdgeData & {
    relationId: RelationId;
    color: Color;
    label: string | null;
    technology?: string | undefined;
    navigateTo: ViewId$1 | null;
    line: RelationshipLineType;
    head?: RelationshipArrowType;
    tail?: RelationshipArrowType;
    description: MarkdownOrString$1 | null;
  }>;
  type Edge = BaseEdge<EdgeData, 'relationship'>;
  type EdgeProps = BaseEdgeProps<Edge>;
}
//#endregion
//#endregion
//#region ../diagram/dist/overlays/relationship-details/layout.d.mts
//#region src/overlays/relationship-details/layout.d.ts
type LayoutResult = {
  nodes: LayoutResult.Node[];
  edges: LayoutResult.Edge[];
  bounds: DiagramView['bounds'];
};
declare namespace LayoutResult {
  type Node = Except<DiagramNode, 'modelRef' | 'description' | 'deploymentRef' | 'inEdges' | 'outEdges'> & {
    description: MarkdownOrString$1 | null;
    modelRef: Fqn$1;
    column: RelationshipDetailsTypes.Column;
    ports: RelationshipDetailsTypes.Ports;
  };
  type Edge = Except<DiagramEdge, 'relations' | 'description'> & {
    relationId: RelationId;
    sourceHandle: string;
    targetHandle: string;
    description: MarkdownOrString$1 | null;
  };
}
//#endregion
//#endregion
//#region ../diagram/dist/overlays/relationship-details/actor.d.mts
//#region src/overlays/relationship-details/actor.d.ts
type XYFLowInstance = ReactFlowInstance<RelationshipDetailsTypes.AnyNode, RelationshipDetailsTypes.Edge>;
type XYStoreState$1 = ReactFlowState<RelationshipDetailsTypes.AnyNode, RelationshipDetailsTypes.Edge>;
type XYStoreApi$1 = {
  getState: () => XYStoreState$1;
};
type Input$2 = ExclusiveUnion<{
  Edge: {
    edgeId: EdgeId;
    viewId: ViewId;
  };
  Between: {
    source: Fqn;
    target: Fqn;
    viewId: ViewId;
  };
}>;
type Subject = {
  edgeId: EdgeId;
  source?: never;
  target?: never;
} | {
  source: Fqn;
  target: Fqn;
  edgeId?: never;
};
type Context$2 = Readonly<{
  subject: Subject;
  viewId: ViewId;
  xyflow: XYFLowInstance | null;
  xystore: XYStoreApi$1 | null;
  initialized: {
    xydata: boolean;
    xyflow: boolean;
  };
  xynodes: RelationshipDetailsTypes.Node[];
  xyedges: RelationshipDetailsTypes.Edge[];
  bounds: BBox;
}>;
type Events$2 = {
  type: 'xyflow.init';
  instance: XYFLowInstance;
  store: XYStoreApi$1;
} | {
  type: 'xyflow.nodeClick';
  node: RelationshipDetailsTypes.Node;
} | {
  type: 'xyflow.edgeClick';
  edge: RelationshipDetailsTypes.Edge;
} | {
  type: 'xyflow.edgeMouseEnter';
  edge: RelationshipDetailsTypes.Edge;
} | {
  type: 'xyflow.edgeMouseLeave';
  edge: RelationshipDetailsTypes.Edge;
} | {
  type: 'dim.nonhovered.edges';
} | {
  type: 'undim.edges';
} | {
  type: 'xyflow.selectionChange';
  nodes: RelationshipDetailsTypes.Node[];
  edges: RelationshipDetailsTypes.Edge[];
} | {
  type: 'xyflow.applyNodeChanges';
  changes: NodeChange<RelationshipDetailsTypes.Node>[];
} | {
  type: 'xyflow.applyEdgeChanges';
  changes: EdgeChange<RelationshipDetailsTypes.Edge>[];
} | {
  type: 'xyflow.paneClick';
} | {
  type: 'xyflow.paneDblClick';
} | {
  type: 'xyflow.resized';
} | {
  type: 'xyflow.updateNodeInternals';
} | {
  type: 'update.layoutData';
  data: LayoutResult;
} | {
  type: 'fitDiagram';
  duration?: number;
  bounds?: BBox;
} | {
  type: 'navigate.to';
  params: {
    edgeId: EdgeId;
    viewId?: ViewId;
  } | {
    source: Fqn;
    target: Fqn;
    viewId?: ViewId;
  };
} | {
  type: 'close';
};
type Tags$1 = never;
interface RelationshipDetailsLogic extends StateMachine<Context$2, Events$2, {}, any, any, any, any, any, Tags$1, Input$2, any, any, any, any> {}
type RelationshipDetailsSnapshot = SnapshotFrom<RelationshipDetailsLogic>;
interface RelationshipDetailsActorRef extends ActorRef<RelationshipDetailsSnapshot, Events$2> {}
//#endregion
//#region ../diagram/dist/overlays/types.d.mts
//#region src/overlays/types.d.ts
declare namespace Overlays {
  namespace ElementDetails {
    interface Input extends ElementDetailsInput {}
    interface Logic extends ElementDetailsLogic {}
    interface ActorRef extends ElementDetailsActorRef {}
  }
  namespace RelationshipDetails {
    type Input = Input$2;
    interface Logic extends RelationshipDetailsLogic {}
    interface ActorRef extends RelationshipDetailsActorRef {}
  }
  namespace RelationshipsBrowser {
    interface Input extends Input$3 {}
    interface Logic extends RelationshipsBrowserLogic {}
    interface ActorRef extends RelationshipsBrowserActorRef {}
  }
}
//#endregion
//#endregion
//#region ../diagram/dist/overlays/overlaysActor.d.mts
//#region src/overlays/overlaysActor.d.ts
type OverlayActorEvent = {
  type: 'open.elementDetails';
} & Overlays.ElementDetails.Input | {
  type: 'open.relationshipDetails';
} & Overlays.RelationshipDetails.Input | {
  type: 'open.relationshipsBrowser';
} & Overlays.RelationshipsBrowser.Input | {
  type: 'close';
  actorId?: string | undefined;
} | {
  type: 'close.all';
};
interface OverlaysContext {
  seq: number;
  overlays: Array<{
    type: 'elementDetails';
    id: `elementDetails-${number}`;
    subject: Fqn$1;
  } | {
    type: 'relationshipDetails';
    id: `relationshipDetails-${number}`;
  } | {
    type: 'relationshipsBrowser';
    id: `relationshipsBrowser-${number}`;
    subject: Fqn$1;
  }>;
}
type OverlayActorEmitedEvent = {
  type: 'opened';
  overlay: 'elementDetails' | 'relationshipsBrowser' | 'relationshipDetails';
} | {
  type: 'closed';
  overlay: 'elementDetails' | 'relationshipsBrowser' | 'relationshipDetails';
} | {
  type: 'idle';
};
interface OverlaysActorLogic extends StateMachine<OverlaysContext, OverlayActorEvent, {
  [key: `elementDetails-${number}`]: Overlays.ElementDetails.ActorRef | undefined;
  [key: `relationshipDetails-${number}`]: Overlays.RelationshipDetails.ActorRef | undefined;
  [key: `relationshipsBrowser-${number}`]: Overlays.RelationshipsBrowser.ActorRef | undefined;
}, any, any, any, any, any, never, never, any, OverlayActorEmitedEvent, any, any> {}
type OverlaysActorSnapshot = SnapshotFrom<OverlaysActorLogic>;
interface OverlaysActorRef extends ActorRef<OverlaysActorSnapshot, OverlayActorEvent, OverlayActorEmitedEvent> {}
//#endregion
//#endregion
//#region ../diagram/dist/search/searchActor.d.mts
//#region src/search/searchActor.d.ts
type SearchActorEvent = {
  type: 'open';
  search?: string | undefined;
} | {
  type: 'close';
} | {
  type: 'change.search';
  search: string;
} | {
  type: 'pickview.open';
  elementFqn: Fqn$1;
} | {
  type: 'navigate.to';
  viewId: ViewId$1;
  focusOnElement?: Fqn$1 | undefined;
} | {
  type: 'animation.presence.end';
} | {
  type: 'pickview.close';
};
interface SearchContext$1 {
  openedWithSearch: string | null;
  searchValue: string;
  pickViewFor: Fqn$1 | null;
  navigateTo: {
    viewId: ViewId$1;
    focusOnElement?: Fqn$1 | undefined;
  } | null;
}
interface SearchActorLogic extends StateMachine<SearchContext$1, SearchActorEvent, {}, any, any, any, any, 'inactive' | 'opened' | 'pickView' | 'waitAnimationEnd', never, never, any, any, any, any> {}
type SearchActorSnapshot = SnapshotFrom<SearchActorLogic>;
interface SearchActorRef extends ActorRef<SearchActorSnapshot, SearchActorEvent> {}
//#endregion
//#endregion
//#region ../diagram/dist/editor/actor/hotkey.d.mts
//#region src/editor/actor/hotkey.d.ts
type HotKeyEvent$1 = {
  type: 'undo' | 'redo';
};
interface HotkeyActorLogic$1 extends CallbackActorLogic<AnyEventObject, NonReducibleUnknown, HotKeyEvent$1> {}
//#endregion
//#endregion
//#region ../diagram/dist/editor/actor/types.d.mts
//#region src/editor/actor/types.d.ts
type EditorActorEvent = {
  type: 'change.view';
  change: t.ViewChange;
} | {
  type: 'change.semantic-layout';
} | {
  type: 'change.latest-to-manual';
} | {
  type: 'change.sync-snapshot';
} | {
  type: 'delete.nodes-edges';
  nodeIds: t.NodeId[];
  edgeIds: t.EdgeId[];
} | {
  type: 'view.synched';
} | {
  type: 'cancel';
} | {
  type: 'edit.move.start';
  subject: 'node' | 'edge';
} | {
  type: 'edit.move.end';
} | {
  type: 'edit.move.cancel';
} | HotKeyEvent$1;
type Snapshot = {
  view: t.LayoutedView;
  change: t.ViewChange.SaveViewSnapshot;
  xynodes: Types.Node[];
  xyedges: Types.Edge[];
};
type LinkedSnapshot = {
  head: Snapshot;
  tail: LinkedSnapshot | null;
};
interface EditorActorInput {
  viewId: t.ViewId;
}
type SyncOp = t.ViewChange | 'sync-snapshot' | 'apply-semantic-layout' | 'apply-latest-to-manual';
interface EditorActorContext {
  viewId: t.ViewId;
  history: LinkedSnapshot | null;
  redo: LinkedSnapshot | null;
  editing: null | {
    /**
     * The subject of the edit
     */
    subject: 'node' | 'edge';
    /**
     * The state before editing started
     */
    before: Snapshot;
  };
  syncQueue: Array<SyncOp>;
  processing: Exclude<SyncOp, 'sync-snapshot'> | null;
}
type EditorActorEmitedEvent = {
  type: 'idle';
};
type EditorActorStateTag = 'pending' | 'busy' | 'ai-semantic-layout';
//#endregion
//#endregion
//#region ../diagram/dist/utils/defineActors.d.mts
//#region src/utils/defineActors.d.ts
type inferChildrenRef<A> = A extends Record<string, AnyActorLogic> ? { [K in keyof A & string]: ActorRefFromLogic<A[K]> | undefined; } : never;
type inferProvidedActor<A> = A extends Record<string, AnyActorLogic> ? { [K in keyof A & string]: {
  id: K;
  logic: A[K];
  src: K;
}; }[keyof A & string] : never;
//#endregion
//#endregion
//#region ../diagram/dist/editor/actor/setup.d.mts
//#region src/editor/actor/setup.d.ts
declare namespace EditorCalls {
  type ApplyLatestToManual = (params: {
    input: ApplyLatestToManual.Input;
  }) => Promise<ApplyLatestToManual.Output>;
  namespace ApplyLatestToManual {
    type Input = {
      viewId: t.ViewId;
      current: t.LayoutedView | undefined;
    };
    type Output = {
      updated: t.LayoutedView;
    };
  }
  type ApplySemanticLayout = (params: {
    input: ApplySemanticLayout.Input;
  }) => Promise<ApplySemanticLayout.Output>;
  namespace ApplySemanticLayout {
    type Input = {
      viewId: t.ViewId;
    };
    type Output = {};
  }
  type ExecuteChange = (params: {
    input: ExecuteChange.Input;
  }) => Promise<ExecuteChange.Output>;
  namespace ExecuteChange {
    type Input = {
      viewId: t.ViewId;
      changes: t.ViewChange[];
    };
    /**
     * Returns the changes that were applied to the view
     */
    type Output = {
      requested: t.ViewChange[];
      applied: t.ViewChange[];
      waitForViewSync: boolean;
    };
  }
}
declare const actors$1: {
  hotkey: HotkeyActorLogic$1;
  applyLatest: PromiseActorLogic<EditorCalls.ApplyLatestToManual.Output, EditorCalls.ApplyLatestToManual.Input, EventObject>;
  executeChange: PromiseActorLogic<EditorCalls.ExecuteChange.Output, EditorCalls.ExecuteChange.Input, EventObject>;
  applySemanticLayout: PromiseActorLogic<EditorCalls.ApplySemanticLayout.Output, EditorCalls.ApplySemanticLayout.Input, EventObject>;
};
/**
 * to workaround circular dependency issue between editor and diagram packages
 */
interface BaseEditorActorLogic<State extends StateValue = any> extends StateMachine<EditorActorContext, EditorActorEvent, inferChildrenRef<typeof actors$1>, inferProvidedActor<typeof actors$1>, never, never, never, State, EditorActorStateTag, EditorActorInput, never, EditorActorEmitedEvent, never, never> {}
type BaseEditorActorRef = ActorRefFromLogic<BaseEditorActorLogic>;
//#endregion
//#endregion
//#region ../diagram/dist/editor/actor/machine.d.mts
//#region src/editor/actor/machine.d.ts
interface EditorActorLogic extends BaseEditorActorLogic {}
type EditorActorSnapshot = SnapshotFrom<EditorActorLogic>;
interface EditorActorRef extends ActorRef<EditorActorSnapshot, EditorActorEvent, EditorActorEmitedEvent> {}
//#endregion
//#endregion
//#region ../diagram/dist/context/DiagramFeatures.d.mts
//#region src/context/DiagramFeatures.d.ts
declare const FeatureNames: readonly ["Controls", "Editor", "AISemanticLayout", "ReadOnly", "FocusMode", "NavigateTo", "ElementDetails", "RelationshipDetails", "RelationshipBrowser", "Search", "NavigationButtons", "Notations", "DynamicViewWalkthrough", "FitView", "CompareWithLatest", "Notes", "Vscode", "ElementTags"];
type FeatureName = typeof FeatureNames[number];
type TogglableFeature = ('ReadOnly' | 'CompareWithLatest') & FeatureName;
type EnabledFeatures = { [P in `enable${FeatureName}`]: boolean; };
export declare function useEnabledFeatures(): EnabledFeatures;
/**
 * Renders children only if the specified feature is enabled
 * @param feature Feature name
 * @param and Additional AND condition
 * @example
 * <IfEnabled feature="ReadOnly" and={isSomething}>
 *   ...
 * </IfEnabled>
 */
export declare function IfEnabled({ feature, children, and }: PropsWithChildren<{
  feature: FeatureName;
  and?: boolean;
}>): JSX$1.Element | null;
export declare function IfNotEnabled({ feature, children }: PropsWithChildren<{
  feature: FeatureName;
}>): JSX$1.Element | null;
export declare function IfReadOnly({ children }: PropsWithChildren): JSX$1.Element | null;
export declare function IfNotReadOnly({ children }: PropsWithChildren): JSX$1.Element | null;
//#endregion
//#endregion
//#region ../diagram/dist/likec4diagram/state/aligners.d.mts
//#region src/likec4diagram/state/aligners.d.ts
type GridAlignmentMode = 'Column' | 'Row';
type LinearAlignmentMode = 'Left' | 'Center' | 'Right' | 'Top' | 'Middle' | 'Bottom';
type AlignmentMode = LinearAlignmentMode | GridAlignmentMode;
//#endregion
//#endregion
//#region ../diagram/dist/hooks/useXYFlow.d.mts
//#region src/hooks/useXYFlow.d.ts
type XYFlowInstance = ReactFlowInstance<Types.AnyNode, Types.AnyEdge>;
type XYStoreState = ReactFlowState<Types.AnyNode, Types.AnyEdge>;
type XYStoreApi = {
  getState: () => XYStoreState;
  setState: (state: Partial<XYStoreState> | ((state: XYStoreState) => Partial<XYStoreState>)) => void;
  subscribe: (listener: (state: XYStoreState, prevState: XYStoreState) => void) => () => void;
};
//#endregion
//#endregion
//#region ../diagram/dist/navigationpanel/actor.setup.d.mts
//#region src/navigationpanel/actor.setup.d.ts
interface Input$1 {
  viewId: ViewId$1;
  viewFolder: string;
}
type Events$1 = {
  type: 'update.inputs';
  inputs: Input$1;
} | {
  type: 'searchQuery.change';
  value: string;
} | {
  type: 'searchQuery.changed';
} | {
  type: 'select.folder';
  folderPath: string;
} | {
  type: 'select.view';
  viewId: ViewId$1;
  viewFolder?: string | undefined;
} | {
  type: 'breadcrumbs.mouseLeave';
} | {
  type: 'breadcrumbs.mouseEnter.root';
} | {
  type: 'breadcrumbs.mouseLeave.root';
} | {
  type: 'breadcrumbs.mouseEnter.folder';
  folderPath: string;
} | {
  type: 'breadcrumbs.mouseLeave.folder';
  folderPath: string;
} | {
  type: 'breadcrumbs.mouseEnter.viewtitle';
} | {
  type: 'breadcrumbs.mouseLeave.viewtitle';
} | {
  type: 'breadcrumbs.click.root';
} | {
  type: 'breadcrumbs.click.folder';
  folderPath: string;
} | {
  type: 'breadcrumbs.click.viewtitle';
} | {
  type: 'dropdown.mouseEnter';
} | {
  type: 'dropdown.mouseLeave';
} | {
  type: 'dropdown.dismiss';
};
interface Context$1 {
  viewId: ViewId$1;
  viewFolder: string;
  /**
   * Who activated the dropdown
   * (if `click` then the dropdown is always open until dismissed)
   * @default 'hover'
   */
  activatedBy: 'hover' | 'click';
  /**
   * The folder that is currently selected in the dropdown
   * By default it is the root
   */
  selectedFolder: string;
  searchQuery: string;
}
type Tags = 'active';
declare function Context$1({ input }: {
  input: Input$1;
}): Context$1;
//#endregion
//#endregion
//#region ../diagram/dist/navigationpanel/actor.d.mts
//#region src/navigationpanel/actor.d.ts
declare const _actorLogic: StateMachine<Context$1, Events$1, {}, never, never, {
  type: "was opened on hover";
  params: unknown;
} | {
  type: "has search query";
  params: unknown;
} | {
  type: "search query is empty";
  params: unknown;
}, "open timeout" | "close timeout", "pending" | "idle" | {
  active: "search" | "opened" | "decide" | "closing";
}, "active", Input$1, NonReducibleUnknown, EventObject, MetaObject, {
  id: "navigationPanel";
  states: {
    readonly idle: {
      id: "idle";
    };
    readonly pending: {};
    readonly active: {
      states: {
        readonly decide: {};
        readonly opened: {};
        readonly search: {};
        readonly closing: {};
      };
    };
  };
}, MetaObject>;
interface NavigationPanelActorLogic extends StateMachine<Context$1, Events$1, any, any, any, any, any, StateValueFrom<typeof _actorLogic>, Tags, Input$1, any, any, any, any> {}
type NavigationPanelActorSnapshot = SnapshotFrom<NavigationPanelActorLogic>;
interface NavigationPanelActorRef extends ActorRef<NavigationPanelActorSnapshot, Events$1, never> {}
//#endregion
//#region ../diagram/dist/likec4diagram/state/hotkeyActor.d.mts
//#region src/likec4diagram/state/hotkeyActor.d.ts
type HotKeyEvent = {
  type: 'key.esc' | `key.arrow.${'left' | 'right' | 'up' | 'down'}`;
};
interface HotkeyActorLogic extends CallbackActorLogic<AnyEventObject, NonReducibleUnknown, HotKeyEvent> {}
//#endregion
//#endregion
//#region ../diagram/dist/likec4diagram/state/mediaPrintActor.d.mts
//#region src/likec4diagram/state/mediaPrintActor.d.ts
type MediaPrintEvent = {
  type: 'media.print.on';
} | {
  type: 'media.print.off';
};
interface MediaPrintActorLogic extends CallbackActorLogic<AnyEventObject, NonReducibleUnknown, MediaPrintEvent> {}
//#endregion
//#endregion
//#region ../diagram/dist/likec4diagram/state/machine.setup.d.mts
//#region src/likec4diagram/state/machine.setup.d.ts
/**
 * Display variant for element views: plain boxes-and-lines diagram, or a compact graph
 * of circles (topology-focused, akin to Structurizr's "Explore" graph view).
 * Client-side only - not persisted, no DSL/grammar impact.
 */
type ElementViewDisplayVariant = 'diagram' | 'graph';
/**
 * Navigation history entry represents a current view state,
 * including viewport, focused node, dynamic view variant, etc.
 */
interface NavigationHistoryEntry {
  viewId: ViewId$1;
  viewport: Viewport;
  viewportChangedManually: boolean;
  viewportBefore?: null | {
    wasChangedManually: boolean;
    value: Viewport;
  };
  focusedNode?: NodeId$1 | null;
  dynamicViewVariant?: DynamicViewDisplayVariant | null;
  activeWalkthrough?: null | StepPath;
}
interface NavigationHistory {
  history: ReadonlyArray<NavigationHistoryEntry>;
  currentIndex: number;
}
interface Input {
  view: DiagramView;
  xystore: XYStoreApi;
  zoomable: boolean;
  pannable: boolean;
  fitView?: boolean | undefined;
  initialZoom?: number | undefined;
  minZoom?: number | undefined;
  maxZoom?: number | undefined;
  nodesDraggable: boolean;
  nodesSelectable: boolean;
  fitViewPadding: ViewPaddings;
  where: WhereOperator | null;
  dynamicViewVariant?: DynamicViewDisplayVariant | undefined;
  relationshipBrowserScope?: RelationshipBrowserScope | undefined;
  features?: EnabledFeatures;
}
type ToggledFeatures = { [P in `enable${TogglableFeature}`]?: boolean; };
interface Context extends Input {
  relationshipBrowserScope: RelationshipBrowserScope;
  xynodes: Types.Node[];
  xyedges: Types.Edge[];
  features: EnabledFeatures;
  toggledFeatures: ToggledFeatures;
  initialized: {
    xydata: boolean;
    xyflow: boolean;
  };
  viewport: Viewport;
  viewportChangedManually: boolean;
  /**
   * Viewport before entering focus mode, walkthrough or printing
   */
  viewportBefore: null | {
    wasChangedManually: boolean;
    value: Viewport;
  };
  viewportOnManualLayout: null | Viewport;
  viewportOnAutoLayout: null | Viewport;
  lastOnNavigate: null | {
    fromView: ViewId$1;
    toView: ViewId$1;
    fromNode: NodeId$1 | null;
    focusOnElement?: Fqn$1 | null;
  };
  navigationHistory: NavigationHistory;
  lastClickedNode: null | {
    id: NodeId$1;
    clicks: number;
    timestamp: number;
  };
  focusedNode: NodeId$1 | null;
  autoUnfocusTimer: boolean;
  activeElementDetails: null | {
    fqn: Fqn$1;
    fromNode: NodeId$1 | null;
    nodeRect?: Rect | null;
    nodeRectScreen?: Rect | null;
  };
  xyflow: XYFlowInstance | null;
  dynamicViewVariant: DynamicViewDisplayVariant;
  elementViewVariant: ElementViewDisplayVariant;
  activeWalkthrough: null | {
    stepId: StepPath;
    activeFlow: StepPath | null;
    outlinePanelWidth: number;
  };
  collapsedSequenceFlows: {
    [flowId: StepPath]: boolean;
  };
  minZoom: number;
  maxZoom: number;
}
declare function Context({ input }: {
  input: Input;
}): Context;
type Events = HotKeyEvent | MediaPrintEvent | {
  type: 'xyflow.init';
  instance: XYFlowInstance;
} | {
  type: 'xyflow.applyChanges';
  edges?: EdgeChange<Types.Edge>[];
  nodes?: NodeChange<Types.Node>[];
} | {
  type: 'xyflow.viewportMoved';
  viewport: Viewport;
  manually: boolean;
} | {
  type: 'xyflow.nodeClick';
  node: Types.Node;
} | {
  type: 'xyflow.edgeClick';
  edge: Types.Edge;
} | {
  type: 'xyflow.edgeDoubleClick';
  edge: Types.Edge;
} | {
  type: 'xyflow.paneClick';
} | {
  type: 'xyflow.paneDblClick';
} | {
  type: 'xyflow.resized';
} | {
  type: 'xyflow.nodeMouseEnter';
  node: Types.Node | NodeId$1;
} | {
  type: 'xyflow.nodeMouseLeave';
  node: Types.Node | NodeId$1;
} | {
  type: 'xyflow.edgeMouseEnter';
  edge: Types.Edge;
  event: MouseEvent$1;
} | {
  type: 'xyflow.edgeMouseLeave';
  edge: Types.Edge;
  event: MouseEvent$1;
} | {
  type: 'xyflow.fitDiagram';
  duration?: number;
  bounds?: BBox$1;
} | {
  type: 'xyflow.setViewport';
  duration?: number;
  viewport: Viewport;
} | {
  type: 'xyflow.centerViewport';
  nodeId: NodeId$1;
  duration?: number;
} | {
  type: 'xyflow.centerViewport';
  edgeId: EdgeId$1;
  duration?: number;
} | {
  type: 'xyflow.resetSelection';
} | {
  type: 'xyflow.select';
  nodes?: NodeId$1[] | undefined;
  edges?: EdgeId$1[] | undefined;
} | {
  type: 'update.nodeData';
  nodeId: NodeId$1;
  data: PartialDeep<Types.NodeData>;
} | {
  type: 'update.edgeData';
  edgeId: EdgeId$1;
  data: PartialDeep<Types.EdgeData>;
} | {
  type: 'update.view';
  view: DiagramView;
  source?: 'editor' | 'external';
} | {
  type: 'update.view';
  view: DiagramView;
  source?: 'editor' | 'external';
  xynodes: Types.Node[];
  xyedges: Types.Edge[];
} | {
  type: 'update.view-bounds';
  bounds: BBox$1;
} | {
  type: 'update.inputs';
  inputs: Partial<Omit<Input, 'view' | 'xystore' | 'dynamicViewVariant' | 'features'>>;
} | {
  type: 'update.features';
  features: EnabledFeatures;
} | ({
  type: 'open.source';
} & OpenSourceParams) | {
  type: 'open.elementDetails';
  fqn: Fqn$1;
  fromNode?: NodeId$1 | undefined;
} | {
  type: 'open.relationshipDetails';
  params: {
    edgeId: EdgeId$1;
  } | {
    source: Fqn$1;
    target: Fqn$1;
  };
} | {
  type: 'open.relationshipsBrowser';
  fqn: Fqn$1;
  scope?: RelationshipBrowserScope | undefined;
} | {
  type: 'open.search';
  search?: string;
} | {
  type: 'navigate.to';
  viewId: ViewId$1;
  fromNode?: NodeId$1 | undefined;
  focusOnElement?: Fqn$1 | undefined;
} | {
  type: 'navigate.back';
} | {
  type: 'navigate.forward';
} | {
  type: 'layout.align';
  mode: AlignmentMode;
} | {
  type: 'layout.resetEdgeControlPoints';
} | {
  type: 'layout.resetManualLayout';
} | {
  type: 'focus.node';
  nodeId: NodeId$1;
  autoUnfocus?: boolean;
} | {
  type: 'focus.autoUnfocus';
} | {
  type: 'switch.dynamicViewVariant';
  variant: DynamicViewDisplayVariant;
} | {
  type: 'switch.elementViewVariant';
  variant: ElementViewDisplayVariant;
} | {
  type: 'walkthrough.start';
  stepId?: StepPath | undefined;
} | {
  type: 'walkthrough.step';
  direction: 'next' | 'prev';
  stepId?: never;
} | {
  type: 'walkthrough.step';
  stepId: StepPath;
  direction?: never;
} | {
  type: 'walkthrough.end';
} | {
  type: 'sequence.flow.collapse';
  flowId: StepPath;
} | {
  type: 'sequence.flow.expand';
  flowId: StepPath;
} | {
  type: 'sequence.flow.toggle';
  flowId: StepPath;
} | {
  type: 'sequence.walkthrough.end';
} | {
  type: 'highlight.node';
  nodeId: NodeId$1;
} | {
  type: 'highlight.edge';
  edgeId: EdgeId$1;
} | {
  type: 'unhighlight.all';
} | {
  type: 'notations.highlight';
  notation: NodeNotation;
  kind?: string;
} | {
  type: 'notations.unhighlight';
} | {
  type: 'tag.highlight';
  tag: string;
} | {
  type: 'tag.unhighlight';
} | {
  type: 'toggle.feature';
  feature: TogglableFeature;
  forceValue?: boolean;
} | {
  type: 'trigger.change';
  change: ViewChange;
} | {
  type: 'emit.onLayoutTypeChange';
  layoutType: LayoutType;
} | {
  type: 'destroy';
};
type EmittedEvents = {
  type: 'initialized';
  instance: XYFlowInstance;
} | {
  type: 'navigateTo';
  viewId: ViewId$1;
} | {
  type: 'openSource';
  params: OpenSourceParams;
} | {
  type: 'paneClick';
} | {
  type: 'nodeClick';
  node: DiagramNode;
  xynode: Types.Node;
} | {
  type: 'edgeClick';
  edge: DiagramEdge;
  xyedge: Types.Edge;
} | {
  type: 'edgeMouseEnter';
  edge: Types.Edge;
  event: MouseEvent$1;
} | {
  type: 'edgeMouseLeave';
  edge: Types.Edge;
  event: MouseEvent$1;
} | {
  type: 'walkthroughStarted';
  edge: Types.Edge;
} | {
  type: 'walkthroughStep';
  edge: Types.Edge;
  stepId: StepPath;
} | {
  type: 'walkthroughStopped';
} | {
  type: 'onLayoutTypeChange';
  layoutType: LayoutType;
};
declare const actors: {
  hotkey: HotkeyActorLogic;
  overlays: OverlaysActorLogic;
  search: SearchActorLogic;
  mediaPrint: MediaPrintActorLogic;
  editor: EditorActorLogic;
  navigationPanel: NavigationPanelActorLogic;
};
type ChildrenActors = typeof actors;
type ActorLogicMap = { [K in keyof ChildrenActors]: ActorRefFromLogic<ChildrenActors[K]> | undefined; };
type ChildrenActor = { [K in keyof ChildrenActors]: {
  id: K;
  logic: ChildrenActors[K];
  src: K;
}; }[keyof ChildrenActors];
/**
 * Here is a trick to reduce inference types
 */
interface BaseDiagramMachineLogic<Actors extends Partial<ActorLogicMap> = ActorLogicMap, State extends StateValue = never> extends StateMachine<Context, Events, Actors & Omit<ActorLogicMap, keyof Actors>, ChildrenActor, never, never, never, State, never, Input, never, EmittedEvents, never, never> {}
//#endregion
//#endregion
//#region ../diagram/dist/likec4diagram/state/machine.d.mts
//#region src/likec4diagram/state/machine.d.ts
declare const _diagramMachine: StateMachine<Context, Events, {
  search?: ActorRefFromLogic<SearchActorLogic>;
  hotkey?: ActorRefFromLogic<HotkeyActorLogic>;
  overlays?: ActorRefFromLogic<OverlaysActorLogic>;
  mediaPrint?: ActorRefFromLogic<MediaPrintActorLogic>;
  editor?: ActorRefFromLogic<EditorActorLogic>;
  navigationPanel?: ActorRefFromLogic<NavigationPanelActorLogic>;
}, {
  src: "search";
  logic: SearchActorLogic;
  id: "search";
} | {
  src: "hotkey";
  logic: HotkeyActorLogic;
  id: "hotkey";
} | {
  src: "overlays";
  logic: OverlaysActorLogic;
  id: "overlays";
} | {
  src: "mediaPrint";
  logic: MediaPrintActorLogic;
  id: "mediaPrint";
} | {
  src: "editor";
  logic: EditorActorLogic;
  id: "editor";
} | {
  src: "navigationPanel";
  logic: NavigationPanelActorLogic;
  id: "navigationPanel";
}, never, {
  type: "isReady";
  params: unknown;
} | {
  type: "enabled: Editor";
  params: unknown;
} | {
  type: "enabled: FitView";
  params: unknown;
} | {
  type: "enabled: FocusMode";
  params: unknown;
} | {
  type: "enabled: Readonly";
  params: unknown;
} | {
  type: "enabled: RelationshipDetails";
  params: unknown;
} | {
  type: "enabled: Search";
  params: unknown;
} | {
  type: "enabled: ElementDetails";
  params: unknown;
} | {
  type: "enabled: OpenSource";
  params: unknown;
} | {
  type: "enabled: DynamicViewWalkthrough";
  params: unknown;
} | {
  type: "enabled: NavigationPanel";
  params: unknown;
} | {
  type: "focus.node: autoUnfocus";
  params: unknown;
} | {
  type: "enabled: Overlays";
  params: unknown;
} | {
  type: "not readonly";
  params: unknown;
} | {
  type: "is dynamic view";
  params: unknown;
} | {
  type: "is dynamic view in sequence variant";
  params: unknown;
} | {
  type: "is same view";
  params: unknown;
} | {
  type: "is another view";
  params: unknown;
} | {
  type: "click: node has modelFqn";
  params: unknown;
} | {
  type: "click: selected node";
  params: unknown;
} | {
  type: "click: same node";
  params: unknown;
} | {
  type: "click: focused node";
  params: unknown;
} | {
  type: "click: node.type = seq-subflow";
  params: unknown;
} | {
  type: "click: node has connections";
  params: unknown;
} | {
  type: "click: selected edge";
  params: unknown;
} | {
  type: "click: active walkthrough step";
  params: unknown;
}, never, "final" | "isReady" | "initializing" | "navigating" | {
  ready: "idle" | "walkthrough" | "focused" | "printing";
}, string, Input, NonReducibleUnknown, EmittedEvents, MetaObject, {
  states: {
    readonly initializing: {};
    readonly isReady: {};
    readonly ready: {
      states: {
        idle: {
          id: string;
        };
        focused: {
          id: string;
        };
        walkthrough: {
          id: string;
        };
        printing: {
          id: string;
        };
      };
    };
    readonly navigating: {
      id: string;
    };
    readonly final: {};
  };
}, MetaObject>;
interface DiagramMachineLogic extends BaseDiagramMachineLogic<{
  overlays: OverlaysActorRef | undefined;
  search: SearchActorRef | undefined;
  editor: BaseEditorActorRef | undefined;
  navigationPanel: NavigationPanelActorRef | undefined;
}, StateValueFrom<typeof _diagramMachine>> {}
type DiagramMachineSnapshot = SnapshotFrom<DiagramMachineLogic>;
interface DiagramMachineRef extends ActorRef<DiagramMachineSnapshot, Events, EmittedEvents> {}
//#endregion
//#region ../diagram/dist/likec4diagram/state/types.d.mts
//#region src/likec4diagram/state/types.d.ts
type System = ActorSystem<{
  actors: {
    diagram: DiagramMachineRef;
    overlays: OverlaysActorRef;
    search: SearchActorRef;
    editor: BaseEditorActorRef;
    navigationPanel: NavigationPanelActorRef;
  };
}>;
interface DiagramActorRef extends DiagramMachineRef {
  system: System;
}
//#endregion
//#region ../diagram/dist/likec4diagram/custom/nodes/CompoundActions.d.mts
//#region src/likec4diagram/custom/nodes/CompoundActions.d.ts
type CompoundActionsProps = Types.NodeProps<'compound-deployment' | 'compound-element'>;
export declare const CompoundActions: (props: CompoundActionsProps) => import("react").JSX.Element | null;
//#endregion
//#endregion
//#region ../diagram/dist/base-primitives/compound/CompoundActionButton.d.mts
//#region src/base-primitives/compound/CompoundActionButton.d.ts
type CompoundActionButtonProps = Simplify<BaseNodeProps & {
  icon?: ReactNode;
  ariaLabel?: string;
  onClick: (e: MouseEvent$1) => void;
}>;
export declare function CompoundActionButton({ selected, data: { hovered: isHovered }, icon, ariaLabel, onClick }: CompoundActionButtonProps): import("react").JSX.Element;
//#endregion
//#endregion
//#region ../diagram/dist/base-primitives/compound/CompoundDetailsButton.d.mts
//#region src/base-primitives/compound/CompoundDetailsButton.d.ts
type CompoundDetailsButtonProps = Simplify<BaseNodeProps & {
  icon?: ReactNode;
  ariaLabel?: string;
  onClick: (e: MouseEvent$1) => void;
}>;
export declare function CompoundDetailsButton({ selected, data: { hovered: isHovered }, icon, ariaLabel, onClick }: CompoundDetailsButtonProps): import("react").JSX.Element;
//#endregion
//#endregion
//#region ../diagram/dist/base-primitives/compound/CompoundNodeContainer.d.mts
//#region src/base-primitives/compound/CompoundNodeContainer.d.ts
type RequiredData$4 = {
  color: Color;
  depth: number;
  style: ElementStyle;
};
type CompoundNodeContainerProps = PropsWithChildren<HTMLAttributes<HTMLDivElement> & {
  layout?: boolean | 'position' | 'size' | 'preserve-aspect';
  layoutId?: string | undefined;
  nodeProps: BaseNodeProps<BaseNode<RequiredData$4>>;
}>;
export declare function CompoundNodeContainer({ nodeProps: { data: { hovered: isHovered, dimmed: isDimmed, ...data } }, className, children, style, ...rest }: CompoundNodeContainerProps): import("react").JSX.Element;
//#endregion
//#endregion
//#region ../diagram/dist/base-primitives/compound/CompoundTitle.d.mts
//#region src/base-primitives/compound/CompoundTitle.d.ts
type RequiredData$3 = {
  id: NodeId$1;
  title: string;
  color: Color;
  style: ComputedNodeStyle$1;
  icon?: string | null;
};
type CompoundTitleProps = {
  data: RequiredData$3;
  /**
   * Opt-in: hide the title from assistive technologies. The main diagram sets
   * this because the compound node's accessible label already conveys the
   * title, so re-exposing it here would cause a duplicate announcement.
   */
  'aria-hidden'?: boolean | undefined;
};
export declare function CompoundTitle({ data, 'aria-hidden': ariaHidden }: CompoundTitleProps): import("react").JSX.Element;
//#endregion
//#endregion
//#region ../diagram/dist/base-primitives/element/ElementActionButtons.d.mts
//#region src/base-primitives/element/ElementActionButtons.d.ts
type ElementActionButtonsProps = {
  selected?: boolean;
  data: {
    hovered?: boolean;
  };
  buttons: ElementActionButtons.Item[];
};
/**
 * Center-Bottom bar with action buttons. Intended to be used inside "leaf" nodes.
 *
 * @param selected - Whether the node is selected
 * @param data - Node data
 * @param buttons - Action buttons
 *
 * @example
 * ```tsx
 * <ElementActionButtons
 *   {...nodeProps}
 *   Buttons={[
 *     {
 *       key: 'action1',
 *       icon: <IconZoomScan />,
 *       onClick: (e) => {
 *         e.stopPropagation()
 *         console.log('action1 clicked')
 *       },
 *     },
 *     //...
 *   ]}
 * />
 * ```
 */
export declare function ElementActionButtons({ selected, data: { hovered: isHovered }, buttons }: ElementActionButtonsProps): import("react").JSX.Element | null;
export declare namespace ElementActionButtons {
  type Item = {
    key?: string;
    ariaLabel?: string;
    icon?: ReactNode;
    onClick: (e: MouseEvent$1) => void;
  };
}
//#endregion
//#endregion
//#region ../diagram/dist/base-primitives/element/ElementData.d.mts
//#region src/base-primitives/element/ElementData.d.ts
type RequiredData$2 = {
  id: NodeId;
  title: string;
  technology?: string | null | undefined;
  color: Color;
  shape?: ElementShape | undefined;
  style: ComputedNodeStyle;
  description?: MarkdownOrString | null | undefined;
  icon?: string | null;
  width?: number | undefined;
  height?: number | undefined;
};
type ElementDataProps = {
  data: RequiredData$2;
};
type IconProps = {
  data: {
    id: string;
    title: string;
    icon?: string | null | undefined;
  };
  className?: string;
  style?: CSSProperties;
};
type SlotProps = {
  data: RequiredData$2;
  className?: string;
  style?: CSSProperties;
  [key: `data-${string}`]: string;
};
/**
 * Renders an element title, technology, description, and icon.
 *
 * @example
 * ```tsx
 * <ElementData {...nodeProps} />
 * ```
 * or
 * ```tsx
 * <ElementData.Root {...nodeProps} >
 *   <ElementData.Icon {...nodeProps} />
 *   <ElementData.Content>
 *     <ElementData.Title {...nodeProps} />
 *     <ElementData.Technology {...nodeProps} />
 *     <ElementData.Description {...nodeProps} />
 *   </ElementData.Content>
 * </ElementData.Root>
 * ```
 */
export declare function ElementData({ data, 'aria-hidden': ariaHidden }: ElementDataProps & {
  'aria-hidden'?: boolean | undefined;
}): import("react").JSX.Element;
export declare namespace ElementData {
  var Root: import("react").ForwardRefExoticComponent<HTMLAttributes<HTMLDivElement> & ElementDataProps & import("react").RefAttributes<HTMLDivElement>>;
  var Icon: ({ data, ...props }: IconProps) => import("react").JSX.Element;
  var Content: import("react").ForwardRefExoticComponent<Omit<DetailedHTMLProps<HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "ref"> & import("react").RefAttributes<HTMLDivElement>>;
  var Title: import("react").ForwardRefExoticComponent<SlotProps & import("react").RefAttributes<HTMLDivElement>>;
  var Technology: import("react").ForwardRefExoticComponent<((import("type-fest/source/merge-exclusive").Without<SlotProps, {
    children?: import("react").ReactNode | undefined;
  }> & {
    children?: import("react").ReactNode | undefined;
  }) | (import("type-fest/source/merge-exclusive").Without<{
    children?: import("react").ReactNode | undefined;
  }, SlotProps> & SlotProps)) & import("react").RefAttributes<HTMLDivElement>>;
  var Description: import("react").ForwardRefExoticComponent<SlotProps & import("react").RefAttributes<HTMLDivElement>>;
}
//#endregion
//#endregion
//#region ../diagram/dist/base-primitives/element/ElementDetailsButton.d.mts
//#region src/base-primitives/element/ElementDetailsButton.d.ts
type ElementDetailsButtonProps = {
  selected?: boolean;
  data: BaseNodeData;
  icon?: ReactNode;
  ariaLabel?: string;
  onClick: (e: MouseEvent$1) => void;
};
export declare function ElementDetailsButton({ selected, data: { hovered: isHovered }, icon, ariaLabel, onClick }: ElementDetailsButtonProps): import("react").JSX.Element;
//#endregion
//#endregion
//#region ../../node_modules/.pnpm/motion-utils@12.39.0/node_modules/motion-utils/dist/index.d.ts
type EasingFunction = (v: number) => number;
//#endregion
//#region ../../node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/index.d.ts
interface MotionNodeLayoutOptions {
  /**
   * If `true`, this component will automatically animate to its new position when
   * its layout changes.
   *
   * ```jsx
   * <motion.div layout />
   * ```
   *
   * This will perform a layout animation using performant transforms. Part of this technique
   * involved animating an element's scale. This can introduce visual distortions on children,
   * `boxShadow` and `borderRadius`.
   *
   * To correct distortion on immediate children, add `layout` to those too.
   *
   * `boxShadow` and `borderRadius` will automatically be corrected if they are already being
   * animated on this component. Otherwise, set them directly via the `initial` prop.
   *
   * If `layout` is set to `"position"`, the size of the component will change instantly and
   * only its position will animate.
   *
   * If `layout` is set to `"size"`, the position of the component will change instantly and
   * only its size will animate.
   *
   * If `layout` is set to `"preserve-aspect"`, the component will animate size & position if
   * the aspect ratio remains the same between renders, and just position if the ratio changes.
   *
   * @public
   */
  layout?: boolean | "position" | "size" | "preserve-aspect" | "x" | "y";
  /**
   * Enable shared layout transitions between different components with the same `layoutId`.
   *
   * When a component with a layoutId is removed from the React tree, and then
   * added elsewhere, it will visually animate from the previous component's bounding box
   * and its latest animated values.
   *
   * ```jsx
   *   {items.map(item => (
   *      <motion.li layout>
   *         {item.name}
   *         {item.isSelected && <motion.div layoutId="underline" />}
   *      </motion.li>
   *   ))}
   * ```
   *
   * If the previous component remains in the tree it will crossfade with the new component.
   *
   * @public
   */
  layoutId?: string;
  /**
   * A callback that will fire when a layout animation on this component starts.
   *
   * @public
   */
  onLayoutAnimationStart?(): void;
  /**
   * A callback that will fire when a layout animation on this component completes.
   *
   * @public
   */
  onLayoutAnimationComplete?(): void;
  /**
   * @public
   */
  layoutDependency?: any;
  /**
   * Whether a projection node should measure its scroll when it or its descendants update their layout.
   *
   * @public
   */
  layoutScroll?: boolean;
  /**
   * Whether an element should be considered a "layout root", where
   * all children will be forced to resolve relatively to it.
   * Currently used for `position: sticky` elements in Framer.
   */
  layoutRoot?: boolean;
  /**
   * The anchor point for relative layout projection. This defines which
   * point on the parent is used as the reference for the child's position.
   *
   * `{ x: 0, y: 0 }` (default) anchors to the top-left corner.
   * `{ x: 0.5, y: 0.5 }` anchors to the center, useful for centered layouts
   * (e.g., flexbox) to prevent drift during parent layout animations.
   * `false` disables relative projection entirely.
   */
  layoutAnchor?: {
    x: number;
    y: number;
  } | false;
  /**
   * Attached to a portal root to ensure we attach the child to the document root and don't
   * perform scale correction on it.
   */
  "data-framer-portal-id"?: string;
  /**
   * By default, shared layout elements will crossfade. By setting this
   * to `false`, this element will take its default opacity throughout the animation.
   */
  layoutCrossfade?: boolean;
}
type AnyResolvedKeyframe = string | number;
interface ProgressTimeline {
  currentTime: null | {
    value: number;
  };
  cancel?: VoidFunction;
}
interface TimelineWithFallback {
  timeline?: ProgressTimeline;
  rangeStart?: string;
  rangeEnd?: string;
  observe: (animation: AnimationPlaybackControls) => VoidFunction;
}
/**
 * Methods to control an animation.
 */
interface AnimationPlaybackControls {
  /**
   * The current time of the animation, in seconds.
   */
  time: number;
  /**
   * The playback speed of the animation.
   * 1 = normal speed, 2 = double speed, 0.5 = half speed.
   */
  speed: number;
  /**
   * The start time of the animation, in milliseconds.
   */
  startTime: number | null;
  /**
   * The state of the animation.
   *
   * This is currently for internal use only.
   */
  state: AnimationPlayState;
  duration: number;
  /**
   * The duration of the animation, including any delay.
   */
  iterationDuration: number;
  /**
   * Stops the animation at its current state, and prevents it from
   * resuming when the animation is played again.
   */
  stop: () => void;
  /**
   * Plays the animation.
   */
  play: () => void;
  /**
   * Pauses the animation.
   */
  pause: () => void;
  /**
   * Completes the animation and applies the final state.
   */
  complete: () => void;
  /**
   * Cancels the animation and applies the initial state.
   */
  cancel: () => void;
  /**
   * Attaches a timeline to the animation, for instance the `ScrollTimeline`.
   *
   * This is currently for internal use only.
   */
  attachTimeline: (timeline: TimelineWithFallback) => VoidFunction;
  finished: Promise<any>;
}
type AnimationPlaybackControlsWithThen = AnimationPlaybackControls & {
  then: (onResolve: VoidFunction, onReject?: VoidFunction) => Promise<void>;
};
interface TransformProperties {
  x?: AnyResolvedKeyframe;
  y?: AnyResolvedKeyframe;
  z?: AnyResolvedKeyframe;
  translateX?: AnyResolvedKeyframe;
  translateY?: AnyResolvedKeyframe;
  translateZ?: AnyResolvedKeyframe;
  rotate?: AnyResolvedKeyframe;
  rotateX?: AnyResolvedKeyframe;
  rotateY?: AnyResolvedKeyframe;
  rotateZ?: AnyResolvedKeyframe;
  scale?: AnyResolvedKeyframe;
  scaleX?: AnyResolvedKeyframe;
  scaleY?: AnyResolvedKeyframe;
  scaleZ?: AnyResolvedKeyframe;
  skew?: AnyResolvedKeyframe;
  skewX?: AnyResolvedKeyframe;
  skewY?: AnyResolvedKeyframe;
  originX?: AnyResolvedKeyframe;
  originY?: AnyResolvedKeyframe;
  originZ?: AnyResolvedKeyframe;
  perspective?: AnyResolvedKeyframe;
  transformPerspective?: AnyResolvedKeyframe;
}
interface SVGPathProperties {
  pathLength?: number;
  pathOffset?: number;
  pathSpacing?: number;
}
/**
 * @public
 */
type Subscriber<T> = (v: T) => void;
/**
 * @public
 */
type PassiveEffect<T> = (v: T, safeSetter: (v: T) => void) => void;
type StartAnimation = (complete: () => void) => AnimationPlaybackControlsWithThen | undefined;
interface MotionValueEventCallbacks<V> {
  animationStart: () => void;
  animationComplete: () => void;
  animationCancel: () => void;
  change: (latestValue: V) => void;
  destroy: () => void;
}
interface ResolvedValues {
  [key: string]: AnyResolvedKeyframe;
}
interface Owner {
  current: HTMLElement | unknown;
  getProps: () => {
    onUpdate?: (latest: ResolvedValues) => void;
    transformTemplate?: (transform: TransformProperties, generatedTransform: string) => string;
  };
}
interface AccelerateConfig {
  factory: (animation: AnimationPlaybackControlsWithThen) => VoidFunction;
  times: number[];
  keyframes: any[];
  ease?: EasingFunction | EasingFunction[];
  duration: number;
  isTransformed?: boolean;
}
interface MotionValueOptions {
  owner?: Owner;
}
/**
 * `MotionValue` is used to track the state and velocity of motion values.
 *
 * @public
 */
declare class MotionValue<V = any> {
  /**
   * If a MotionValue has an owner, it was created internally within Motion
   * and therefore has no external listeners. It is therefore safe to animate via WAAPI.
   */
  owner?: Owner;
  /**
   * The current state of the `MotionValue`.
   */
  private current;
  /**
   * The previous state of the `MotionValue`.
   */
  private prev;
  /**
   * The previous state of the `MotionValue` at the end of the previous frame.
   */
  private prevFrameValue;
  /**
   * The last time the `MotionValue` was updated.
   */
  updatedAt: number;
  /**
   * The time `prevFrameValue` was updated.
   */
  prevUpdatedAt: number | undefined;
  private stopPassiveEffect?;
  /**
   * Whether the passive effect is active.
   */
  isEffectActive?: boolean;
  /**
   * A reference to the currently-controlling animation.
   */
  animation?: AnimationPlaybackControlsWithThen;
  /**
   * A list of MotionValues whose values are computed from this one.
   * This is a rough start to a proper signal-like dirtying system.
   */
  private dependents;
  /**
   * Tracks whether this value should be removed
   */
  liveStyle?: boolean;
  /**
   * Scroll timeline acceleration metadata. When set, VisualElement
   * can create a native WAAPI animation attached to a scroll timeline
   * instead of driving updates through JS.
   */
  accelerate?: AccelerateConfig;
  /**
   * @param init - The initiating value
   * @param config - Optional configuration options
   *
   * -  `transformer`: A function to transform incoming values with.
   */
  constructor(init: V, options?: MotionValueOptions);
  setCurrent(current: V): void;
  setPrevFrameValue(prevFrameValue?: V | undefined): void;
  /**
   * Adds a function that will be notified when the `MotionValue` is updated.
   *
   * It returns a function that, when called, will cancel the subscription.
   *
   * When calling `onChange` inside a React component, it should be wrapped with the
   * `useEffect` hook. As it returns an unsubscribe function, this should be returned
   * from the `useEffect` function to ensure you don't add duplicate subscribers..
   *
   * ```jsx
   * export const MyComponent = () => {
   *   const x = useMotionValue(0)
   *   const y = useMotionValue(0)
   *   const opacity = useMotionValue(1)
   *
   *   useEffect(() => {
   *     function updateOpacity() {
   *       const maxXY = Math.max(x.get(), y.get())
   *       const newOpacity = transform(maxXY, [0, 100], [1, 0])
   *       opacity.set(newOpacity)
   *     }
   *
   *     const unsubscribeX = x.on("change", updateOpacity)
   *     const unsubscribeY = y.on("change", updateOpacity)
   *
   *     return () => {
   *       unsubscribeX()
   *       unsubscribeY()
   *     }
   *   }, [])
   *
   *   return <motion.div style={{ x }} />
   * }
   * ```
   *
   * @param subscriber - A function that receives the latest value.
   * @returns A function that, when called, will cancel this subscription.
   *
   * @deprecated
   */
  onChange(subscription: Subscriber<V>): () => void;
  /**
   * An object containing a SubscriptionManager for each active event.
   */
  private events;
  on<EventName extends keyof MotionValueEventCallbacks<V>>(eventName: EventName, callback: MotionValueEventCallbacks<V>[EventName]): VoidFunction;
  clearListeners(): void;
  /**
   * Attaches a passive effect to the `MotionValue`.
   */
  attach(passiveEffect: PassiveEffect<V>, stopPassiveEffect: VoidFunction): void;
  /**
   * Sets the state of the `MotionValue`.
   *
   * @remarks
   *
   * ```jsx
   * const x = useMotionValue(0)
   * x.set(10)
   * ```
   *
   * @param latest - Latest value to set.
   * @param render - Whether to notify render subscribers. Defaults to `true`
   *
   * @public
   */
  set(v: V): void;
  setWithVelocity(prev: V, current: V, delta: number): void;
  /**
   * Set the state of the `MotionValue`, stopping any active animations,
   * effects, and resets velocity to `0`.
   */
  jump(v: V, endAnimation?: boolean): void;
  dirty(): void;
  addDependent(dependent: MotionValue): void;
  removeDependent(dependent: MotionValue): void;
  updateAndNotify: (v: V) => void;
  /**
   * Returns the latest state of `MotionValue`
   *
   * @returns - The latest state of `MotionValue`
   *
   * @public
   */
  get(): NonNullable<V>;
  /**
   * @public
   */
  getPrevious(): V | undefined;
  /**
   * Returns the latest velocity of `MotionValue`
   *
   * @returns - The latest velocity of `MotionValue`. Returns `0` if the state is non-numerical.
   *
   * @public
   */
  getVelocity(): number;
  hasAnimated: boolean;
  /**
   * Registers a new animation to control this `MotionValue`. Only one
   * animation can drive a `MotionValue` at one time.
   *
   * ```jsx
   * value.start()
   * ```
   *
   * @param animation - A function that starts the provided animation
   */
  start(startAnimation: StartAnimation): Promise<void>;
  /**
   * Stop the currently active animation.
   *
   * @public
   */
  stop(): void;
  /**
   * Returns `true` if this value is currently animating.
   *
   * @public
   */
  isAnimating(): boolean;
  private clearAnimation;
  /**
   * Destroy and clean up subscribers to this `MotionValue`.
   *
   * The `MotionValue` hooks like `useMotionValue` and `useTransform` automatically
   * handle the lifecycle of the returned `MotionValue`, so this method is only necessary if you've manually
   * created a `MotionValue` via the `motionValue` function.
   *
   * @public
   */
  destroy(): void;
}
declare const optimizedAppearDataAttribute: "data-framer-appear-id";
type Process = (data: FrameData) => void;
type Schedule = (process: Process, keepAlive?: boolean, immediate?: boolean) => Process;
type StepId = "setup" | "read" | "resolveKeyframes" | "preUpdate" | "update" | "preRender" | "render" | "postRender";
type Batcher = { [key in StepId]: Schedule; };
interface FrameData {
  delta: number;
  timestamp: number;
  isProcessing: boolean;
}
/**
 * Expose only the needed part of the VisualElement interface to
 * ensure React types don't end up in the generic DOM bundle.
 */
interface WithAppearProps {
  props: {
    [optimizedAppearDataAttribute]?: string;
    values?: {
      [key: string]: MotionValue<number> | MotionValue<string>;
    };
  };
}
type HandoffFunction = (storeId: string, valueName: string, frame: Batcher) => number | null;
/**
 * The window global object acts as a bridge between our inline script
 * triggering the optimized appear animations, and Motion.
 */
declare global {
  interface Window {
    MotionHandoffAnimation?: HandoffFunction;
    MotionHandoffMarkAsComplete?: (elementId: string) => void;
    MotionHandoffIsComplete?: (elementId: string) => boolean;
    MotionHasOptimisedAnimation?: (elementId?: string, valueName?: string) => boolean;
    MotionCancelOptimisedAnimation?: (elementId?: string, valueName?: string, frame?: Batcher, canResume?: boolean) => void;
    MotionCheckAppearSync?: (visualElement: WithAppearProps, valueName: string, value: MotionValue) => VoidFunction | void;
    MotionIsMounted?: boolean;
  }
}
declare global {
  interface Window {
    ScrollTimeline: ScrollTimeline;
    ViewTimeline: ViewTimeline;
  }
}
declare class ScrollTimeline implements ProgressTimeline {
  constructor(options: ScrollOptions);
  currentTime: null | {
    value: number;
  };
  cancel?: VoidFunction;
}
declare class ViewTimeline implements ProgressTimeline {
  constructor(options: {
    subject: Element;
    axis?: string;
  });
  currentTime: null | {
    value: number;
  };
  cancel?: VoidFunction;
}
//#endregion
//#region ../../node_modules/.pnpm/framer-motion@12.43.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/framer-motion/dist/index.d.ts
type MotionValueString = MotionValue<string>;
type MotionValueNumber = MotionValue<number>;
type MotionValueAny = MotionValue<any>;
type AnyMotionValue = MotionValueNumber | MotionValueString | MotionValueAny;
type MotionValueHelper<T> = T | AnyMotionValue;
type MakeMotionHelper<T> = { [K in keyof T]: MotionValueHelper<T[K]>; };
type MakeCustomValueTypeHelper<T> = MakeMotionHelper<T>;
type MakeMotion<T> = MakeCustomValueTypeHelper<T>;
type MotionCSS = MakeMotion<Omit<CSSProperties, "rotate" | "scale" | "perspective" | "x" | "y" | "z">>;
/**
 * @public
 */
type MotionTransform = MakeMotion<TransformProperties>;
type MotionSVGProps = MakeMotion<SVGPathProperties>;
/**
 * @public
 */
interface MotionStyle extends MotionCSS, MotionTransform, MotionSVGProps {}
//#endregion
//#region ../diagram/dist/base-primitives/element/ElementNodeContainer.d.mts
//#region src/base-primitives/element/ElementNodeContainer.d.ts
type RequiredData$1 = {
  color: Color;
  shape: ElementShape$2;
  style?: ComputedNodeStyle$1;
};
/**
 * Top-level primitive to compose leaf nodes renderers.
 * This container provides the state via data-* attributes
 */
export declare const ElementNodeContainer: import("react").ForwardRefExoticComponent<{
  [key: `data-${string}`]: string | undefined;
  nodeProps: BaseNodePropsWithData<RequiredData$1>;
  className?: string | undefined;
  style?: MotionStyle | undefined;
} & MotionNodeLayoutOptions & {
  children?: import("react").ReactNode | undefined;
} & import("react").RefAttributes<HTMLDivElement>>;
//#endregion
//#endregion
//#region ../diagram/dist/base-primitives/element/ElementShape.d.mts
//#region src/base-primitives/element/ElementShape.d.ts
type RequiredData = {
  shape: ElementShape$1;
  width: number;
  height: number;
  style?: ComputedNodeStyle$1;
};
type ElementShapeProps = {
  data: RequiredData;
  width?: number | undefined;
  height?: number | undefined;
  /**
   * @default true
   */
  showSelectionOutline?: boolean | undefined;
};
declare function ElementShape$1({ data, width, height, showSelectionOutline }: ElementShapeProps): import("react").JSX.Element;
//#endregion
//#region ../diagram/dist/base-primitives/element/ElementTags.d.mts
//#region src/base-primitives/element/ElementTags.d.ts
export declare const ElementTag: import("react").ForwardRefExoticComponent<{
  tag: string;
  cursor?: "pointer" | "default";
} & Omit<Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "ref">, "color" | "children" | "translate"> & import("react").RefAttributes<HTMLDivElement>>;
type Data = {
  tags: readonly string[] | null | undefined;
  width: number;
};
type ElementTagsProps = BaseNodePropsWithData<Data> & {
  onTagClick?: (tag: `#${string}`) => void;
  onTagMouseEnter?: (tag: `#${string}`) => void;
  onTagMouseLeave?: (tag: `#${string}`) => void;
};
export declare const ElementTags: import("react").MemoExoticComponent<({ id, data: { tags, width, hovered }, onTagClick, onTagMouseEnter, onTagMouseLeave }: ElementTagsProps) => import("react").JSX.Element | null>;
//#endregion
//#endregion
//#region styled-system/tokens/tokens.d.mts
type FontSizeToken = "xxs" | "xs" | "sm" | "md" | "lg" | "xl" | "likec4.xs" | "likec4.sm" | "likec4.md" | "likec4.lg" | "likec4.xl" | "h1" | "h2" | "h3" | "h4" | "h5" | "h6";
type FontWeightToken = "normal" | "medium" | "semibold" | "bold" | "extrabold" | "display";
type LineHeightToken = "1" | "tight" | "snug" | "xs" | "sm" | "md" | "lg" | "xl";
type FontToken = "display" | "mono" | "body" | "likec4" | "likec4.element" | "likec4.compound" | "likec4.relation";
type LetterSpacingToken = "display" | "tight" | "normal" | "caps" | "caps.sm";
type SizeToken = "0" | "auto" | "max-content" | "min-content" | "fit-content" | "stretch" | "100cqw" | "100cqh" | "100vw" | "100vh" | "100%" | "50%" | "full" | "control.sm" | "control.md" | "control.lg" | "action-icon" | "icon" | "icon.xxs" | "icon.xs" | "icon.sm" | "icon.md" | "icon.lg" | "icon.xl" | "breakpoint-xs" | "breakpoint-sm" | "breakpoint-md" | "breakpoint-lg" | "breakpoint-xl";
type BorderToken = "none" | "transparent" | "subtle" | "default" | "strong" | "outline" | "panel";
type BorderWidthToken = "0" | "1" | "2" | "3" | "4" | "default" | "strong" | "extra";
type SpacingToken = "0" | "1" | "2" | "3" | "4" | "5" | "6" | "7" | "8" | "9" | "10" | "12" | "16" | "0.5" | "1.5" | "2.5" | "3.5" | "4.5" | "xxs" | "xs" | "sm" | "md" | "lg" | "xl" | "likec4.xs" | "likec4.sm" | "likec4.md" | "likec4.lg" | "likec4.xl" | "-0" | "-1" | "-2" | "-3" | "-4" | "-5" | "-6" | "-7" | "-8" | "-9" | "-10" | "-12" | "-16" | "-0.5" | "-1.5" | "-2.5" | "-3.5" | "-4.5" | "-xxs" | "-xs" | "-sm" | "-md" | "-lg" | "-xl" | "-likec4.xs" | "-likec4.sm" | "-likec4.md" | "-likec4.lg" | "-likec4.xl";
type RadiusToken = "0" | "xs" | "sm" | "md" | "lg" | "xl" | "pill";
type ColorToken = "mantine.gray[0]" | "mantine.gray[1]" | "mantine.gray[2]" | "mantine.gray[3]" | "mantine.gray[4]" | "mantine.gray[5]" | "mantine.gray[6]" | "mantine.gray[7]" | "mantine.gray[8]" | "mantine.gray[9]" | "mantine.dark[0]" | "mantine.dark[1]" | "mantine.dark[2]" | "mantine.dark[3]" | "mantine.dark[4]" | "mantine.dark[5]" | "mantine.dark[6]" | "mantine.dark[7]" | "mantine.dark[8]" | "mantine.dark[9]" | "mantine.orange[0]" | "mantine.orange[1]" | "mantine.orange[2]" | "mantine.orange[3]" | "mantine.orange[4]" | "mantine.orange[5]" | "mantine.orange[6]" | "mantine.orange[7]" | "mantine.orange[8]" | "mantine.orange[9]" | "mantine.yellow[0]" | "mantine.yellow[1]" | "mantine.yellow[2]" | "mantine.yellow[3]" | "mantine.yellow[4]" | "mantine.yellow[5]" | "mantine.yellow[6]" | "mantine.yellow[7]" | "mantine.yellow[8]" | "mantine.yellow[9]" | "transparent" | "none" | "inherit" | "current" | "currentColor" | "white" | "black" | "likec4.accent.0" | "likec4.accent.1" | "likec4.accent.2" | "likec4.accent.3" | "likec4.accent.4" | "likec4.accent.5" | "likec4.accent.6" | "likec4.accent.7" | "likec4.accent.8" | "likec4.accent.9" | "likec4.accent" | "surface.canvas" | "surface.default" | "surface.sunken" | "surface.sunken.hover" | "surface.code" | "surface.field" | "surface.field.hover" | "surface.hover" | "surface.selected" | "text" | "text.default" | "text.bright" | "text.dimmed" | "text.non-essential" | "text.display" | "text.heading" | "text.link" | "text.on-primary" | "text.on-inverse" | "text.warning" | "border.subtle" | "border.default" | "border.strong" | "border.focus" | "border.outline" | "disabled.body" | "disabled.text" | "disabled.border" | "highlight.body" | "highlight.text" | "primary.body" | "primary.body.hover" | "primary.body.focused" | "primary.body.light" | "primary.body.lightHover" | "primary.text" | "primary.text.light" | "primary.border" | "primary.border.hover" | "primary.border.focused" | "warning.body" | "warning.text" | "diagram.background" | "diagram.background.pattern" | "likec4.mixColor" | "likec4.tag.bg" | "likec4.tag.bg.hover" | "likec4.tag.border" | "likec4.tag.text" | "likec4.panel.bg" | "likec4.panel.border" | "likec4.panel.text" | "likec4.panel.text.dimmed" | "likec4.panel.action" | "likec4.panel.action.disabled" | "likec4.panel.action.hover" | "likec4.panel.action.bg" | "likec4.panel.action.bg.hover" | "likec4.panel.action.warning" | "likec4.panel.action.warning.hover" | "likec4.panel.action.warning.bg" | "likec4.panel.action.warning.bg.hover" | "likec4.dropdown.bg" | "likec4.dropdown.border" | "likec4.overlay.backdrop" | "likec4.overlay.body" | "likec4.overlay.border" | "likec4.walkthrough.parallelFrame" | "likec4.compare.manual" | "likec4.compare.outline" | "likec4.compare.latest" | "subflow.opt" | "subflow.opt.hovered" | "subflow.opt.text" | "subflow.opt.border" | "subflow.opt.label" | "subflow.loop" | "subflow.loop.hovered" | "subflow.loop.text" | "subflow.loop.border" | "subflow.loop.header" | "subflow.loop.label" | "subflow.try" | "subflow.try.hovered" | "subflow.try.text" | "subflow.try.border" | "subflow.try.header" | "subflow.try.label" | "subflow.break" | "subflow.break.hovered" | "subflow.break.text" | "subflow.break.border" | "subflow.break.header" | "subflow.break.label" | "subflow.par" | "subflow.par.hovered" | "subflow.par.text" | "subflow.par.border" | "subflow.par.header" | "subflow.par.label" | "subflow.alt" | "subflow.alt.hovered" | "subflow.alt.header" | "subflow.alt.text" | "subflow.alt.border" | "subflow.alt.label" | "amber.1" | "amber.2" | "amber.3" | "amber.4" | "amber.5" | "amber.6" | "amber.7" | "amber.8" | "amber.9" | "amber.10" | "amber.11" | "amber.12" | "blue.1" | "blue.2" | "blue.3" | "blue.4" | "blue.5" | "blue.6" | "blue.7" | "blue.8" | "blue.9" | "blue.10" | "blue.11" | "blue.12" | "crimson.1" | "crimson.2" | "crimson.3" | "crimson.4" | "crimson.5" | "crimson.6" | "crimson.7" | "crimson.8" | "crimson.9" | "crimson.10" | "crimson.11" | "crimson.12" | "grass.1" | "grass.2" | "grass.3" | "grass.4" | "grass.5" | "grass.6" | "grass.7" | "grass.8" | "grass.9" | "grass.10" | "grass.11" | "grass.12" | "indigo.1" | "indigo.2" | "indigo.3" | "indigo.4" | "indigo.5" | "indigo.6" | "indigo.7" | "indigo.8" | "indigo.9" | "indigo.10" | "indigo.11" | "indigo.12" | "lime.1" | "lime.2" | "lime.3" | "lime.4" | "lime.5" | "lime.6" | "lime.7" | "lime.8" | "lime.9" | "lime.10" | "lime.11" | "lime.12" | "orange.1" | "orange.2" | "orange.3" | "orange.4" | "orange.5" | "orange.6" | "orange.7" | "orange.8" | "orange.9" | "orange.10" | "orange.11" | "orange.12" | "pink.1" | "pink.2" | "pink.3" | "pink.4" | "pink.5" | "pink.6" | "pink.7" | "pink.8" | "pink.9" | "pink.10" | "pink.11" | "pink.12" | "purple.1" | "purple.2" | "purple.3" | "purple.4" | "purple.5" | "purple.6" | "purple.7" | "purple.8" | "purple.9" | "purple.10" | "purple.11" | "purple.12" | "red.1" | "red.2" | "red.3" | "red.4" | "red.5" | "red.6" | "red.7" | "red.8" | "red.9" | "red.10" | "red.11" | "red.12" | "ruby.1" | "ruby.2" | "ruby.3" | "ruby.4" | "ruby.5" | "ruby.6" | "ruby.7" | "ruby.8" | "ruby.9" | "ruby.10" | "ruby.11" | "ruby.12" | "teal.1" | "teal.2" | "teal.3" | "teal.4" | "teal.5" | "teal.6" | "teal.7" | "teal.8" | "teal.9" | "teal.10" | "teal.11" | "teal.12" | "tomato.1" | "tomato.2" | "tomato.3" | "tomato.4" | "tomato.5" | "tomato.6" | "tomato.7" | "tomato.8" | "tomato.9" | "tomato.10" | "tomato.11" | "tomato.12" | "violet.1" | "violet.2" | "violet.3" | "violet.4" | "violet.5" | "violet.6" | "violet.7" | "violet.8" | "violet.9" | "violet.10" | "violet.11" | "violet.12" | "yellow.1" | "yellow.2" | "yellow.3" | "yellow.4" | "yellow.5" | "yellow.6" | "yellow.7" | "yellow.8" | "yellow.9" | "yellow.10" | "yellow.11" | "yellow.12" | "colorPalette.opt" | "colorPalette" | "colorPalette.opt.hovered" | "colorPalette.hovered" | "colorPalette.opt.text" | "colorPalette.text" | "colorPalette.opt.border" | "colorPalette.border" | "colorPalette.opt.label" | "colorPalette.label" | "colorPalette.loop" | "colorPalette.loop.hovered" | "colorPalette.loop.text" | "colorPalette.loop.border" | "colorPalette.loop.header" | "colorPalette.header" | "colorPalette.loop.label" | "colorPalette.try" | "colorPalette.try.hovered" | "colorPalette.try.text" | "colorPalette.try.border" | "colorPalette.try.header" | "colorPalette.try.label" | "colorPalette.break" | "colorPalette.break.hovered" | "colorPalette.break.text" | "colorPalette.break.border" | "colorPalette.break.header" | "colorPalette.break.label" | "colorPalette.par" | "colorPalette.par.hovered" | "colorPalette.par.text" | "colorPalette.par.border" | "colorPalette.par.header" | "colorPalette.par.label" | "colorPalette.alt" | "colorPalette.alt.hovered" | "colorPalette.alt.header" | "colorPalette.alt.text" | "colorPalette.alt.border" | "colorPalette.alt.label";
type EasingToken = "default" | "in" | "out" | "inOut";
type DurationToken = "0" | "fastest" | "fast" | "medium" | "slow" | "slowest";
type ShadowToken = "none" | "xs" | "sm" | "md" | "lg" | "xl";
type ZIndexToken = "0" | "-1" | "base" | "sticky" | "floating" | "panel" | "dropdown" | "overlay" | "tooltip" | "toast" | "diagram.edge" | "diagram.edge.label" | "diagram.edge.controlPoint" | "diagram.node.compound" | "diagram.node.element";
type OpacityToken = "0" | "1" | "0.05" | "0.1" | "0.15" | "0.2" | "0.25" | "0.3" | "0.35" | "0.4" | "0.45" | "0.5" | "0.55" | "0.6" | "0.65" | "0.7" | "0.75" | "0.8" | "0.85" | "0.9" | "0.95" | "disabled";
type CursorToken = "default" | "pointer" | "none" | "inherit" | "grab" | "grabbing" | "move" | "zoom-out";
type BreakpointToken = "xs" | "sm" | "md" | "lg" | "xl";
type Tokens = {
  fontSizes: FontSizeToken;
  fontWeights: FontWeightToken;
  lineHeights: LineHeightToken;
  fonts: FontToken;
  letterSpacings: LetterSpacingToken;
  sizes: SizeToken;
  borders: BorderToken;
  borderWidths: BorderWidthToken;
  spacing: SpacingToken;
  radii: RadiusToken;
  colors: ColorToken;
  easings: EasingToken;
  durations: DurationToken;
  shadows: ShadowToken;
  zIndex: ZIndexToken;
  opacity: OpacityToken;
  cursor: CursorToken;
  breakpoints: BreakpointToken;
} & {
  [token: string]: never;
};
//#endregion
//#region ../diagram/dist/base-primitives/Markdown.d.mts
//#region src/base-primitives/Markdown.d.ts
export declare const Markdown: import("react").ForwardRefExoticComponent<Omit<Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "ref">, "color" | "children" | "dangerouslySetInnerHTML" | "translate"> & {
  value: RichTextOrEmpty;
  /**
   * When markdown block is used inside a diagram node, this variant should be used to apply the likec4 palette.
   * @default false
   */
  uselikec4palette?: boolean;
  /**
   * Scale factor for the block
   * @default 1
   */
  textScale?: number;
  /**
   * Font size for the block
   * @default 'md'
   */
  fontSize?: Tokens["fontSizes"] | undefined;
  /**
   * If true, the component will not render anything if the value is empty.
   * @default false
   */
  hideIfEmpty?: boolean | undefined;
  /**
   * Text to show if the value is empty.
   * @default "no content"
   */
  emptyText?: string;
} & import("react").RefAttributes<HTMLDivElement>>;
//#endregion
//#endregion
//#region ../diagram/dist/base-primitives/memoEdge.d.mts
//#region src/base-primitives/memoEdge.d.ts
export declare function memoEdge<P extends BaseEdgeProps>(Edge: FunctionComponent<P>): FunctionComponent<P>;
//#endregion
//#endregion
//#region ../diagram/dist/base-primitives/memoNode.d.mts
//#region src/base-primitives/memoNode.d.ts
export declare function memoNode<P extends BaseNodeProps>(Node: FunctionComponent<P>, displayName?: string): FunctionComponent<P>;
//#endregion
//#endregion
//#region ../diagram/dist/base-primitives/NodeHandles.d.mts
//#region src/base-primitives/NodeHandles.d.ts
/**
 * XYFlow requires handles to be defined on nodes.
 */
export declare function DefaultHandles({ direction }: {
  direction?: AutoLayoutDirection | undefined;
}): import("react").JSX.Element;
//#endregion
//#endregion
//#region ../diagram/dist/likec4diagram/custom/nodes/ElementActions.d.mts
//#region src/likec4diagram/custom/nodes/ElementActions.d.ts
type WithExtraButtons = {
  /**
   * Add extra action buttons
   * @example
   * ```tsx
   * <ElementActions
   *   extraButtons={[
   *     {
   *       key: 'extra',
   *       icon: <IconZoomScan />,
   *       onClick: (e) => {
   *         e.stopPropagation()
   *         console.log('extra action clicked')
   *       },
   *       },
   *     },
   *   ]}
   * />
   * ```
   */
  extraButtons?: ElementActionButtons.Item[];
};
type ElementActionsProps = SimplifyDeep<{
  selected?: boolean;
  data: Pick<Types.ElementNodeData, 'id' | 'modelFqn' | 'navigateTo' | 'title'> & BaseNodeData;
}> & WithExtraButtons;
/**
 * Center-Bottom action bar, includes zoom-in and browse relationships actions, if the features are enabled.
 * Intended to be used with model elements.
 *
 * Use generic {@link ElementActionButtons} for custom action buttons.
 *
 * @param extraButtons - Add extra action buttons
 *
 * @example
 * ```tsx
 * <ElementActions
 *   extraButtons={[
 *     {
 *       key: 'extra',
 *       icon: <IconZoomScan />,
 *       onClick: (e) => {
 *         e.stopPropagation()
 *         console.log('extra action clicked')
 *       },
 *       },
 *     },
 *   ]}
 * />
 * ```
 */
export declare function ElementActions({ extraButtons, ...props }: ElementActionsProps): import("react").JSX.Element;
type DeploymentElementActionsProps = SimplifyDeep<{
  selected?: boolean;
  data: Pick<Types.DeploymentElementNodeData, 'id' | 'modelFqn' | 'navigateTo' | 'title'> & BaseNodeData;
}> & WithExtraButtons;
/**
 * Center-Bottom action bar, includes zoom-in and browse relationships actions, if the features are enabled.
 * Intended to be used with deployment elements.
 *
 * Use generic {@link ElementActionButtons} for custom action buttons.
 *
 * @param extraButtons - Add extra action buttons
 *
 * @example
 * ```tsx
 * <DeploymentElementActions
 *   extraButtons={[
 *     {
 *       key: 'extra',
 *       icon: <IconZoomScan />,
 *       onClick: (e) => {
 *         e.stopPropagation()
 *         console.log('extra action clicked')
 *       },
 *       },
 *     },
 *   ]}
 * />
 * ```
 */
export declare const DeploymentElementActions: ({ extraButtons, ...props }: DeploymentElementActionsProps) => import("react").JSX.Element;
//#endregion
//#endregion
//#region ../diagram/dist/likec4diagram/custom/nodes/nodes.d.mts
//#region src/likec4diagram/custom/nodes/nodes.d.ts
export declare function ElementDetailsButtonWithHandler(props: {
  id: string;
  selected?: boolean;
  data: BaseNodeData & {
    modelFqn?: Fqn | null | undefined;
  };
}): import("react").JSX.Element | null;
export declare function CompoundDetailsButtonWithHandler(props: Types.NodeProps<'compound-deployment' | 'compound-element'>): import("react").JSX.Element | null;
/**
 * Renders an element node.
 */
declare function ElementNode$1(props: Types.NodeProps<'element'>): import("react").JSX.Element;
export declare function DeploymentNode(props: Types.NodeProps<'deployment'>): import("react").JSX.Element;
declare function CompoundElementNode$1(props: Types.NodeProps<'compound-element'>): import("react").JSX.Element;
declare function CompoundDeploymentNode$1(props: Types.NodeProps<'compound-deployment'>): import("react").JSX.Element;
declare function ViewGroupNode$1(props: Types.NodeProps<'view-group'>): import("react").JSX.Element;
//#endregion
//#endregion
//#region ../diagram/dist/likec4diagram/custom/nodes/SequenceActorNode.d.mts
//#region src/likec4diagram/custom/nodes/SequenceActorNode.d.ts
declare function SequenceActorNode$1(props: Types.NodeProps<'seq-actor'>): import("react").JSX.Element;
declare function SequenceParallelArea$1(props: Types.NodeProps<'seq-parallel'>): import("react").JSX.Element;
//#endregion
//#endregion
//#region ../diagram/dist/likec4diagram/custom/nodes/toolbar/CompoundToolbar.d.mts
//#region src/likec4diagram/custom/nodes/toolbar/CompoundToolbar.d.ts
export declare function CompoundElementToolbar(props: Types.NodeProps<'compound-element'>): import("react").JSX.Element;
export declare function CompoundDeploymentToolbar(props: Types.NodeProps<'compound-deployment'>): import("react").JSX.Element;
//#endregion
//#endregion
//#region ../diagram/dist/likec4diagram/custom/nodes/toolbar/ElementToolbar.d.mts
//#region src/likec4diagram/custom/nodes/toolbar/ElementToolbar.d.ts
export declare function ElementToolbar(props: Types.NodeProps<'element' | 'seq-actor'> & {
  data: {
    modelFqn: Fqn$1;
  };
}): import("react").JSX.Element;
export declare function DeploymentElementToolbar(props: Types.NodeProps<'deployment'>): import("react").JSX.Element;
//#endregion
//#endregion
//#region ../diagram/dist/likec4diagram/custom/nodes/toolbar/Toolbar.d.mts
//#region src/likec4diagram/custom/nodes/toolbar/Toolbar.d.ts
type ToolbarProps = Omit<NodeToolbarProps, 'title'> & {
  nodeProps: BaseNodeProps;
  title: ReactNode;
};
export declare function Toolbar({ title, children, nodeProps, ...props }: ToolbarProps): import("react").JSX.Element | null;
//#endregion
//#endregion
//#region ../diagram/dist/custom/customNodes.d.mts
//#region src/custom/customNodes.d.ts
type Any$1$3 = aux.Any;
type Unknown$2 = aux.UnknownLayouted;
/**
 * Node that will be used to render the element from the model.
 * It is a leaf node, i.e. it does not have children.
 *
 * Custom node renderer receives these props:
 * - `nodeProps`: props from XYFlow
 * - `nodeModel`: LikeC4 {@link NodeModel.WithElement}
 *
 * @see [Default implementation](https://github.com/likec4/likec4/blob/main/packages/diagram/src/likec4diagram/custom/nodes/nodes.tsx)
 *
 * @example
 * ```tsx
 * import {
 *   elementNode,
 *   ElementNodeContainer,
 *   ElementShape,
 *   ElementData,
 *   ElementActions,
 *   ElementDetailsButtonWithHandler,
 *   IfEnabled,
 *   IfNotReadOnly,
 *   ElementToolbar,
 *   DefaultHandles,
 *   ElementTags
 * } from '@likec4/diagram/custom'
 *
 * const CustomElementNode = elementNode(({ nodeProps, nodeModel }) => (
 *   <ElementNodeContainer nodeProps={nodeProps}>
 *     <ElementShape {...nodeProps} />
 *     <ElementData {...nodeProps} />
 *     <IfEnabled feature="ElementTags">
 *       <ElementTags {...nodeProps} />
 *     </IfEnabled>
 *     <ElementActions
 *       {...nodeProps}
 *       extraButtons={[
 *         {
 *           key: 'plus',
 *           icon: <IconPlus />,
 *           onClick: () => console.log('extra'),
 *         },
 *       ]}
 *     />
 *     <ElementDetailsButtonWithHandler {...nodeProps} />
 *     {nodeModel.element.getMetadata('your-attr') === 'value' && <YourComponent />}
 *     <IfNotReadOnly>
 *       <ElementToolbar {...nodeProps} />
 *     </IfNotReadOnly>
 *     <DefaultHandles />
 *   </ElementNodeContainer>
 * ))
 * ```
 */
export declare function elementNode<A extends Any$1$3 = Unknown$2>(component: FC<ElementNodeProps<A>>): Types.NodeRenderer<'element'>;
export type ElementNodeProps<A extends Any$1$3 = Unknown$2> = {
  nodeProps: Types.NodeProps<'element'>;
  nodeModel: NodeModel.WithElement<A>;
};
/**
 * Node that will be used to render the element from deployment model.
 * It is a leaf node, i.e. it does not have children.
 * Can be {@link DeploymentNodeModel} or {@link DeployedInstanceModel}.
 *
 * Custom node renderer receives these props:
 * - `nodeProps`: props from XYFlow
 * - `nodeModel`: {@link NodeModel.WithDeploymentElement}
 *
 * @see [Default implementation](https://github.com/likec4/likec4/blob/main/packages/diagram/src/likec4diagram/custom/nodes/nodes.tsx)
 *
 * @example
 * ```tsx
 * import {
 *   deploymentNode,
 *   ElementNodeContainer,
 *   ElementShape,
 *   ElementData,
 *   DeploymentElementActions,
 *   ElementDetailsButtonWithHandler,
 *   IfNotReadOnly,
 *   DeploymentElementToolbar,
 *   DefaultHandles,
 * } from '@likec4/diagram/custom'
 *
 * const CustomDeploymentNode = deploymentNode(({ nodeProps, nodeModel }) => (
 *   <ElementNodeContainer nodeProps={nodeProps}>
 *     <ElementShape {...nodeProps} />
 *     <ElementData {...nodeProps} />
 *     <DeploymentElementActions
 *       {...nodeProps}
 *       extraButtons={[
 *         {
 *           key: 'plus',
 *           icon: <IconPlus />,
 *           onClick: () => console.log('extra'),
 *         },
 *       ]}
 *     />
 *     <ElementDetailsButtonWithHandler {...nodeProps} />
 *     <IfNotReadOnly>
 *       <DeploymentElementToolbar {...nodeProps} />
 *     </IfNotReadOnly>
 *     <DefaultHandles />
 *   </ElementNodeContainer>
 * ))
 * ```
 */
export declare function deploymentNode<A extends Any$1$3 = Unknown$2>(component: FC<DeploymentNodeProps<A>>): Types.NodeRenderer<'deployment'>;
export type DeploymentNodeProps<A extends Any$1$3 = Unknown$2> = {
  nodeProps: Types.NodeProps<'deployment'>;
  nodeModel: NodeModel.WithDeploymentElement<A>;
};
/**
 * Node that will be used to render the compound element from the model.
 * It is a container node, i.e. it has children.
 *
 * Custom node renderer receives these props:
 * - `nodeProps`: props from XYFlow
 * - `nodeModel`: LikeC4 {@link NodeModel.WithElement}
 *
 * @see [Default implementation](https://github.com/likec4/likec4/blob/main/packages/diagram/src/likec4diagram/custom/nodes/nodes.tsx)
 *
 * @example
 * ```tsx
 * import {
 *   compoundElementNode,
 *   CompoundNodeContainer,
 *   CompoundTitle,
 *   CompoundActions,
 *   CompoundDetailsButtonWithHandler,
 *   IfEnabled,
 *   CompoundElementToolbar,
 *   DefaultHandles,
 * } from '@likec4/diagram/custom'
 *
 * const CustomCompoundElementNode = compoundElementNode(({ nodeProps, nodeModel }) => (
 *   <CompoundNodeContainer nodeProps={props}>
 *     <CompoundTitle {...props} />
 *     <CompoundActions {...props} />
 *     <IfEnabled feature="ElementDetails">
 *       <CompoundDetailsButtonWithHandler {...props} />
 *     </IfEnabled>
 *     <IfNotReadOnly>
 *       <CompoundElementToolbar {...props} />
 *     </IfNotReadOnly>
 *     <DefaultHandles />
 *   </CompoundNodeContainer>
 * ))
 * ```
 */
export declare function compoundElementNode<A extends Any$1$3 = Unknown$2>(component: FC<CompoundElementNodeProps<A>>): Types.NodeRenderer<'compound-element'>;
export type CompoundElementNodeProps<A extends Any$1$3 = Unknown$2> = {
  nodeProps: Types.NodeProps<'compound-element'>;
  nodeModel: NodeModel.WithElement<A>;
};
/**
 * Node that will be used to render the compound from the deployment model.
 * It is a container node, i.e. it has children.
 *
 * Custom node renderer receives these props:
 * - `nodeProps`: props from XYFlow
 * - `nodeModel`: LikeC4 {@link NodeModel.WithDeploymentElement}
 *
 * @see [Default implementation](https://github.com/likec4/likec4/blob/main/packages/diagram/src/likec4diagram/custom/nodes/nodes.tsx)
 *
 * @example
 * ```tsx
 * import {
 *   compoundDeploymentNode,
 *   CompoundNodeContainer,
 *   CompoundTitle,
 *   CompoundActions,
 *   CompoundDeploymentToolbar,
 *   DefaultHandles,
 * } from '@likec4/diagram/custom'
 *
 * const CustomCompoundDeploymentNode = compoundDeploymentNode(({ nodeProps, nodeModel }) => (
 *   <CompoundNodeContainer nodeProps={nodeProps}>
 *     <CompoundTitle {...nodeProps} />
 *     <CompoundActions {...nodeProps} />
 *     <IfNotReadOnly>
 *       <CompoundDeploymentToolbar {...nodeProps} />
 *     </IfNotReadOnly>
 *     <DefaultHandles />
 *   </CompoundNodeContainer>
 * ```
 */
export declare function compoundDeploymentNode<A extends Any$1$3 = Unknown$2>(component: FC<CompoundDeploymentNodeProps<A>>): Types.NodeRenderer<'compound-deployment'>;
export type CompoundDeploymentNodeProps<A extends Any$1$3 = Unknown$2> = {
  nodeProps: Types.NodeProps<'compound-deployment'>;
  nodeModel: NodeModel.WithDeploymentElement<A>;
};
/**
 * Node that will be used to render the view group from the model.
 *
 * Custom node renderer receives these props:
 * - `nodeProps`: props from XYFlow
 * - `nodeModel`: LikeC4 {@link NodeModel.IsGroup}
 *
 * @see [Default implementation](https://github.com/likec4/likec4/blob/main/packages/diagram/src/likec4diagram/custom/nodes/nodes.tsx)
 *
 * @example
 * ```tsx
 * import {
 *   viewGroupNode,
 *   CompoundNodeContainer,
 *   CompoundTitle,
 *   DefaultHandles,
 * } from '@likec4/diagram/custom'
 *
 * const CustomViewGroupNode = viewGroupNode(({ nodeProps, nodeModel }) => (
 *   <CompoundNodeContainer nodeProps={nodeProps}>
 *     <CompoundTitle {...nodeProps} />
 *     <DefaultHandles />
 *   </CompoundNodeContainer>
 * ```
 */
export declare function viewGroupNode<A extends Any$1$3 = Unknown$2>(component: FC<ViewGroupNodeProps<A>>): Types.NodeRenderer<'view-group'>;
export type ViewGroupNodeProps<A extends Any$1$3 = Unknown$2> = {
  nodeProps: Types.NodeProps<'view-group'>;
  nodeModel: NodeModel.IsGroup<A>;
};
export declare function sequenceActorNode<A extends Any$1$3 = Unknown$2>(component: FC<SequenceActorNodeProps<A>>): Types.NodeRenderer<'seq-actor'>;
export type SequenceActorNodeProps<A extends Any$1$3 = Unknown$2> = {
  nodeProps: Types.NodeProps<'seq-actor'>;
  nodeModel: NodeModel.WithElement<A>;
};
//#endregion
//#endregion
//#region ../diagram/dist/context/DiagramEventHandlers.d.mts
//#region src/context/DiagramEventHandlers.d.ts
type RequiredOrNull<T> = { [P in keyof T]-?: NonNullable<T[P]> | null; };
type DiagramEventHandlersRef = RefObject<Required<LikeC4DiagramEventHandlers>>;
type DiagramEventHandlersContext = RequiredOrNull<LikeC4DiagramEventHandlers> & {
  handlersRef: DiagramEventHandlersRef;
};
export declare function useDiagramEventHandlers(): DiagramEventHandlersContext;
//#endregion
//#endregion
//#region ../diagram/dist/hooks/useCurrentView.d.mts
//#region src/hooks/useCurrentView.d.ts
/**
 * Returns current view id
 * Should be used only inside LikeC4Diagram
 */
export declare function useCurrentViewId(): ViewId$1;
/**
 * Returns current view
 * Should be used only inside LikeC4Diagram
 */
export declare function useCurrentView(): LayoutedView;
//#endregion
//#endregion
//#region ../diagram/dist/context/LikeC4ModelContext.d.mts
//#region src/context/LikeC4ModelContext.d.ts
type UnknownLayouted$1 = t.aux.UnknownLayouted;
type CurrentViewModel = LikeC4ViewModel<UnknownLayouted$1, LayoutedView<UnknownLayouted$1>>;
/**
 * @returns The LikeC4Model from context, or null if no LikeC4ModelProvider is found.
 */
export declare function useOptionalLikeC4Model<A extends t.aux.Any = UnknownLayouted$1>(): LikeC4Model<A> | null;
export declare function useOptionalCurrentViewModel(): CurrentViewModel | null;
//#endregion
//#endregion
//#region ../diagram/dist/hooks/useCurrentViewModel.d.mts
//#region src/hooks/useCurrentViewModel.d.ts
/**
 * Hook to get the current view model from the context.
 * Throws an error if no view model is found in the context.
 *
 * @see useOptionalCurrentViewModel
 */
export declare function useCurrentViewModel(): CurrentViewModel;
//#endregion
//#region ../diagram/dist/hooks/useLikeC4Model.d.mts
//#region src/hooks/useLikeC4Model.d.ts
type Any$1$2 = t.aux.Any;
/**
 * @returns The LikeC4Model from context.
 * @throws If no LikeC4ModelProvider is found.
 */
export declare function useLikeC4Model<A extends Any$1$2 = t.aux.UnknownLayouted>(): LikeC4Model<A>;
export declare function useLikeC4ViewModel<A extends Any$1$2 = t.aux.UnknownLayouted>(viewId: t.aux.ViewId<A>): LikeC4ViewModel<A>;
export declare function useLikeC4Specification(): t.Specification<t.aux.UnknownLayouted>;
//#endregion
//#region ../diagram/dist/LikeC4ProjectsProvider.d.mts
//#region src/LikeC4ProjectsProvider.d.ts
type LandingPageConfig = {
  redirect: true;
} | {
  include: string[];
} | {
  exclude: string[];
};
interface LikeC4ProjectData {
  readonly id: ProjectId$1;
  readonly title?: string | undefined;
  readonly path?: string | undefined;
  readonly landingPage?: LandingPageConfig | undefined;
  readonly exportFormats?: readonly string[] | undefined;
}
interface LikeC4ProjectsProviderProps {
  /**
   * Projects to be used in the navigation panel.
   * Current project is taken from the LikeC4Model
   */
  projects: ReadonlyArray<LikeC4ProjectData>;
  /**
   * Optional callback when another project is selected.
   */
  onProjectChange?: (id: ProjectId$1) => void;
}
/**
 * Ensures LikeC4Projects context
 */
export declare function LikeC4ProjectsProvider({ children, projects, onProjectChange: _onProjectChange }: PropsWithChildren<LikeC4ProjectsProviderProps>): JSX$1.Element;
//#endregion
//#endregion
//#region ../diagram/dist/context/LikeC4ProjectsContext.d.mts
//#region src/context/LikeC4ProjectsContext.d.ts
type LikeC4ProjectsContext = {
  projects: ReadonlyArray<LikeC4ProjectData>;
  onProjectChange: (id: ProjectId$1) => void;
};
//#endregion
//#endregion
//#region ../diagram/dist/hooks/useLikeC4Project.d.mts
//#region src/hooks/useLikeC4Project.d.ts
export declare function useLikeC4ProjectsContext(): LikeC4ProjectsContext;
/**
 * @returns The list of available projects, or empty array if no projects are available.
 */
export declare function useLikeC4Projects(): ReadonlyArray<LikeC4ProjectData>;
/**
 * @returns The callback to change current project, or a no-op if no LikeC4ProjectsProvider is found.
 */
export declare function useChangeLikeC4Project(): (id: ProjectId$1) => void;
/**
 * @returns True if there are more than one project available in the context.
 */
export declare function useHasProjects(): boolean;
/**
 * @returns Current project id, as provided by LikeC4Model
 */
export declare function useLikeC4ProjectId(): ProjectId$1;
/**
 * Returns current LikeC4 project.
 * Requires LikeC4ModelProvider in the tree.
 * Falls back to model's project if LikeC4ProjectsProvider is not available.
 */
export declare function useLikeC4Project(): LikeC4ProjectData;
//#endregion
//#endregion
//#region ../diagram/dist/hooks/useLikeC4Styles.d.mts
//#region src/hooks/useLikeC4Styles.d.ts
export declare function useLikeC4Styles(): LikeC4Styles$1;
//#endregion
//#endregion
//#region ../diagram/dist/hooks/useSetState.d.mts
//#region src/hooks/useSetState.d.ts
/**
 * Differs from useState in that:
 * - it uses custom equal function (shallowEqual by default) to determine whether the state has changed.
 * - allows partial updates to the state
 */
export declare function useSetState<T extends object>(initialState: T | (() => T), equal?: (a: T, b: T) => boolean): readonly [T, (statePartial: NonEmptyObject<Partial<T>> | ((current: T) => NonEmptyObject<Partial<T>>)) => void];
//#endregion
//#endregion
//#region ../../node_modules/.pnpm/@react-hookz+web@25.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/@react-hookz/web/dist/types.d.ts
type DependenciesComparator<Deps extends DependencyList = DependencyList> = (a: Deps, b: Deps) => boolean;
//#endregion
//#region ../../node_modules/.pnpm/@react-hookz+web@25.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/@react-hookz/web/dist/util/misc.d.ts
type EffectCallback$1 = (...args: any[]) => any;
type EffectHook<Callback extends EffectCallback$1 = EffectCallback$1, Deps extends DependencyList | undefined = DependencyList | undefined, RestArgs extends any[] = any[]> = ((...args: [Callback, Deps, ...RestArgs]) => void) | ((...args: [Callback, Deps]) => void);
//#endregion
//#region ../diagram/dist/hooks/useUpdateEffect.d.mts
//#region src/hooks/useUpdateEffect.d.ts
declare function useUpdateEffect$1<Callback extends EffectCallback = EffectCallback, Deps extends DependencyList = DependencyList>(callback: Callback, deps: Deps, equalityFn?: DependenciesComparator<Deps>, effectHook?: EffectHook<Callback, Deps>): void;
//#endregion
//#region ../diagram/dist/overlays/overlay/Overlay.d.mts
//#region src/overlays/overlay/Overlay.d.ts
type OverlayProps = PropsWithChildren<{
  fullscreen?: boolean | undefined;
  withBackdrop?: boolean | undefined;
  overlayLevel?: number;
  className?: string;
  classes?: {
    dialog?: string;
    body?: string;
  };
  backdrop?: {
    opacity?: number;
  };
  /**
   * Delay before showing the overlay content (in milliseconds) - helps to avoid flickering
   * Default: `130ms`
   * If set to `0`, the content will be shown immediately
   */
  openDelay?: number;
  /**
   * Called when the overlay is closed by outside click or escape key
   */
  onClose: () => void;
  onClick?: never;
}>;
export declare const Overlay: import("react").ForwardRefExoticComponent<{
  fullscreen?: boolean | undefined;
  withBackdrop?: boolean | undefined;
  overlayLevel?: number;
  className?: string;
  classes?: {
    dialog?: string;
    body?: string;
  };
  backdrop?: {
    opacity?: number;
  };
  /**
   * Delay before showing the overlay content (in milliseconds) - helps to avoid flickering
   * Default: `130ms`
   * If set to `0`, the content will be shown immediately
   */
  openDelay?: number;
  /**
   * Called when the overlay is closed by outside click or escape key
   */
  onClose: () => void;
  onClick?: never;
} & {
  children?: import("react").ReactNode | undefined;
} & import("react").RefAttributes<HTMLDialogElement>>;
//#endregion
//#endregion
//#region ../diagram/dist/components/PortalToContainer.d.mts
//#region src/components/PortalToContainer.d.ts
/**
 * PortalToContainer is used to render elements outside the LikeC4DiagramXYFlow, but inside the container.
 * It is used internally by the library.
 */
export declare function PortalToContainer({ children }: PropsWithChildren): import("react").JSX.Element;
//#endregion
//#endregion
//#region ../diagram/dist/context/FramerMotionConfig.d.mts
//#region src/context/FramerMotionConfig.d.ts
export declare function FramerMotionConfig({ reducedMotion, children }: PropsWithChildren<{
  /**
   * If true, will respect the device prefersReducedMotion setting by switching
   * transform animations off.
   */
  reducedMotion?: 'always' | 'never' | 'user' | undefined;
}>): import("react").JSX.Element;
//#endregion
//#endregion
//#region ../../node_modules/.pnpm/react-error-boundary@6.1.6_@types+react@19.3.0_react@19.3.0/node_modules/react-error-boundary/dist/react-error-boundary.d.ts
declare type ErrorBoundaryProps = ErrorBoundaryPropsWithFallback | ErrorBoundaryPropsWithComponent | ErrorBoundaryPropsWithRender;
declare type ErrorBoundaryPropsWithComponent = ErrorBoundarySharedProps & {
  fallback?: never;
  /**
   * React component responsible for returning a fallback UI based on a thrown value.
   *
   * ```tsx
   * <ErrorBoundary FallbackComponent={Fallback} />
   * ```
   */
  FallbackComponent: ComponentType<FallbackProps>;
  fallbackRender?: never;
};
declare type ErrorBoundaryPropsWithFallback = ErrorBoundarySharedProps & {
  /**
   * Static content to render in place of an error if one is thrown.
   *
   * ```tsx
   * <ErrorBoundary fallback={<div className="text-red">Something went wrong</div>} />
   * ```
   */
  fallback: ReactNode;
  FallbackComponent?: never;
  fallbackRender?: never;
};
declare type ErrorBoundaryPropsWithRender = ErrorBoundarySharedProps & {
  fallback?: never;
  FallbackComponent?: never;
  /**
   * [Render prop](https://react.dev/reference/react/Children#calling-a-render-prop-to-customize-rendering) function responsible for returning a fallback UI based on a thrown value.
   *
   * ```tsx
   * <ErrorBoundary fallbackRender={({ error, resetErrorBoundary }) => <div>...</div>} />
   * ```
   */
  fallbackRender: (props: FallbackProps) => ReactNode;
};
declare type ErrorBoundarySharedProps = PropsWithChildren<{
  /**
   * Optional callback to enable e.g. logging error information to a server.
   *
   * @param error Value that was thrown; typically an instance of `Error`
   * @param info React "component stack" identifying where the error was thrown
   */
  onError?: (error: unknown, info: ErrorInfo) => void;
  /**
   * Optional callback to be notified when an error boundary is reset so React can retry the failed render.
   */
  onReset?: (details: {
    reason: "imperative-api";
    args: unknown[];
  } | {
    reason: "keys";
    prev: unknown[] | undefined;
    next: unknown[] | undefined;
  }) => void;
  /**
   * When changed, these keys will reset a triggered error boundary.
   * This can be useful when an error condition may be tied to some specific state (that can be uniquely identified by key).
   * See the documentation for examples of how to use this prop.
   */
  resetKeys?: unknown[];
}>;
declare type FallbackProps = {
  error: unknown;
  resetErrorBoundary: (...args: unknown[]) => void;
};
//#endregion
//#region ../diagram/dist/components/ErrorFallback.d.mts
//#region src/components/ErrorFallback.d.ts
export declare function ErrorFallback({ error, resetErrorBoundary }: FallbackProps): import("react").JSX.Element;
declare function ErrorBoundary$1(props: Pick<ErrorBoundaryProps, 'onReset' | 'onError' | 'children'>): import("react").JSX.Element;
//#endregion
//#region ../../node_modules/.pnpm/@mantine+core@9.7.1_@mantine+hooks@9.7.1_react@19.3.0__@types+react@19.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/@mantine/core/lib/core/Box/Box.types.d.ts
interface CSSProperties$1 extends React.CSSProperties {
  [key: string]: any;
}
type MantineStyle = CSSProperties$1 | ((theme: MantineTheme) => CSSProperties$1);
type MantineStyleProp = MantineStyle | MantineStyle[] | MantineStyleProp[] | undefined;
type CssVariable = `--${string}`;
type CssVariables<Variable extends string = CssVariable> = Partial<Record<Variable, string>>;
type CssVars<Variable extends string = CssVariable> = CssVariables<Variable> | ((theme: MantineTheme) => CssVariables<Variable>) | CssVars<Variable>[];
type CssVarsProp<Variable extends string = CssVariable> = CssVars<Variable> | CssVars<Variable>[];
//#endregion
//#region ../../node_modules/.pnpm/@mantine+core@9.7.1_@mantine+hooks@9.7.1_react@19.3.0__@types+react@19.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/@mantine/core/lib/core/Box/style-props/style-props.types.d.ts
type StyleProp<Value> = Value | Partial<Record<MantineBreakpoint | (string & {}), Value>>;
interface MantineStyleProps {
  /** Margin, theme key: theme.spacing */
  m?: StyleProp<MantineSpacing>;
  /** MarginBlock, theme key: theme.spacing */
  my?: StyleProp<MantineSpacing>;
  /** MarginInline, theme key: theme.spacing */
  mx?: StyleProp<MantineSpacing>;
  /** MarginTop, theme key: theme.spacing */
  mt?: StyleProp<MantineSpacing>;
  /** MarginBottom, theme key: theme.spacing */
  mb?: StyleProp<MantineSpacing>;
  /** MarginInlineStart, theme key: theme.spacing */
  ms?: StyleProp<MantineSpacing>;
  /** MarginInlineEnd, theme key: theme.spacing */
  me?: StyleProp<MantineSpacing>;
  /** MarginInlineStart, theme key: theme.spacing */
  mis?: StyleProp<MantineSpacing>;
  /** MarginInlineEnd, theme key: theme.spacing */
  mie?: StyleProp<MantineSpacing>;
  /** MarginLeft, theme key: theme.spacing */
  ml?: StyleProp<MantineSpacing>;
  /** MarginRight, theme key: theme.spacing */
  mr?: StyleProp<MantineSpacing>;
  /** Padding, theme key: theme.spacing */
  p?: StyleProp<MantineSpacing>;
  /** PaddingBlock, theme key: theme.spacing */
  py?: StyleProp<MantineSpacing>;
  /** PaddingInline, theme key: theme.spacing */
  px?: StyleProp<MantineSpacing>;
  /** PaddingTop, theme key: theme.spacing */
  pt?: StyleProp<MantineSpacing>;
  /** PaddingBottom, theme key: theme.spacing */
  pb?: StyleProp<MantineSpacing>;
  /** PaddingInlineStart, theme key: theme.spacing */
  ps?: StyleProp<MantineSpacing>;
  /** PaddingInlineEnd, theme key: theme.spacing */
  pe?: StyleProp<MantineSpacing>;
  /** PaddingInlineStart, theme key: theme.spacing */
  pis?: StyleProp<MantineSpacing>;
  /** PaddingInlineEnd, theme key: theme.spacing */
  pie?: StyleProp<MantineSpacing>;
  /** PaddingLeft, theme key: theme.spacing */
  pl?: StyleProp<MantineSpacing>;
  /** PaddingRight, theme key: theme.spacing */
  pr?: StyleProp<MantineSpacing>;
  /** Border */
  bd?: StyleProp<React.CSSProperties['border']>;
  /** BorderRadius, theme key: theme.radius */
  bdrs?: StyleProp<MantineSpacing>;
  /** Background, theme key: theme.colors */
  bg?: StyleProp<MantineColor>;
  /** Color */
  c?: StyleProp<MantineColor>;
  opacity?: StyleProp<React.CSSProperties['opacity']>;
  /** FontFamily */
  ff?: StyleProp<'monospace' | 'text' | 'heading' | (string & {})>;
  /** FontSize, theme key: theme.fontSizes */
  fz?: StyleProp<MantineFontSize | `h${1 | 2 | 3 | 4 | 5 | 6}` | number | (string & {})>;
  /** FontWeight */
  fw?: StyleProp<React.CSSProperties['fontWeight']>;
  /** LetterSpacing */
  lts?: StyleProp<React.CSSProperties['letterSpacing']>;
  /** TextAlign */
  ta?: StyleProp<React.CSSProperties['textAlign']>;
  /** LineHeight, theme key: lineHeights */
  lh?: StyleProp<MantineLineHeight | `h${1 | 2 | 3 | 4 | 5 | 6}` | number | (string & {})>;
  /** FontStyle */
  fs?: StyleProp<React.CSSProperties['fontStyle']>;
  /** TextTransform */
  tt?: StyleProp<React.CSSProperties['textTransform']>;
  /** TextDecoration */
  td?: StyleProp<React.CSSProperties['textDecoration']>;
  /** Width, theme key: theme.spacing */
  w?: StyleProp<React.CSSProperties['width']>;
  /** MinWidth, theme key: theme.spacing*/
  miw?: StyleProp<React.CSSProperties['minWidth']>;
  /** MaxWidth, theme key: theme.spacing */
  maw?: StyleProp<React.CSSProperties['maxWidth']>;
  /** Height, theme key: theme.spacing */
  h?: StyleProp<React.CSSProperties['height']>;
  /** MinHeight, theme key: theme.spacing */
  mih?: StyleProp<React.CSSProperties['minHeight']>;
  /** MaxHeight, theme key: theme.spacing */
  mah?: StyleProp<React.CSSProperties['maxHeight']>;
  /** BackgroundSize */
  bgsz?: StyleProp<React.CSSProperties['backgroundSize']>;
  /** BackgroundPosition */
  bgp?: StyleProp<React.CSSProperties['backgroundPosition']>;
  /** BackgroundRepeat */
  bgr?: StyleProp<React.CSSProperties['backgroundRepeat']>;
  /** BackgroundAttachment */
  bga?: StyleProp<React.CSSProperties['backgroundAttachment']>;
  /** Position */
  pos?: StyleProp<React.CSSProperties['position']>;
  top?: StyleProp<React.CSSProperties['top']>;
  left?: StyleProp<React.CSSProperties['left']>;
  bottom?: StyleProp<React.CSSProperties['bottom']>;
  right?: StyleProp<React.CSSProperties['right']>;
  inset?: StyleProp<React.CSSProperties['inset']>;
  display?: StyleProp<React.CSSProperties['display']>;
  flex?: StyleProp<React.CSSProperties['flex']>;
}
//#endregion
//#region ../../node_modules/.pnpm/@mantine+core@9.7.1_@mantine+hooks@9.7.1_react@19.3.0__@types+react@19.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/@mantine/core/lib/core/Box/Box.d.ts
type Mod = Record<string, any> | string;
type BoxMod = Mod | Mod[] | BoxMod[];
interface BoxProps extends MantineStyleProps {
  /** Class added to the root element, if applicable */
  className?: string | undefined;
  /** Inline style added to root component element, can subscribe to theme defined on MantineProvider */
  style?: MantineStyleProp;
  /** CSS variables defined on root component element */
  __vars?: CssVarsProp;
  /** `size` property passed down the HTML element */
  __size?: string;
  /** Breakpoint above which the component is hidden with `display: none` */
  hiddenFrom?: MantineBreakpoint;
  /** Breakpoint below which the component is hidden with `display: none` */
  visibleFrom?: MantineBreakpoint;
  /** Determines whether component should be hidden in light color scheme with `display: none` */
  lightHidden?: boolean;
  /** Determines whether component should be hidden in dark color scheme with `display: none` */
  darkHidden?: boolean;
  /** Element modifiers transformed into `data-` attributes, for example, `{ 'data-size': 'xl' }`, falsy values are removed */
  mod?: BoxMod;
}
type ElementProps<ElementType extends React.ElementType, PropsToOmit extends string = never> = Omit<React.ComponentProps<ElementType>, 'style' | PropsToOmit>;
interface BoxComponentProps extends BoxProps {
  /** Variant passed from parent component, sets `data-variant` */
  variant?: string;
  /** Size passed from parent component, sets `data-size` if value is not number like */
  size?: string | number;
}
//#endregion
//#region ../../node_modules/.pnpm/@mantine+core@9.7.1_@mantine+hooks@9.7.1_react@19.3.0__@types+react@19.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/@mantine/core/lib/core/MantineProvider/color-functions/default-variant-colors-resolver/default-variant-colors-resolver.d.ts
interface VariantColorsResolverInput {
  color: MantineColor | undefined;
  theme: MantineTheme;
  variant: string;
  gradient?: MantineGradient;
  autoContrast?: boolean;
}
interface VariantColorResolverResult {
  background: string;
  hover: string;
  color: string;
  border: string;
  hoverColor?: string;
}
type VariantColorsResolver = (input: VariantColorsResolverInput) => VariantColorResolverResult;
//#endregion
//#region ../../node_modules/.pnpm/@mantine+core@9.7.1_@mantine+hooks@9.7.1_react@19.3.0__@types+react@19.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/@mantine/core/lib/core/MantineProvider/theme.types.d.ts
interface MantineTheme {
  /** Controls focus ring styles. Supports the following options:
   *  - `auto` – focus ring is displayed only when the user navigates with keyboard (default value)
   *  - `always` – focus ring is displayed when the user navigates with keyboard and mouse
   *  - `never` – focus ring is always hidden (not recommended)
   */
  focusRing: 'auto' | 'always' | 'never';
  /** Rem units scale, change if you customize font-size of `html` element
   *  default value is `1` (for `100%`/`16px` font-size on `html`)
   */
  scale: number;
  /** Determines whether `font-smoothing` property should be set on the body, `true` by default */
  fontSmoothing: boolean;
  /** White color */
  white: string;
  /** Black color */
  black: string;
  /** Object of colors, key is color name, value is an array of at least 10 strings (colors) */
  colors: MantineThemeColors;
  /** Index of theme.colors[color].
   *  Primary shade is used in all components to determine which color from theme.colors[color] should be used.
   *  Can be either a number (0–9) or an object to specify different color shades for light and dark color schemes.
   *  Default value `{ light: 6, dark: 8 }`
   *
   *  For example,
   *  { primaryShade: 6 } // shade 6 is used both for dark and light color schemes
   *  { primaryShade: { light: 6, dark: 7 } } // different shades for dark and light color schemes
   * */
  primaryShade: MantineColorShade | MantinePrimaryShade;
  /** Key of `theme.colors`, hex/rgb/hsl values are not supported.
   *  Determines which color will be used in all components by default.
   *  Default value – `blue`.
   * */
  primaryColor: string;
  /** Function to resolve colors based on variant.
   *  Can be used to deeply customize how colors are applied to `Button`, `ActionIcon`, `ThemeIcon`
   *  and other components that use colors from theme.
   * */
  variantColorResolver: VariantColorsResolver;
  /** Determines whether text color must be changed based on the given `color` prop in filled variant
   *  For example, if you pass `color="blue.1"` to Button component, text color will be changed to `var(--mantine-color-black)`
   *  Default value – `false`
   * */
  autoContrast: boolean;
  /** Determines which luminance value is used to determine if text color should be light or dark.
   *  Used only if `theme.autoContrast` is set to `true`.
   *  Default value is `0.3`
   * */
  luminanceThreshold: number;
  /** Font-family used in all components, system fonts by default */
  fontFamily: string;
  /** Monospace font-family, used in code and other similar components, system fonts by default  */
  fontFamilyMonospace: string;
  /** Controls various styles of h1-h6 elements, used in Typography and Title components */
  headings: {
    fontFamily: string;
    fontWeight: string;
    textWrap: 'wrap' | 'nowrap' | 'balance' | 'pretty' | 'stable';
    sizes: {
      h1: HeadingStyle;
      h2: HeadingStyle;
      h3: HeadingStyle;
      h4: HeadingStyle;
      h5: HeadingStyle;
      h6: HeadingStyle;
    };
  };
  /** Object of values that are used to set `border-radius` in all components that support it */
  radius: MantineRadiusValues;
  /** Key of `theme.radius` or any valid CSS value. Default `border-radius` used by most components */
  defaultRadius: MantineRadius;
  /** Object of values that are used to set various CSS properties that control spacing between elements */
  spacing: MantineSpacingValues;
  /** Object of values that are used to control `font-size` property in all components */
  fontSizes: MantineFontSizesValues;
  /** Object of values that are used to control `line-height` property in `Text` component */
  lineHeights: MantineLineHeightValues;
  /** Object of values that are used to control `font-weight` property in components */
  fontWeights: MantineFontWeightsValues;
  /** Object of values that are used to control breakpoints in all components,
   *  values are expected to be defined in em
   * */
  breakpoints: MantineBreakpointsValues;
  /** Object of values that are used to add `box-shadow` styles to components that support `shadow` prop */
  shadows: MantineShadowsValues;
  /** Determines whether user OS settings to reduce motion should be respected, `false` by default */
  respectReducedMotion: boolean;
  /** Determines which cursor type will be used for interactive elements
   * - `default` – cursor that is used by native HTML elements, for example, `input[type="checkbox"]` has `cursor: default` styles
   * - `pointer` – sets `cursor: pointer` on interactive elements that do not have these styles by default
   */
  cursorType: 'default' | 'pointer';
  /** Default gradient configuration for components that support `variant="gradient"` */
  defaultGradient: MantineGradient;
  /** Class added to the elements that have active styles, for example, `Button` and `ActionIcon` */
  activeClassName: string;
  /** Class added to the elements that have focus styles, for example, `Button` or `ActionIcon`.
   *  Overrides `theme.focusRing` property.
   */
  focusClassName: string;
  /** Allows adding `classNames`, `styles` and `defaultProps` to any component */
  components: MantineThemeComponents;
  /** Any other properties that you want to access with the theme objects */
  other: MantineThemeOther;
}
type MantineColorScheme = 'light' | 'dark' | 'auto';
type MantineThemeOverride = PartialDeep<MantineTheme>;
interface MantineThemeComponent {
  classNames?: any;
  styles?: any;
  vars?: any;
  defaultProps?: any;
}
type MantineThemeComponents = Record<string, MantineThemeComponent>;
interface HeadingStyle {
  fontSize: string;
  fontWeight?: string;
  lineHeight: string;
}
type MantineSize = 'xs' | 'sm' | 'md' | 'lg' | 'xl';
interface MantineThemeSizesOverride {}
type MantineBreakpoint = (MantineThemeSizesOverride extends {
  breakpoints: Record<infer CustomBreakpoints, string>;
} ? CustomBreakpoints : MantineSize) | (string & {});
type MantineBreakpointsValues = Record<MantineBreakpoint, string>;
type MantineFontSize = (MantineThemeSizesOverride extends {
  fontSizes: Record<infer CustomFontSizes, string>;
} ? CustomFontSizes : MantineSize) | (string & {});
type MantineFontSizesValues = Record<MantineFontSize, string>;
type _MantineRadius = (MantineThemeSizesOverride extends {
  radius: Record<infer CustomRadius, string>;
} ? CustomRadius : MantineSize) | (string & {});
type MantineRadius = _MantineRadius | number;
type MantineRadiusValues = Record<_MantineRadius, string>;
type _MantineSpacing = (MantineThemeSizesOverride extends {
  spacing: Record<infer CustomSpacing, string>;
} ? CustomSpacing : MantineSize) | (string & {});
type MantineSpacing = _MantineSpacing | number;
type MantineSpacingValues = Record<MantineSpacing, string>;
type MantineShadow = (MantineThemeSizesOverride extends {
  shadows: Record<infer CustomShadow, string>;
} ? CustomShadow : MantineSize) | (string & {});
type MantineShadowsValues = Record<MantineShadow, string>;
type MantineLineHeight = (MantineThemeSizesOverride extends {
  lineHeights: Record<infer CustomLineHeight, string>;
} ? CustomLineHeight : MantineSize) | (string & {});
type MantineLineHeightValues = Record<MantineLineHeight, string>;
type MantineFontWeight = (MantineThemeSizesOverride extends {
  fontWeights: Record<infer CustomFontWeight, string>;
} ? CustomFontWeight : 'regular' | 'medium' | 'bold') | (string & {});
type MantineFontWeightsValues = Record<MantineFontWeight, string>;
interface MantineThemeOther {
  [key: string]: any;
}
interface MantineGradient {
  from: string;
  to: string;
  deg?: number;
}
type MantineColorsTuple = readonly [string, string, string, string, string, string, string, string, string, string, ...string[]];
type MantineColorShade = 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9;
interface MantinePrimaryShade {
  light: MantineColorShade;
  dark: MantineColorShade;
}
type DefaultMantineColor = 'dark' | 'gray' | 'red' | 'pink' | 'grape' | 'violet' | 'indigo' | 'blue' | 'cyan' | 'green' | 'lime' | 'yellow' | 'orange' | 'teal' | (string & {});
interface MantineThemeColorsOverride {}
type MantineThemeColors = MantineThemeColorsOverride extends {
  colors: Record<infer CustomColors, MantineColorsTuple>;
} ? Record<CustomColors, MantineColorsTuple> : Record<DefaultMantineColor, MantineColorsTuple>;
type MantineColor = keyof MantineThemeColors;
//#endregion
//#region ../../node_modules/.pnpm/@mantine+core@9.7.1_@mantine+hooks@9.7.1_react@19.3.0__@types+react@19.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/@mantine/core/lib/core/MantineProvider/color-scheme-managers/types.d.ts
interface MantineColorSchemeManager {
  /** Function to retrieve color scheme value from external storage, for example window.localStorage */
  get: (defaultValue: MantineColorScheme) => MantineColorScheme;
  /** Function to set color scheme value in external storage, for example window.localStorage */
  set: (value: MantineColorScheme) => void;
  /** Function to subscribe to color scheme changes triggered by external events */
  subscribe: (onUpdate: (colorScheme: MantineColorScheme) => void) => void;
  /** Function to unsubscribe from color scheme changes triggered by external events */
  unsubscribe: () => void;
  /** Function to clear value from external storage */
  clear: () => void;
}
//#endregion
//#region ../../node_modules/.pnpm/@mantine+core@9.7.1_@mantine+hooks@9.7.1_react@19.3.0__@types+react@19.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/@mantine/core/lib/core/MantineProvider/convert-css-variables/css-variables-object-to-string.d.ts
type CSSVariables = Record<CssVariable, string>;
//#endregion
//#region ../../node_modules/.pnpm/@mantine+core@9.7.1_@mantine+hooks@9.7.1_react@19.3.0__@types+react@19.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/@mantine/core/lib/core/MantineProvider/convert-css-variables/convert-css-variables.d.ts
interface ConvertCSSVariablesInput {
  /** Shared CSS variables that should be accessible independent from color scheme */
  variables: CSSVariables;
  /** CSS variables available only in dark color scheme */
  dark: CSSVariables;
  /** CSS variables available only in light color scheme */
  light: CSSVariables;
}
//#endregion
//#region ../../node_modules/.pnpm/@mantine+core@9.7.1_@mantine+hooks@9.7.1_react@19.3.0__@types+react@19.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/@mantine/core/lib/core/MantineProvider/Mantine.context.d.ts
interface MantineStylesTransform {
  sx?: () => (sx: any) => string;
  styles?: () => (styles: any, payload: any) => Record<string, string>;
}
//#endregion
//#region ../../node_modules/.pnpm/@mantine+core@9.7.1_@mantine+hooks@9.7.1_react@19.3.0__@types+react@19.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/@mantine/core/lib/core/MantineProvider/MantineCssVariables/default-css-variables-resolver.d.ts
type CSSVariablesResolver = (theme: MantineTheme) => ConvertCSSVariablesInput;
//#endregion
//#region ../../node_modules/.pnpm/@mantine+core@9.7.1_@mantine+hooks@9.7.1_react@19.3.0__@types+react@19.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/@mantine/core/lib/core/MantineProvider/MantineProvider.d.ts
interface MantineProviderProps {
  /** Theme override object */
  theme?: MantineThemeOverride;
  /** Used to retrieve/set color scheme value in external storage, by default uses `window.localStorage` */
  colorSchemeManager?: MantineColorSchemeManager;
  /** Default color scheme value used when `colorSchemeManager` cannot retrieve value from external storage, `light` by default */
  defaultColorScheme?: MantineColorScheme;
  /** Forces color scheme value, if set, MantineProvider ignores `colorSchemeManager` and `defaultColorScheme` */
  forceColorScheme?: 'light' | 'dark';
  /** CSS selector to which CSS variables should be added, by default variables are applied to `:root` and `:host` */
  cssVariablesSelector?: string;
  /** Determines whether theme CSS variables should be added to given `cssVariablesSelector` @default true */
  withCssVariables?: boolean;
  /** Determines whether CSS variables should be deduplicated: if CSS variable has the same value as in default theme, it is not added in the runtime. @default true. */
  deduplicateCssVariables?: boolean;
  /** Function to resolve root element to set `data-mantine-color-scheme` attribute, must return undefined on server, `() => document.documentElement` by default */
  getRootElement?: () => HTMLElement | undefined;
  /** A prefix for components static classes (for example {selector}-Text-root), `mantine` by default */
  classNamesPrefix?: string;
  /** Function to generate nonce attribute added to all generated `style` tags */
  getStyleNonce?: () => string;
  /** Function to generate CSS variables based on theme object */
  cssVariablesResolver?: CSSVariablesResolver;
  /** Determines whether components should have static classes, for example, `mantine-Button-root`. @default true */
  withStaticClasses?: boolean;
  /** Determines whether global classes should be added with `<style />` tag. Global classes are required for `hiddenFrom`/`visibleFrom` and `lightHidden`/`darkHidden` props to work. @default true. */
  withGlobalClasses?: boolean;
  /** An object to transform `styles` and `sx` props into css classes, can be used with CSS-in-JS libraries */
  stylesTransform?: MantineStylesTransform;
  /** Determines whether inline styles with identical content should be deduplicated using React 19 style hoisting. When enabled, components with the same responsive style props share a single `<style />` tag instead of each generating their own. @default false */
  deduplicateInlineStyles?: boolean;
  /** Your application */
  children?: React.ReactNode;
  /** Environment at which the provider is used, `'test'` environment disables all transitions and portals */
  env?: 'default' | 'test';
}
//#endregion
//#region ../../node_modules/.pnpm/@mantine+core@9.7.1_@mantine+hooks@9.7.1_react@19.3.0__@types+react@19.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/@mantine/core/lib/core/factory/factory.d.ts
interface FactoryPayload {
  props: Record<string, any>;
  ctx?: any;
  ref?: any;
  stylesNames?: string;
  vars?: any;
  variant?: string;
  staticComponents?: Record<string, any>;
  compound?: boolean;
  signature?: any;
}
//#endregion
//#region ../../node_modules/.pnpm/@mantine+core@9.7.1_@mantine+hooks@9.7.1_react@19.3.0__@types+react@19.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/@mantine/core/lib/core/factory/polymorphic-factory.d.ts
interface PolymorphicFactoryPayload extends FactoryPayload {
  defaultComponent: any;
  defaultRef: any;
}
//#endregion
//#region ../../node_modules/.pnpm/@mantine+core@9.7.1_@mantine+hooks@9.7.1_react@19.3.0__@types+react@19.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/@mantine/core/lib/core/factory/create-factory.d.ts
type PolymorphicFactory<Payload extends PolymorphicFactoryPayload> = Payload;
//#endregion
//#region ../../node_modules/.pnpm/@mantine+core@9.7.1_@mantine+hooks@9.7.1_react@19.3.0__@types+react@19.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/@mantine/core/lib/core/styles-api/create-vars-resolver/create-vars-resolver.d.ts
type PartialTransformVars<V> = { [Key in keyof V]: V[Key] extends CssVariable ? Partial<Record<V[Key], string | undefined>> : never; };
type PartialVarsResolver<Payload extends FactoryPayload> = (theme: MantineTheme, props: Payload['props'], ctx: Payload['ctx']) => PartialTransformVars<Payload['vars']>;
//#endregion
//#region ../../node_modules/.pnpm/@mantine+core@9.7.1_@mantine+hooks@9.7.1_react@19.3.0__@types+react@19.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/@mantine/core/lib/core/styles-api/styles-api.types.d.ts
type StylesApiRecord<Payload extends FactoryPayload, DataType> = Payload['compound'] extends true ? Payload['stylesNames'] extends string ? StylesRecord<Payload['stylesNames'], DataType> : never : Payload['stylesNames'] extends string ? StylesRecord<Payload['stylesNames'], DataType> | ((theme: MantineTheme, props: Payload['props'], ctx: Payload['ctx']) => StylesRecord<Payload['stylesNames'], DataType>) : never;
type Styles<Payload extends FactoryPayload> = StylesApiRecord<Payload, CSSProperties$1>;
type ClassNames<Payload extends FactoryPayload> = StylesApiRecord<Payload, string | undefined>;
type Attributes<Payload extends FactoryPayload> = Payload['stylesNames'] extends string ? Payload['compound'] extends true ? never : { [K in Payload['stylesNames']]?: Record<string, any>; } : never;
type StylesRecord<StylesNames extends string, Payload> = Partial<Record<StylesNames, Payload>>;
interface StylesApiProps<Payload extends FactoryPayload> {
  unstyled?: boolean;
  variant?: Payload['variant'] extends string ? Payload['variant'] | (string & {}) : string;
  classNames?: ClassNames<Payload>;
  styles?: Styles<Payload>;
  vars?: PartialVarsResolver<Payload>;
  attributes?: Attributes<Payload>;
}
//#endregion
//#region ../../node_modules/.pnpm/@mantine+core@9.7.1_@mantine+hooks@9.7.1_react@19.3.0__@types+react@19.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/@mantine/core/lib/components/UnstyledButton/UnstyledButton.d.ts
type UnstyledButtonStylesNames = 'root';
interface UnstyledButtonProps extends Omit<BoxComponentProps, 'vars' | 'variant'>, StylesApiProps<UnstyledButtonFactory> {
  __staticSelector?: string;
}
type UnstyledButtonFactory = PolymorphicFactory<{
  props: UnstyledButtonProps;
  stylesNames: UnstyledButtonStylesNames;
  defaultComponent: 'button';
  defaultRef: HTMLButtonElement;
}>;
//#endregion
//#region ../diagram/dist/LikeC4MantineProvider.d.mts
//#region src/LikeC4MantineProvider.d.ts
type LikeC4MantineProviderProps = MantineProviderProps;
/**
 * LikeC4 Mantine provider with custom theme and CSS variables resolver
 */
export declare function LikeC4MantineProvider({ children, defaultColorScheme, theme, ...props }: LikeC4MantineProviderProps): JSX$2.Element;
/**
 * This is a deprecated alias for LikeC4MantineProvider.
 * @deprecated Use LikeC4MantineProvider instead
 */
export declare const DefaultMantineProvider: typeof LikeC4MantineProvider;
type ExtendedCustomColors = 'likec4' | DefaultMantineColor;
type ExtendedSizes = 'xxs' | 'xs' | 'sm' | 'md' | 'lg' | 'xl';
declare module '@mantine/core' {
  interface MantineThemeSizesOverride {
    fontSizes: Record<ExtendedSizes, string>;
    spacing: Record<ExtendedSizes, string>;
  }
  interface MantineThemeColorsOverride {
    colors: Record<ExtendedCustomColors, MantineColorsTuple>;
  }
}
//#endregion
//#endregion
//#region ../diagram/dist/LikeC4Styles.d.mts
//#region src/LikeC4Styles.d.ts
interface LikeC4StylesProps {
  /**
   * Root element selector to scope the styles to (e.g., "#diagram-root")
   * Must be a valid CSS selector
   */
  rootSelector: string;
}
/**
 * Component that renders LikeC4 theme colors as CSS variables
 * scoped to the provided root selector
 */
export declare function LikeC4Styles({ rootSelector }: LikeC4StylesProps): JSX$1.Element;
//#endregion
//#endregion
//#region ../diagram/dist/context/TagStylesContext.d.mts
//#region src/context/TagStylesContext.d.ts
type TagStylesProviderProps = PropsWithChildren<{
  /**
   * Root element selector to scope the tag styles to (e.g., "#diagram-root")
   * Must be a valid CSS selector
   */
  rootSelector: string;
}>;
export declare function TagStylesProvider({ children, rootSelector }: TagStylesProviderProps): import("react").JSX.Element;
//#endregion
//#endregion
//#region ../diagram/dist/hooks/safeContext.d.mts
//#region src/hooks/safeContext.d.ts
export declare function useDiagram(): DiagramApi;
/**
 * Tuple type for selector and compare function pair
 */
type SelectAndCompare<A, B> = [selector: (snapshot: A) => B, compare: (a: B, b: B) => boolean];
declare const DiagramActorContextProvider: Provider<DiagramActorRef>, selectDiagramSnapshot: <T>(select: (state: MachineSnapshot<Context, Events, {
  overlays: OverlaysActorRef | undefined;
  search: SearchActorRef | undefined;
  editor: BaseEditorActorRef | undefined;
  navigationPanel: NavigationPanelActorRef | undefined;
} & Omit<{
  hotkey: ActorRefFromLogic<HotkeyActorLogic> | undefined;
  overlays: ActorRefFromLogic<OverlaysActorLogic> | undefined;
  search: ActorRefFromLogic<SearchActorLogic> | undefined;
  mediaPrint: ActorRefFromLogic<MediaPrintActorLogic> | undefined;
  editor: ActorRefFromLogic<EditorActorLogic> | undefined;
  navigationPanel: ActorRefFromLogic<NavigationPanelActorLogic> | undefined;
}, "search" | "overlays" | "editor" | "navigationPanel">, "final" | "isReady" | "initializing" | "ready" | "navigating" | {
  ready?: NonNullable<"idle" | "walkthrough" | "focused" | "printing">;
}, never, never, never, never>) => T, compare?: ((old: NoInfer<T>, next: NoInfer<T>) => boolean) | undefined) => SelectAndCompare<MachineSnapshot<Context, Events, {
  overlays: OverlaysActorRef | undefined;
  search: SearchActorRef | undefined;
  editor: BaseEditorActorRef | undefined;
  navigationPanel: NavigationPanelActorRef | undefined;
} & Omit<{
  hotkey: ActorRefFromLogic<HotkeyActorLogic> | undefined;
  overlays: ActorRefFromLogic<OverlaysActorLogic> | undefined;
  search: ActorRefFromLogic<SearchActorLogic> | undefined;
  mediaPrint: ActorRefFromLogic<MediaPrintActorLogic> | undefined;
  editor: ActorRefFromLogic<EditorActorLogic> | undefined;
  navigationPanel: ActorRefFromLogic<NavigationPanelActorLogic> | undefined;
}, "search" | "overlays" | "editor" | "navigationPanel">, "final" | "isReady" | "initializing" | "ready" | "navigating" | {
  ready?: NonNullable<"idle" | "walkthrough" | "focused" | "printing">;
}, never, never, never, never>, T> & {
  Out: T;
}, selectDiagramContext: <T>(select: (state: Context) => T, compare?: ((old: NoInfer<T>, next: NoInfer<T>) => boolean) | undefined) => SelectAndCompare<MachineSnapshot<Context, Events, {
  overlays: OverlaysActorRef | undefined;
  search: SearchActorRef | undefined;
  editor: BaseEditorActorRef | undefined;
  navigationPanel: NavigationPanelActorRef | undefined;
} & Omit<{
  hotkey: ActorRefFromLogic<HotkeyActorLogic> | undefined;
  overlays: ActorRefFromLogic<OverlaysActorLogic> | undefined;
  search: ActorRefFromLogic<SearchActorLogic> | undefined;
  mediaPrint: ActorRefFromLogic<MediaPrintActorLogic> | undefined;
  editor: ActorRefFromLogic<EditorActorLogic> | undefined;
  navigationPanel: ActorRefFromLogic<NavigationPanelActorLogic> | undefined;
}, "search" | "overlays" | "editor" | "navigationPanel">, "final" | "isReady" | "initializing" | "ready" | "navigating" | {
  ready?: NonNullable<"idle" | "walkthrough" | "focused" | "printing">;
}, never, never, never, never>, T> & {
  Out: T;
}, useDiagramSelector: {
  <T>(select: (state: MachineSnapshot<Context, Events, {
    overlays: OverlaysActorRef | undefined;
    search: SearchActorRef | undefined;
    editor: BaseEditorActorRef | undefined;
    navigationPanel: NavigationPanelActorRef | undefined;
  } & Omit<{
    hotkey: ActorRefFromLogic<HotkeyActorLogic> | undefined;
    overlays: ActorRefFromLogic<OverlaysActorLogic> | undefined;
    search: ActorRefFromLogic<SearchActorLogic> | undefined;
    mediaPrint: ActorRefFromLogic<MediaPrintActorLogic> | undefined;
    editor: ActorRefFromLogic<EditorActorLogic> | undefined;
    navigationPanel: ActorRefFromLogic<NavigationPanelActorLogic> | undefined;
  }, "search" | "overlays" | "editor" | "navigationPanel">, "final" | "isReady" | "initializing" | "ready" | "navigating" | {
    ready?: NonNullable<"idle" | "walkthrough" | "focused" | "printing">;
  }, never, never, never, never>) => T): T;
  <T>(selectorCompare: SelectAndCompare<MachineSnapshot<Context, Events, {
    overlays: OverlaysActorRef | undefined;
    search: SearchActorRef | undefined;
    editor: BaseEditorActorRef | undefined;
    navigationPanel: NavigationPanelActorRef | undefined;
  } & Omit<{
    hotkey: ActorRefFromLogic<HotkeyActorLogic> | undefined;
    overlays: ActorRefFromLogic<OverlaysActorLogic> | undefined;
    search: ActorRefFromLogic<SearchActorLogic> | undefined;
    mediaPrint: ActorRefFromLogic<MediaPrintActorLogic> | undefined;
    editor: ActorRefFromLogic<EditorActorLogic> | undefined;
    navigationPanel: ActorRefFromLogic<NavigationPanelActorLogic> | undefined;
  }, "search" | "overlays" | "editor" | "navigationPanel">, "final" | "isReady" | "initializing" | "ready" | "navigating" | {
    ready?: NonNullable<"idle" | "walkthrough" | "focused" | "printing">;
  }, never, never, never, never>, T>): T;
  <T>(selector: (snapshot: MachineSnapshot<Context, Events, {
    overlays: OverlaysActorRef | undefined;
    search: SearchActorRef | undefined;
    editor: BaseEditorActorRef | undefined;
    navigationPanel: NavigationPanelActorRef | undefined;
  } & Omit<{
    hotkey: ActorRefFromLogic<HotkeyActorLogic> | undefined;
    overlays: ActorRefFromLogic<OverlaysActorLogic> | undefined;
    search: ActorRefFromLogic<SearchActorLogic> | undefined;
    mediaPrint: ActorRefFromLogic<MediaPrintActorLogic> | undefined;
    editor: ActorRefFromLogic<EditorActorLogic> | undefined;
    navigationPanel: ActorRefFromLogic<NavigationPanelActorLogic> | undefined;
  }, "search" | "overlays" | "editor" | "navigationPanel">, "final" | "isReady" | "initializing" | "ready" | "navigating" | {
    ready?: NonNullable<"idle" | "walkthrough" | "focused" | "printing">;
  }, never, never, never, never>) => T, compare: (a: T, b: T) => boolean): T;
}, useDiagramActorRef: () => DiagramActorRef;
//#endregion
//#region ../diagram/dist/hooks/useDiagram.d.mts
//#region src/hooks/useDiagram.d.ts
/**
 * Read diagram context
 * @deprecated use {@link useDiagramSelector}
 */
export declare function useDiagramContext<T = unknown>(selector: (context: Context) => T, compare?: (a: NoInfer<T>, b: NoInfer<T>) => boolean, deps?: DependencyList): T;
type PickEmittedEvent<T> = T extends EmittedEvents['type'] ? EmittedEvents & {
  type: T;
} : unknown;
/**
 * Subscribe to diagram emitted events
 * @example
 * ```tsx
 * useOnDiagramEvent('navigateTo', ({viewId}) => {
 *   console.log('Navigating to view', viewId)
 * })
 * ```
 */
export declare function useOnDiagramEvent<T extends EmittedEvents['type'] | '*'>(event: T, callback: (event: PickEmittedEvent<T>) => void, options?: {
  once?: boolean;
}): void;
//#endregion
//#region ../diagram/dist/LikeC4Diagram.props.d.mts
//#region src/LikeC4Diagram.props.d.ts
type Any$1$1 = t.aux.Any;
type Unknown$1 = t.aux.UnknownLayouted;
type ViewId$1$2<A> = t.aux.ViewId<A>;
type Fqn$1$2<A> = t.aux.Fqn<A>;
type RelationId$1 = t.aux.RelationId;
type DeploymentFqn$1<A> = t.aux.DeploymentFqn<A>;
type StrictViewId<A> = t.aux.StrictViewId<A>;
type NodeRenderers = Partial<CamelCasedProperties<Types.NodeRenderers>>;
type DiagramNodeWithNavigate<A extends Any$1$1 = Unknown$1> = SetRequired<DiagramNode<A>, 'navigateTo'>;
type ElementIconRendererProps = {
  node: {
    id: string;
    title: string;
    icon?: string | null | undefined;
  };
  className?: string;
};
type ElementIconRenderer = (props: ElementIconRendererProps) => ReactNode;
type LikeC4ColorScheme = 'light' | 'dark';
type RelationshipBrowserScope = 'global' | 'view';
type OverrideReactFlowProps = Pick<ReactFlowProps<Types.AnyNode, Types.AnyEdge>, 'paneClickDistance' | 'nodeClickDistance' | 'selectionKeyCode' | 'panActivationKeyCode' | 'multiSelectionKeyCode' | 'zoomActivationKeyCode' | 'snapToGrid' | 'snapGrid' | 'onlyRenderVisibleElements' | 'nodesDraggable' | 'nodesFocusable' | 'elementsSelectable' | 'selectNodesOnDrag' | 'panOnDrag' | 'preventScrolling' | 'zoomOnScroll' | 'zoomOnPinch' | 'panOnScroll' | 'panOnScrollSpeed' | 'panOnScrollMode' | 'zoomOnDoubleClick' | 'nodeDragThreshold' | 'edgesFocusable'>;
type PaddingUnit = 'px' | '%';
type PaddingWithUnit = `${number}${PaddingUnit}` | number;
type ViewPaddings = {
  top?: PaddingWithUnit;
  right?: PaddingWithUnit;
  bottom?: PaddingWithUnit;
  left?: PaddingWithUnit;
  x?: PaddingWithUnit;
  y?: PaddingWithUnit;
};
/**
 * Padding around the diagram
 *
 * @example
 * {
 *   top: '8px',
 *   right: '8px',
 *   bottom: '8px',
 *   left: '8px',
 * }
 *
 * {
 *   x: '16px',
 *   y: '16px',
 * }
 */
type ViewPadding = PaddingWithUnit | ViewPaddings;
interface LikeC4DiagramProperties<A extends Any$1$1 = Unknown$1> {
  view: LayoutedView<A>;
  className?: string | undefined;
  /**
   * Enable/disable panning
   * @default true
   */
  pannable?: boolean | undefined;
  /**
   * Enable/disable zooming
   * @default true
   */
  zoomable?: boolean | undefined;
  /**
   * Show/hide panel with top left controls
   *
   * @default true
   */
  controls?: boolean | undefined;
  /**
   * If set, initial viewport will show all nodes & edges
   * @default true
   */
  fitView?: boolean | undefined;
  /**
   * Initial centered zoom level. When set, it overrides automatic fit-to-view.
   */
  initialZoom?: number | undefined;
  /**
   * Padding around the diagram (number - pixels)
   * @default 16 - 16px
   *
   * @see {@link ViewPadding}
   *
   * @example
   * ```tsx
   * <LikeC4Diagram
   *   fitViewPadding={{
   *     x: '16px',
   *     y: 16,
   *   }}
   * />
   *
   * <LikeC4Diagram
   *   fitViewPadding={{
   *     top: 8,
   *     right: '8px',
   *     bottom: '1px',
   *     left: '8px',
   *   }}
   * />
   * ```
   */
  fitViewPadding?: ViewPadding | undefined;
  /**
   * If not readonly, or `enableFocusMode`, `onNavigateTo` or  `onNodeClick` are set - nodes will be selectable
   *
   * @default false
   */
  nodesSelectable?: boolean | undefined;
  /**
   * Initial width of the diagram
   * (supposed to be used during SSR)
   */
  initialWidth?: number | undefined;
  /**
   * Initial height of the diagram
   * (supposed to be used during SSR)
   */
  initialHeight?: number | undefined;
  /**
   * Background pattern
   * @default 'dots'
   */
  background?: 'transparent' | 'solid' | 'dots' | 'lines' | 'cross' | undefined;
  /**
   * Show back/forward history navigation buttons
   * @default true if `onNavigateTo` is set
   */
  showNavigationButtons?: undefined | boolean;
  /**
   * Display notations in the bottom right corner
   * (Active if only notations are present)
   *
   * @default false
   */
  enableNotations?: boolean | undefined;
  /**
   * Display dropdown with details on relationship's label click
   * @default false
   */
  enableRelationshipDetails?: boolean | undefined;
  /**
   * If double click on a node should enable focus mode, i.e. highlight incoming/outgoing edges
   * @default false
   */
  enableFocusMode?: boolean | undefined;
  /**
   * Enable search popup for elements and views
   * @default true
   */
  enableSearch?: boolean | undefined;
  /**
   * Enable modal with element details
   * @default false
   */
  enableElementDetails?: boolean | undefined;
  /**
   * Experimental feature to browse relationships
   *
   * @default false
   */
  enableRelationshipBrowser?: boolean | undefined;
  /**
   * Initial scope for the relationship browser
   *
   * @default 'view'
   */
  relationshipBrowserScope?: RelationshipBrowserScope | undefined;
  /**
   * If Walkthrough for dynamic views should be enabled
   * @default false
   */
  enableDynamicViewWalkthrough?: boolean | undefined;
  /**
   * Enable "Compare with auto layout" action when view was manually modified and out of sync with latest model
   * @default true if `onLayoutTypeChange` is set, false otherwise
   */
  enableCompareWithLatest?: boolean | undefined;
  /**
   * Default dynamic view display variant
   * @default 'diagram'
   */
  dynamicViewVariant?: DynamicViewDisplayVariant | undefined;
  /**
   * Display element tags in the bottom left corner
   * @default false
   */
  enableElementTags?: boolean | undefined;
  /**
   * Display element notes, if they are present in the view
   *
   * @default true
   */
  enableNotes?: boolean | undefined;
  /**
   * Improve performance by hiding certain elements and reducing visual effects (disable mix-blend, shadows, animations)
   * Enable it if you have a large or static view
   * - `auto` - will be `true` if view has more then 3000 * 2000 pixels
   *
   * @default 'auto'
   */
  reduceGraphics?: 'auto' | boolean | undefined;
  /**
   * Render icon for an element, bundled or remote
   * By default, if icon is http:// or https://, it will be rendered as an image
   *
   * Consider using `IconRendererProvider`
   */
  renderIcon?: ElementIconRenderer | undefined;
  /**
   * Override node renderers
   */
  renderNodes?: NodeRenderers | undefined;
  /**
   * Dynamic filter, applies both to nodes and edges
   */
  where?: WhereOperator$1<A> | undefined;
  /**
   * Override ReactFlow props
   */
  reactFlowProps?: OverrideReactFlowProps | undefined;
  /**
   * Minimum zoom level
   * @default 0.05
   */
  minZoom?: number | undefined;
  /**
   * Maximum zoom level
   * @default 3
   */
  maxZoom?: number | undefined;
}
type OpenSourceParams<A extends Any$1$1 = Unknown$1> = {
  element: Fqn$1$2<A>;
  property?: string;
} | {
  relation: RelationId$1;
} | {
  deployment: DeploymentFqn$1<A>;
  property?: string;
} | {
  view: StrictViewId<A>;
} | {
  view: StrictViewId<A>;
  astPath: string;
};
/**
 * "Go to source" action
 */
type OnOpenSource<A extends Any$1$1 = Unknown$1> = (params: OpenSourceParams<A>) => void;
type OnNavigateTo<A extends Any$1$1 = Unknown$1> = (to: ViewId$1$2<A>, event?: MouseEvent$1, element?: DiagramNodeWithNavigate<A>) => void;
type OnNodeClick<A extends Any$1$1 = Unknown$1> = (node: DiagramNode<A>, event: MouseEvent$1) => void;
type OnEdgeClick<A extends Any$1$1 = Unknown$1> = (edge: DiagramEdge<A>, event: MouseEvent$1) => void;
/**
 * On pane/canvas click (not on any node or edge)
 */
type OnCanvasClick = (event: MouseEvent$1) => void;
type OnCanvasContextMenu = (event: MouseEvent$1) => void;
type OnInitialized = (params: {
  diagram: DiagramApi;
  xyflow: XYFlowInstance;
}) => void;
type OnLayoutTypeChange = (layoutType: LayoutType) => void;
type OnRelationshipBrowserScopeChange = (scope: RelationshipBrowserScope) => void;
interface LikeC4DiagramEventHandlers<A extends Any$1$1 = Unknown$1> {
  onNavigateTo?: OnNavigateTo<A> | null | undefined;
  onNodeClick?: OnNodeClick<A> | null | undefined;
  onNodeContextMenu?: OnNodeClick<A> | null | undefined;
  onCanvasContextMenu?: OnCanvasContextMenu | null | undefined;
  onEdgeClick?: OnEdgeClick<A> | null | undefined;
  onEdgeContextMenu?: OnEdgeClick<A> | null | undefined;
  onCanvasClick?: OnCanvasClick | null | undefined;
  onCanvasDblClick?: OnCanvasClick | null | undefined;
  onLogoClick?: null | undefined | (() => void);
  onOpenSource?: OnOpenSource<A> | null | undefined;
  onInitialized?: OnInitialized | null | undefined;
  /**
   * Triggered when user changes layout type (e.g. from 'manual' to 'auto')
   * Expected another `view` to be passed to the diagram
   *
   * @param layoutType new layout type
   */
  onLayoutTypeChange?: OnLayoutTypeChange | null | undefined;
  onRelationshipBrowserScopeChange?: OnRelationshipBrowserScopeChange | null | undefined;
}
//#endregion
//#region ../diagram/dist/likec4diagram/state/diagram-api.d.mts
//#region src/likec4diagram/state/diagram-api.d.ts
type Any$1 = t.aux.Any;
type Unknown = t.aux.UnknownLayouted;
type ViewId$1$1<A> = t.aux.ViewId<A>;
type Fqn$1$1<A> = t.aux.Fqn<A>;
type NodeId$1$1 = t.aux.NodeId;
type EdgeId$1$1 = t.aux.EdgeId;
declare class DiagramApi<A extends Any$1 = Unknown> {
  private static cache;
  static withActor(actorRef: RefObject<DiagramActorRef>): DiagramApi;
  /**
   * React ref to the diagram actor
   */
  readonly ref: RefObject<DiagramActorRef>;
  private constructor();
  /**
   * @warning Do not use in render phase
   */
  get actor(): DiagramActorRef;
  /**
   * @warning Do not use in render phase
   */
  get currentView(): t.DiagramView<A>;
  /**
   * Editor actor reference
   * @warning Do not use in render phase
   */
  editorActor(): EditorActorRef;
  /**
   * Overlays actor reference
   * @warning Do not use in render phase
   */
  overlays(): OverlaysActorRef;
  /**
   * Search actor reference
   * @warning Do not use in render phase
   */
  searchActor(): SearchActorRef;
  /**
   * Send event to diagram actor
   */
  send(event: Events): void;
  /**
   * Navigate to view
   * @param viewId - Target view ID
   * @param fromNode - Node from which navigation was triggered
   * @param focusOnElement - Element FQN to focus after navigation (from search)
   */
  navigateTo(viewId: ViewId$1$1<A>, fromNode?: NodeId$1$1, focusOnElement?: Fqn$1$1<A>): void;
  /**
   * Navigate back or forward in history
   */
  navigate(direction: 'back' | 'forward'): void;
  /**
   * Fit diagram to view
   */
  fitDiagram(duration?: number): void;
  /**
   * Open relationships browser
   */
  openRelationshipsBrowser(fqn: Fqn$1$1<A>, scope?: RelationshipBrowserScope): void;
  /**
   * If running in editor, trigger opening source file
   */
  openSource(params: OpenSourceParams<Unknown>): void;
  /**
   * Open element details card
   */
  openElementDetails(fqn: Fqn$1$1<A>, fromNode?: NodeId$1$1): void;
  openRelationshipDetails(...params: [edgeId: EdgeId$1$1] | [source: Fqn$1$1<A>, target: Fqn$1$1<A>]): void;
  updateNodeData(nodeId: NodeId$1$1, data: PartialDeep<Types.NodeData>): void;
  updateEdgeData(edgeId: EdgeId$1$1, data: PartialDeep<Types.EdgeData>): void;
  highlightNode(nodeId: NodeId$1$1): void;
  highlightEdge(edgeId: EdgeId$1$1): void;
  unhighlightAll(): void;
  select(target?: {
    nodes?: NodeId$1$1[];
    edges?: (EdgeId$1$1 | t.StepPath)[];
  }): void;
  /**
   * Center viewport on a given node
   */
  centerViewportOnNode(target: NodeId$1$1): void;
  /**
   * Center viewport on a given edge (centering on edge means including both source and target nodes in view)
   */
  centerViewportOnEdge(target: EdgeId$1$1): void;
  /**
   * Start editing, either node or edge
   */
  startEditing(subject: 'node' | 'edge'): void;
  /**
   * Stop editing
   * @param wasChanged - whether there were changes made during editing
   * @default false
   */
  stopEditing(wasChanged?: boolean): void;
  /**
   * Undo last editing operation
   * @returns true if there was something to undo
   */
  undoEditing(): boolean;
  /**
   * Align nodes
   */
  align(mode: AlignmentMode): void;
  /**
   * Reset edge control points
   */
  resetEdgeControlPoints(): void;
  /**
   * Focus node
   */
  focusNode(nodeId: NodeId$1$1): void;
  /**
   * Focus on element by FQN (finds the node and focuses on it).
   * Used by search to highlight an element on the current view.
   */
  focusOnElement(elementFqn: Fqn$1$1<A>): void;
  /**
   * @warning Do not use in render phase
   */
  getContext(): Context;
  /**
   * @warning Do not use in render phase
   */
  findDiagramNode(xynodeId: string): t.DiagramNode<A> | null;
  /**
   * @warning Do not use in render phase
   */
  findEdge(xyedgeId: string): Types.Edge | null;
  /**
   * @warning Do not use in render phase
   */
  findDiagramEdge(xyedgeId: string): t.DiagramEdge<A> | null;
  startWalkthrough(stepId?: t.StepPath): void;
  walkthroughStep(value?: 'next' | 'prev' | {
    step: t.StepPath;
  }): void;
  stopWalkthrough(): void;
  toggleFeature(feature: TogglableFeature, forceValue?: boolean): void;
  highlightNotation(notation: NodeNotation, kind?: string): void;
  unhighlightNotation(): void;
  openSearch(searchValue?: string): void;
  triggerChange(change: ViewChange): void;
  /**
   * Switch dynamic view display variant
   */
  switchDynamicViewVariant(variant: DynamicViewDisplayVariant): void;
  /**
   * Switch element view display variant ('diagram' | 'graph')
   */
  switchElementViewVariant(variant: ElementViewDisplayVariant): void;
  /**
   * Toggle sequence flow collapse/expand
   */
  toggleSequenceFlow(flowId: t.StepPath): void;
}
//#endregion
//#endregion
//#region ../diagram/dist/context/IconRenderer.d.mts
//#region src/context/IconRenderer.d.ts
/**
 * Provider for custom element icon renderers
 *
 * @example
 * ```tsx
 * const MyIconRenderer: ElementIconRenderer = ({ node }) => {
 *   return <div>{node.title}</div>
 * }
 *
 * <IconRendererProvider value={MyIconRenderer}>
 *   <LikeC4Diagram />
 * </IconRendererProvider>
 * ```
 */
export declare function IconRendererProvider({ value, children }: PropsWithChildren<{
  value: ElementIconRenderer | null;
}>): import("react").JSX.Element;
export declare function DefaultIconRenderer({ node, ...props }: ElementIconRendererProps): import("react").JSX.Element | null;
//#endregion
//#endregion
//#region ../diagram/dist/base/const.d.mts
//#region src/base/const.d.ts
export declare const MinZoom = 0.05;
export declare const MaxZoom = 3;
//#endregion
//#endregion
//#region ../diagram/dist/LikeC4Diagram.d.mts
//#region src/LikeC4Diagram.d.ts
type LikeC4DiagramProps<A extends Any = Any> = PropsWithChildren<LikeC4DiagramProperties<A> & LikeC4DiagramEventHandlers<A>>;
/**
 * Low-level component to display LikeC4 view
 * Expects CSS to be injected
 *
 * Use {@link ReactLikeC4} or {@link LikeC4View} for ready-to-use component
 */
export declare function LikeC4Diagram<A extends Any = Any>({ onCanvasClick, onCanvasContextMenu, onCanvasDblClick, onEdgeClick, onEdgeContextMenu, onNavigateTo, onNodeClick, onNodeContextMenu, onOpenSource, onLogoClick, onLayoutTypeChange, onRelationshipBrowserScopeChange, onInitialized, view, className, controls, fitView, initialZoom, fitViewPadding: _fitViewPadding, pannable, zoomable, background, enableElementTags, enableFocusMode, enableElementDetails, enableRelationshipDetails, enableRelationshipBrowser, relationshipBrowserScope, enableCompareWithLatest, nodesSelectable, enableNotations, showNavigationButtons, enableDynamicViewWalkthrough, dynamicViewVariant, enableSearch, enableNotes, initialWidth, initialHeight, reduceGraphics, renderIcon, where, reactFlowProps, renderNodes, minZoom, maxZoom, children }: LikeC4DiagramProps<A>): JSX$1.Element;
//#endregion
//#endregion
//#region ../diagram/dist/LikeC4ModelProvider.d.mts
//#region src/LikeC4ModelProvider.d.ts
interface LikeC4ModelProviderProps {
  likec4model: LikeC4Model<any>;
}
/**
 * Ensures LikeC4Model context
 */
export declare function LikeC4ModelProvider({ children, likec4model }: PropsWithChildren<LikeC4ModelProviderProps>): JSX$1.Element;
//#endregion
//#endregion
//#region ../diagram/dist/hooks/useDiagramCompareLayout.d.mts
//#region src/hooks/useDiagramCompareLayout.d.ts
declare function selectCompareLayoutState({ context }: DiagramMachineSnapshot): {
  isEnabled: false;
  hasEditor: boolean;
  isEditable: false;
  state: 'inactive';
  drifts: null;
  canApplyLatest: boolean;
  layout: t.LayoutType;
} | {
  isEnabled: true;
  hasEditor: boolean;
  isEditable: boolean;
  state: 'comparing' | 'inactive';
  drifts: readonly [t.LayoutedViewDriftReason, ...t.LayoutedViewDriftReason[]];
  canApplyLatest: boolean;
  layout: t.LayoutType;
};
/**
 * Current manual-layout comparison state exposed by {@link useDiagramCompareLayout}.
 */
type DiagramCompareLayoutState = ReturnType<typeof selectCompareLayoutState>;
/**
 * Manual-layout actions exposed by {@link useDiagramCompareLayout}.
 */
type DiagramCompareLayoutOps = {
  /**
   * Toggles the compare mode on or off.
   */
  toggleCompare: (force?: 'on' | 'off') => void;
  /**
   * Switches the layout type between 'auto' and 'manual'.
   */
  switchLayout: (layoutType: t.LayoutType) => void;
  /**
   * Merges the latest layout into the manual layout.
   */
  applyLatestToManual: () => void;
  /**
   * Resets the manual layout to its default state.
   */
  resetManualLayout: () => void;
};
/**
 * Controls LikeC4's manual-layout comparison from custom diagram children.
 *
 * The hook must be called by a component rendered inside {@link LikeC4Diagram}.
 */
export declare function useDiagramCompareLayout(): [DiagramCompareLayoutState, DiagramCompareLayoutOps];
//#endregion
//#endregion
//#region ../diagram/dist/StaticLikeC4Diagram.d.mts
//#region src/StaticLikeC4Diagram.d.ts
type StaticLikeC4DiagramProps<A extends Any> = Pick<LikeC4DiagramProperties<A>, 'view' | 'className' | 'fitView' | 'fitViewPadding' | 'background' | 'enableElementDetails' | 'enableRelationshipDetails' | 'enableRelationshipBrowser' | 'relationshipBrowserScope' | 'enableElementTags' | 'reduceGraphics' | 'initialWidth' | 'initialHeight' | 'initialZoom' | 'maxZoom' | 'minZoom' | 'renderIcon' | 'renderNodes' | 'dynamicViewVariant' | 'where'>;
/**
 * StaticLikeC4Diagram is a component that renders a LikeC4 diagram in a static way.
 * (Export/Embed)
 *
 * @internal
 */
export declare function StaticLikeC4Diagram<A extends Any = UnknownLayouted>({ view, fitView, fitViewPadding, enableRelationshipDetails, enableRelationshipBrowser, background, className, ...rest }: StaticLikeC4DiagramProps<A>): JSX$1.Element;
//#endregion
//#endregion
//#region ../diagram/dist/LikeC4View.d.mts
//#region src/LikeC4View.d.ts
interface LikeC4ViewProps<A extends t.aux.Any = t.aux.UnknownLayouted> {
  /**
   * View to display.
   */
  viewId: t.aux.ViewId<A>;
  /**
   * Layout to display
   * - `auto`: auto-layouted from the current sources
   * - `manual`: manually layouted (if available, falls back to `auto`)
   *
   * @default 'manual'
   */
  layoutType?: t.LayoutType | undefined;
  /**
   * Enable/disable panning
   * @default false
   */
  pannable?: boolean | undefined;
  /**
   * Enable/disable zooming
   * @default false
   */
  zoomable?: boolean | undefined;
  /**
   * @default true
   */
  keepAspectRatio?: boolean | undefined;
  /**
   * Background pattern
   * @default 'transparent'
   */
  background?: 'dots' | 'lines' | 'cross' | 'transparent' | 'solid' | undefined;
  /**
   * Click on the view opens a modal with browser.
   * You can customize or disable the browser.
   *
   * @default true
   */
  browser?: boolean | LikeC4BrowserProps | undefined;
  /**
   * @default - determined by the user's system preferences.
   */
  colorScheme?: 'light' | 'dark' | undefined;
  /**
   * LikeC4 views are using 'IBM Plex Sans' font.
   * By default, component injects the CSS to document head.
   * Set to false if you want to handle the font yourself.
   *
   * @default true
   */
  injectFontCss?: boolean | undefined;
  /**
   * Show/hide panel with top left controls,
   * @default false
   */
  controls?: boolean | undefined;
  /**
   * If set, initial viewport will show all nodes & edges
   * @default true
   */
  fitView?: boolean | undefined;
  /**
   * Padding around the diagram
   * @default '16px'
   *
   * @see {@link ViewPadding}
   *
   * @example
   * ```tsx
   * <LikeC4View
   *   fitViewPadding={{
   *     x: '16px',
   *     y: 16,
   *   }}
   * />
   *
   * <LikeC4View
   *   fitViewPadding={{
   *     top: 8,
   *     right: '8px',
   *     bottom: '1px',
   *     left: '8px',
   *   }}
   * />
   * ```
   */
  fitViewPadding?: ViewPadding | undefined;
  /**
   * Show back/forward navigation buttons in controls panel
   * @default false
   */
  showNavigationButtons?: undefined | boolean;
  /**
   * Display notations of the view
   * @default false
   */
  enableNotations?: boolean | undefined;
  /**
   * If double click on a node should enable focus mode, i.e. highlight incoming/outgoing edges
   * Conflicts with `browser` prop
   *
   * @default false
   */
  enableFocusMode?: boolean | undefined;
  /**
   * If Walkthrough for dynamic views should be enabled
   * @default false
   */
  enableDynamicViewWalkthrough?: boolean | undefined;
  /**
   * Default dynamic view display variant
   * @default 'diagram'
   */
  dynamicViewVariant?: t.DynamicViewDisplayVariant | undefined;
  /**
   * Enable popup with element details
   * @default false
   */
  enableElementDetails?: boolean | undefined;
  /**
   * Display element tags in the bottom left corner
   * @default false
   */
  enableElementTags?: boolean | undefined;
  /**
   * Display dropdown with details on relationship's label click
   * @default false
   */
  enableRelationshipDetails?: boolean | undefined;
  /**
   * Allow popup to browse relationships
   *
   * @default enableRelationshipDetails
   */
  enableRelationshipBrowser?: boolean | undefined;
  /**
   * Display element notes, if they are present in the view
   *
   * @default false
   */
  enableNotes?: boolean | undefined;
  /**
   * Improve performance by hiding certain elements and reducing visual effects (disable mix-blend, shadows, animations)
   *
   * @default 'auto' - will be set to true if view is pannable and has more than 3000 * 2000 pixels
   */
  reduceGraphics?: 'auto' | boolean | undefined;
  where?: t.WhereOperator<A> | undefined;
  /**
   * Override some react flow props
   */
  reactFlowProps?: OverrideReactFlowProps | undefined;
  className?: string | undefined;
  style?: CSSProperties | undefined;
  /**
   * Override Mantine theme
   */
  mantineTheme?: any;
  /** Function to generate nonce attribute added to all generated `<style />` tags */
  styleNonce?: string | (() => string) | undefined;
  /**
   * Override node renderers
   */
  renderNodes?: NodeRenderers | undefined;
  /**
   * Render custom icon for a node
   * By default, if icon is http:// or https://, it will be rendered as an image
   */
  renderIcon?: ElementIconRenderer | undefined;
  /**
   * Children to render inside the diagram (not inside the browser overlay)
   */
  children?: ReactNode | undefined;
}
interface LikeC4BrowserProps {
  /**
   * Background pattern for the browser view.
   * @default 'dots'
   */
  background?: 'dots' | 'lines' | 'cross' | 'transparent' | 'solid' | undefined;
  /**
   * Padding around the diagram
   * @default '16px'
   */
  fitViewPadding?: PaddingWithUnit | undefined;
  /**
   * Show/hide panel with top left controls,
   *
   * @default true
   */
  controls?: boolean | undefined;
  /**
   * Show back/forward navigation buttons
   * @default true
   */
  showNavigationButtons?: undefined | boolean;
  /**
   * Enable search popup for elements and views
   * @default true
   */
  enableSearch?: boolean | undefined;
  /**
   * If double click on a node should enable focus mode
   *
   * @default true
   */
  enableFocusMode?: boolean | undefined;
  /**
   * If Walkthrough for dynamic views should be enabled
   * @default true
   */
  enableDynamicViewWalkthrough?: boolean | undefined;
  /**
   * Default dynamic view display variant
   * @default 'diagram'
   */
  dynamicViewVariant?: t.DynamicViewDisplayVariant | undefined;
  /**
   * Enable popup with element details
   * @default true
   */
  enableElementDetails?: boolean | undefined;
  /**
   * Experimental feature to browse relationships
   *
   * @default true
   */
  enableRelationshipBrowser?: boolean | undefined;
  /**
   * Display dropdown with details on relationship's label click
   * @default enableRelationshipBrowser
   */
  enableRelationshipDetails?: boolean | undefined;
  /**
   * Display element tags in the bottom left corner
   * @default true
   */
  enableElementTags?: boolean | undefined;
  /**
   * Display notations of the view
   * @default true
   */
  enableNotations?: boolean | undefined;
  /**
   * Enable "Compare with auto layout" action when view was manually modified and out of sync with latest model
   * @default true
   */
  enableCompareWithLatest?: boolean | undefined;
  /**
   * Display element notes, if they are present in the view
   *
   * @default true
   */
  enableNotes?: boolean | undefined;
  /**
   * Improve performance by hiding certain elements and reducing visual effects (disable mix-blend, shadows, animations)
   *
   * @default 'auto' - will be set to true if view is pannable and has more than 3000 * 2000 pixels
   */
  reduceGraphics?: 'auto' | boolean | undefined;
  className?: string | undefined;
  style?: CSSProperties | undefined;
  /**
   * Override some react flow props
   */
  reactFlowProps?: OverrideReactFlowProps | undefined;
  /**
   * Children to render inside the browser overlay
   */
  children?: ReactNode | undefined;
}
/**
 * Ready-to-use component to display embedded LikeC4 view,
 * OnClick allows to browse the model.
 *
 * {@link ReactLikeC4} gives you more control.
 *
 * Component is wrapped in ShadowRoot to isolate styles.
 */
export declare function LikeC4View<A extends t.aux.Any = t.aux.UnknownLayouted>({ viewId, className, pannable, zoomable, keepAspectRatio, colorScheme, injectFontCss, controls, layoutType: initialLayoutType, background, browser, showNavigationButtons, enableNotations, enableFocusMode, enableDynamicViewWalkthrough, enableElementDetails, enableRelationshipDetails, enableRelationshipBrowser, enableNotes, reduceGraphics, mantineTheme, styleNonce, style, reactFlowProps, renderNodes, children, ...props }: LikeC4ViewProps<A>): JSX$1.Element;
//#endregion
//#endregion
//#region ../diagram/dist/ReactLikeC4.d.mts
//#region src/ReactLikeC4.d.ts
type ReactLikeC4Props<A extends t.aux.Any = t.aux.UnknownLayouted> = {
  viewId: t.aux.ViewId<A>;
  /**
   * Layout to display
   * - `auto`: auto-layouted from the current sources
   * - `manual`: manually layouted (if available, falls back to `auto`)
   *
   * Uncontrolled initial value, use `onLayoutTypeChange` to control it.
   *
   * @default 'manual'
   */
  layoutType?: t.LayoutType | undefined;
  /**
   * Keep aspect ratio of the diagram
   *
   * @default false
   */
  keepAspectRatio?: boolean | undefined;
  /**
   * By default determined by the user's system preferences.
   */
  colorScheme?: 'light' | 'dark' | undefined;
  /**
   * LikeC4 views are using 'IBM Plex Sans Variable' font.
   * By default, component injects the CSS to document head.
   * Set to false if you want to handle the font yourself.
   *
   * @default true
   */
  injectFontCss?: boolean | undefined;
  style?: CSSProperties | undefined;
  mantineTheme?: any;
  /** Function to generate nonce attribute added to all generated `<style />` tags */
  styleNonce?: string | (() => string | undefined) | undefined;
  children?: ReactNode | undefined;
} & Omit<LikeC4DiagramProperties<A>, 'view'> & LikeC4DiagramEventHandlers<A>;
/**
 * Ready-to-use component to display embedded LikeC4 view, same as {@link LikeC4View}
 * But provides more control over the diagram
 *
 * Component is wrapped in ShadowRoot to isolate styles.
 */
export declare function ReactLikeC4<A extends t.aux.Any = t.aux.UnknownLayouted>({ viewId, layoutType: initialLayoutType, className, colorScheme, injectFontCss, enableNotations, keepAspectRatio, style, mantineTheme, styleNonce, ...props }: ReactLikeC4Props<A>): JSX$1.Element;
//#endregion
//#endregion
//#region ../diagram/dist/utils/view-bounds.d.mts
//#region src/utils/view-bounds.d.ts
/**
 * Picks appropriate bounds from the view,
 * depending on its type and dynamic variant
 */
export declare function pickViewBounds(view: LayoutedView, dynamicVariant?: DynamicViewDisplayVariant): BBox$1;
//#endregion
//#endregion
//#region ../diagram/dist/projects-overview/ProjectsOverviewXY.d.mts
//#region src/projects-overview/ProjectsOverviewXY.d.ts
type ProjectsOverviewXYProps = {
  /**
   * Background pattern
   * @default 'dots'
   */
  background?: 'dots' | 'lines' | 'cross' | 'transparent' | 'solid' | undefined;
  /**
   * @default - determined by the user's system preferences.
   */
  colorScheme?: 'light' | 'dark' | undefined;
};
//#endregion
//#endregion
//#region ../diagram/dist/projects-overview/ProjectsOverview.d.mts
//#region src/projects-overview/ProjectsOverview.d.ts
type ProjectsOverviewProps = {
  view: LayoutedProjectsView;
  /**
   * Callback when project is selected (e.g. clicked)
   */
  onNavigateToProject?: undefined | ((projectId: ProjectId) => void);
  fitViewPadding?: ViewPadding | undefined;
} & ProjectsOverviewXYProps;
//#endregion
//#endregion
//#region ../diagram/dist/LikeC4ProjectsOverview.d.mts
//#region src/LikeC4ProjectsOverview.d.ts
type LikeC4ProjectsOverviewProps = Simplify<ProjectsOverviewProps & {
  className?: string;
  onSelectProject?: ProjectsOverviewProps['onNavigateToProject'];
}>;
export declare function LikeC4ProjectsOverview({ view, className, onNavigateToProject, ...props }: LikeC4ProjectsOverviewProps): JSX$1.Element;
//#endregion
//#endregion
//#region ../diagram/dist/search/SearchContext.d.mts
//#region src/search/SearchContext.d.ts
interface SearchContextValue {
  searchValue: string;
  setSearchValue: (value: string) => void;
  normalizedSearch: string;
  navigateTo: (viewId: ViewId$1, focusOnElement?: Fqn$1) => void;
  openPickView: (elementFqn: Fqn$1) => void;
  closePickView: () => void;
  pickViewFor: Fqn$1 | null;
  close: () => void;
  currentViewId: string | null;
  openedWithSearch: string | null;
}
export declare const SearchContext: import("react").Context<SearchContextValue | null>;
export declare function useSearchContext(): SearchContextValue;
/**
 * Normalize a raw search string for comparison.
 * Extracted as a pure function so both XState and standalone adapters can reuse it.
 */
export declare function normalizeSearch(value: string): string;
//#endregion
//#endregion
//#region ../diagram/dist/search/Search.d.mts
//#region src/search/Search.d.ts
declare const dialogCss: string;
declare const bodyCss: string;
/**
 * The shared search panel content used by both diagram and overview search.
 * Must be rendered inside a SearchContext.Provider.
 */
export declare const SearchPanelContent: import("react").ForwardRefExoticComponent<import("react").RefAttributes<HTMLDivElement>>;
//#endregion
//#endregion
//#region ../diagram/dist/components/SearchControl.d.mts
//#region src/components/SearchControl.d.ts
interface SearchControlProps extends Omit<UnstyledButtonProps, 'className'>, ElementProps<'button'> {}
export declare function SearchControl({ className, ...others }: SearchControlProps): import("react").JSX.Element;
//#endregion
//#endregion
//#region ../diagram/dist/components/Logo.d.mts
//#region src/components/Logo.d.ts
type LogoProps = Omit<SVGProps<SVGSVGElement>, 'viewBox'>;
export declare const Logo: import("react").ForwardRefExoticComponent<Omit<LogoProps, "ref"> & import("react").RefAttributes<SVGSVGElement>>;
export declare const LogoIcon: import("react").ForwardRefExoticComponent<Omit<LogoProps, "ref"> & import("react").RefAttributes<SVGSVGElement>>;
//#endregion
//#endregion
//#region src/index.d.ts
export declare const xyflow: {
  readonly ControlButton: typeof ControlButton;
  readonly MiniMap: {
    ({ style, className, nodeStrokeColor, nodeColor, nodeClassName, nodeBorderRadius, nodeStrokeWidth, nodeComponent, bgColor, maskColor, maskStrokeColor, maskStrokeWidth, position, onClick, onNodeClick, pannable, zoomable, ariaLabel, inversePan, zoomStep, offsetScale }: MiniMapProps<Types.AnyNode>): import("react").JSX.Element;
    displayName: string;
  };
  readonly MiniMapNode: import("react").MemoExoticComponent<({ id, x, y, width, height, style, color, strokeColor, strokeWidth, className, borderRadius, shapeRendering, selected, onClick }: MiniMapNodeProps) => import("react").JSX.Element>;
  readonly NodeToolbar: typeof NodeToolbar;
  readonly Panel: import("react").ForwardRefExoticComponent<import("react").HTMLAttributes<HTMLDivElement> & {
    position?: PanelPosition;
  } & import("react").RefAttributes<HTMLDivElement>>;
  readonly Position: typeof Position;
  readonly ViewportPortal: typeof ViewportPortal;
};
//#endregion
export { type BaseEdge, type BaseEdgeData, type BaseEdgeProps, type BaseEdgePropsWithData, type BaseNode, type BaseNodeData, type BaseNodeProps, type BaseNodePropsWithData, CompoundDeploymentNode$1 as CompoundDeploymentNode, CompoundElementNode$1 as CompoundElementNode, type CurrentViewModel, type DiagramActorRef, type DiagramMachineSnapshot as DiagramActorSnapshot, type DiagramApi, type DiagramCompareLayoutOps, type DiagramCompareLayoutState, type Context as DiagramContext, type EmittedEvents as DiagramEmittedEvents, type Events as DiagramEvents, type DiagramNodeWithNavigate, type ElementIconRenderer, type ElementIconRendererProps, ElementNode$1 as ElementNode, ElementShape$1 as ElementShape, type EnabledFeatures, ErrorBoundary$1 as ErrorBoundary, type FeatureName, type LikeC4BrowserProps, type LikeC4ColorScheme, type LikeC4DiagramEventHandlers, type LikeC4DiagramProperties, type LikeC4DiagramProps, type LikeC4EditorCallbacks, type LikeC4EditorChangeResult, type LikeC4EditorProviderProps, type LikeC4ModelProviderProps, type LikeC4ProjectsOverviewProps, type LikeC4ProjectsProviderProps, type LikeC4ViewProps, type NodeRenderers, type OnCanvasClick, type OnEdgeClick, type OnInitialized, type OnNavigateTo, type OnNodeClick, type OnOpenSource, type OpenSourceParams, type OverlayProps, type PaddingUnit, type PaddingWithUnit, type ReactLikeC4Props, type SearchContextValue, SequenceActorNode$1 as SequenceActorNode, SequenceParallelArea$1 as SequenceParallelArea, type Types, ViewGroupNode$1 as ViewGroupNode, type ViewPadding, type ViewPaddings, type WhereOperator$1 as WhereOperator, type XYStoreState, bodyCss as searchBodyCss, dialogCss as searchDialogCss, selectDiagramContext, selectDiagramSnapshot, useDiagramActorRef, useDiagramSelector, useUpdateEffect$1 as useUpdateEffect };