import "../src/chunks/rolldown-runtime.mjs";
import { C as safeParseAsync, D as normalizeParams, E as installLazyProp, O as own, S as safeParse, T as clone, _ as $ZodPipe, b as parse, d as $ZodBoolean, f as $ZodCodec, g as $ZodOptional, h as $ZodObject, k as shallowClone, l as _string, m as $ZodLiteral, p as $ZodDefault, u as _stringbool, v as $ZodString, w as $constructor, x as parseAsync, y as $ZodType } from "../src/chunks/libs/zod.mjs";
import { createRoot } from "react-dom/client";
import { jsx } from "react/jsx-runtime";
import { ComponentName } from "likec4:app-config";
import { LikeC4View as LikeC4View$1 } from "likec4:react";
//#region ../../node_modules/.pnpm/zod@4.6.5/node_modules/zod/v4/mini/schemas.js
var ZodMiniType = /*@__PURE__*/ $constructor("ZodMiniType", (inst, def) => {
	if (!inst._zod) throw new Error("Uninitialized schema in ZodMiniType.");
	$ZodType.init(inst, def);
	inst.def = def;
	inst.type = def.type;
}, {
	get with() {
		return this.check;
	},
	set with(value) {
		own(this, "with", value);
	},
	parse(data, params) {
		return parse(this, data, params, { callee: this.parse });
	},
	parseAsync(data, params) {
		return parseAsync(this, data, params, { callee: this.parseAsync });
	},
	safeParse(data, params) {
		return safeParse(this, data, params);
	},
	safeParseAsync(data, params) {
		return safeParseAsync(this, data, params);
	},
	check(...checks) {
		const def = this.def;
		return this.clone({
			...def,
			checks: [...def.checks ?? [], ...checks.map((ch) => typeof ch === "function" ? { _zod: {
				check: ch,
				def: { check: "custom" },
				onattach: []
			} } : ch)]
		}, { parent: true });
	},
	clone(_def, params) {
		return clone(this, _def, params);
	},
	brand() {
		return this;
	},
	register(reg, meta) {
		reg.add(this, meta);
		return this;
	},
	apply(fn, ...args) {
		return args.length === 0 ? fn(this) : fn(this, ...args);
	}
});
var ZodMiniString = /*@__PURE__*/ $constructor("ZodMiniString", (inst, def) => {
	$ZodString.init(inst, def);
	ZodMiniType.init(inst, def);
});
// @__NO_SIDE_EFFECTS__
function string(params) {
	return _string(ZodMiniString, params);
}
var ZodMiniBoolean = /*@__PURE__*/ $constructor("ZodMiniBoolean", (inst, def) => {
	$ZodBoolean.init(inst, def);
	ZodMiniType.init(inst, def);
});
var ZodMiniObject = /*@__PURE__*/ $constructor("ZodMiniObject", (inst, def) => {
	$ZodObject.init(inst, def);
	ZodMiniType.init(inst, def);
	installLazyProp(inst, "shape", (self) => self._zod.def.shape, false);
});
// @__NO_SIDE_EFFECTS__
function object(shape, params) {
	return new ZodMiniObject({
		type: "object",
		shape: shape ?? {},
		...normalizeParams(params)
	});
}
var ZodMiniLiteral = /*@__PURE__*/ $constructor("ZodMiniLiteral", (inst, def) => {
	$ZodLiteral.init(inst, def);
	ZodMiniType.init(inst, def);
});
// @__NO_SIDE_EFFECTS__
function literal(value, params) {
	return new ZodMiniLiteral({
		type: "literal",
		values: Array.isArray(value) ? value : [value],
		...normalizeParams(params)
	});
}
var ZodMiniOptional = /*@__PURE__*/ $constructor("ZodMiniOptional", (inst, def) => {
	$ZodOptional.init(inst, def);
	ZodMiniType.init(inst, def);
});
// @__NO_SIDE_EFFECTS__
function optional(innerType) {
	return new ZodMiniOptional({
		type: "optional",
		innerType
	});
}
var ZodMiniDefault = /*@__PURE__*/ $constructor("ZodMiniDefault", (inst, def) => {
	$ZodDefault.init(inst, def);
	ZodMiniType.init(inst, def);
});
// @__NO_SIDE_EFFECTS__
function _default(innerType, defaultValue) {
	return new ZodMiniDefault({
		type: "default",
		innerType,
		get defaultValue() {
			return typeof defaultValue === "function" ? defaultValue() : shallowClone(defaultValue);
		}
	});
}
var ZodMiniPipe = /*@__PURE__*/ $constructor("ZodMiniPipe", (inst, def) => {
	$ZodPipe.init(inst, def);
	ZodMiniType.init(inst, def);
});
var ZodMiniCodec = /*@__PURE__*/ $constructor("ZodMiniCodec", (inst, def) => {
	ZodMiniPipe.init(inst, def);
	$ZodCodec.init(inst, def);
});
var stringbool = (...args) => _stringbool({
	Codec: ZodMiniCodec,
	Boolean: ZodMiniBoolean,
	String: ZodMiniString
}, ...args);
//#endregion
//#region codegen/webcomponent.tsx
var propsSchema = /* @__PURE__ */ object({
	viewId: /* @__PURE__ */ _default(/* @__PURE__ */ string(), "index"),
	browser: /* @__PURE__ */ _default(stringbool(), true),
	dynamicViewVariant: /* @__PURE__ */ optional(/* @__PURE__ */ literal(["diagram", "sequence"])),
	colorScheme: /* @__PURE__ */ optional(/* @__PURE__ */ literal(["light", "dark"]))
});
var LikeC4View = class extends HTMLElement {
	shadow;
	root;
	hostCss;
	lastHostCss = "";
	constructor() {
		super();
		this.shadow = this.attachShadow({
			mode: "open",
			delegatesFocus: true
		});
	}
	updateHostCss() {
		const hostCss = `
    :host {
      display: contents;
      background-color: transparent;
      margin: 0;
      padding: 0;
    }`;
		if (hostCss !== this.lastHostCss) {
			this.hostCss?.replaceSync(hostCss);
			this.lastHostCss = hostCss;
		}
	}
	connectedCallback() {
		this.lastHostCss = "";
		this.hostCss = new CSSStyleSheet();
		this.updateHostCss();
		this.shadow.adoptedStyleSheets = [this.hostCss];
		this.render();
	}
	disconnectedCallback() {
		this.root?.unmount();
		this.root = void 0;
		this.shadow.adoptedStyleSheets.length = 0;
		this.hostCss = void 0;
	}
	static observedAttributes = [
		"view-id",
		"browser",
		"dynamic-variant",
		"color-scheme"
	];
	getProps() {
		const props = propsSchema.safeParse({
			viewId: this.getAttribute("view-id"),
			browser: this.getAttribute("browser") ?? void 0,
			dynamicViewVariant: this.getAttribute("dynamic-variant") ?? void 0,
			colorScheme: this.getAttribute("color-scheme") ?? void 0
		});
		if (!props.success) {
			console.error("Invalid props", props.error);
			return { viewId: "index" };
		}
		return props.data;
	}
	render() {
		const props = this.getProps();
		this.updateHostCss();
		this.root ??= createRoot(this.shadow);
		this.root.render(/* @__PURE__ */ jsx(LikeC4View$1, { ...props }));
	}
	attributeChangedCallback(_name) {
		if (this.root) this.render();
	}
};
customElements.define(ComponentName.View, LikeC4View);
//#endregion
export { LikeC4View };
