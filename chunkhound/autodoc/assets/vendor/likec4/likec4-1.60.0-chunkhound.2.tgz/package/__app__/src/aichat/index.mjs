import "../chunks/rolldown-runtime.mjs";
import { Suspense, lazy } from "react";
import { jsx } from "react/jsx-runtime";
import { isAIAvailable } from "likec4:rpc";
//#region src/aichat/index.tsx
var AIChat = /* @__PURE__ */ lazy(() => import("../chunks/AIChat.mjs"));
/**
* AI Chat component that is conditionally rendered based on AI availability
* Uses lazy loading to avoid importing AI components in environments where AI is not available
*/
var LazyAIChat = isAIAvailable ? () => /* @__PURE__ */ jsx(Suspense, { children: /* @__PURE__ */ jsx(AIChat, {}) }) : () => null;
//#endregion
export { LazyAIChat };
