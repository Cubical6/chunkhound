import { i as __name } from "./rolldown-runtime.mjs";
import { createContext, createElement, forwardRef, useContext, useMemo } from "react";
//#region styled-system/helpers.mjs
function isObject(value) {
	return typeof value === "object" && value != null && !Array.isArray(value);
}
var isObjectOrArray = (obj) => typeof obj === "object" && obj !== null;
function compact(value) {
	return Object.fromEntries(Object.entries(value ?? {}).filter(([_, value2]) => value2 !== void 0));
}
var isBaseCondition = (v) => v === "base";
function filterBaseConditions(c) {
	return c.slice().filter((v) => !isBaseCondition(v));
}
function toChar(code) {
	return String.fromCharCode(code + (code > 25 ? 39 : 97));
}
function toName(code) {
	let name = "";
	let x;
	for (x = Math.abs(code); x > 52; x = x / 52 | 0) name = toChar(x % 52) + name;
	return toChar(x % 52) + name;
}
function toPhash(h, x) {
	let i = x.length;
	while (i) h = h * 33 ^ x.charCodeAt(--i);
	return h;
}
function toHash(value) {
	return toName(toPhash(5381, value) >>> 0);
}
var importantRegex = /\s*!(important)?/i;
function isImportant(value) {
	return typeof value === "string" ? importantRegex.test(value) : false;
}
function withoutImportant(value) {
	return typeof value === "string" ? value.replace(importantRegex, "").trim() : value;
}
function withoutSpace(str) {
	return typeof str === "string" ? str.replaceAll(" ", "_") : str;
}
var memo$1 = /* @__PURE__ */ __name((fn) => {
	const cache = /* @__PURE__ */ new Map();
	const get = (...args) => {
		const key = JSON.stringify(args);
		if (cache.has(key)) return cache.get(key);
		const result = fn(...args);
		cache.set(key, result);
		return result;
	};
	return get;
}, "memo");
var MERGE_OMIT = /* @__PURE__ */ new Set([
	"__proto__",
	"constructor",
	"prototype"
]);
function mergeProps(...sources) {
	return sources.reduce((prev, obj) => {
		if (!obj) return prev;
		Object.keys(obj).forEach((key) => {
			if (MERGE_OMIT.has(key)) return;
			const prevValue = prev[key];
			const value = obj[key];
			if (isObject(prevValue) && isObject(value)) prev[key] = mergeProps(prevValue, value);
			else prev[key] = value;
		});
		return prev;
	}, {});
}
var isNotNullish = (element) => element != null;
function walkObject(target, predicate, options = {}) {
	const { stop, getKey } = options;
	function inner(value, path = []) {
		if (isObjectOrArray(value)) {
			const result = {};
			for (const [prop, child] of Object.entries(value)) {
				const key = getKey?.(prop, child) ?? prop;
				const childPath = [...path, key];
				if (stop?.(value, childPath)) return predicate(value, path);
				const next = inner(child, childPath);
				if (isNotNullish(next)) result[key] = next;
			}
			return result;
		}
		return predicate(value, path);
	}
	return inner(target);
}
function mapObject(obj, fn) {
	if (Array.isArray(obj)) return obj.map((value) => fn(value));
	if (!isObject(obj)) return fn(obj);
	return walkObject(obj, (value) => fn(value));
}
function toResponsiveObject(values, breakpoints) {
	return values.reduce((acc, current, index) => {
		const key = breakpoints[index];
		if (current != null) acc[key] = current;
		return acc;
	}, {});
}
function normalizeStyleObject(styles, context, shorthand = true) {
	const { utility, conditions } = context;
	const { hasShorthand, resolveShorthand } = utility;
	return walkObject(styles, (value) => {
		return Array.isArray(value) ? toResponsiveObject(value, conditions.breakpoints.keys) : value;
	}, {
		stop: (value) => Array.isArray(value),
		getKey: shorthand ? (prop) => hasShorthand ? resolveShorthand(prop) : prop : void 0
	});
}
var fallbackCondition = {
	shift: (v) => v,
	finalize: (v) => v,
	breakpoints: { keys: [] }
};
var sanitize = (value) => typeof value === "string" ? value.replaceAll(/[\n\s]+/g, " ") : value;
function createCss(context) {
	const { utility, hash, conditions: conds = fallbackCondition } = context;
	const formatClassName = (str) => [utility.prefix, str].filter(Boolean).join("-");
	const hashFn = (conditions, className) => {
		let result;
		if (hash) {
			const baseArray = [...conds.finalize(conditions), className];
			result = formatClassName(utility.toHash(baseArray, toHash));
		} else result = [...conds.finalize(conditions), formatClassName(className)].join(":");
		return result;
	};
	return memo$1(({ base, ...styles } = {}) => {
		const normalizedObject = normalizeStyleObject(Object.assign(styles, base), context);
		const classNames = /* @__PURE__ */ new Set();
		walkObject(normalizedObject, (value, paths) => {
			if (value == null) return;
			const important = isImportant(value);
			const [prop, ...allConditions] = conds.shift(paths);
			const conditions = filterBaseConditions(allConditions);
			const transformed = utility.transform(prop, withoutImportant(sanitize(value)));
			let className = hashFn(conditions, transformed.className);
			if (important) className = `${className}!`;
			classNames.add(className);
		});
		return Array.from(classNames).join(" ");
	});
}
function compactStyles(...styles) {
	return styles.flat().filter((style) => isObject(style) && Object.keys(compact(style)).length > 0);
}
function createMergeCss(context) {
	function resolve(styles) {
		const allStyles = compactStyles(...styles);
		if (allStyles.length === 1) return allStyles;
		return allStyles.map((style) => normalizeStyleObject(style, context));
	}
	function mergeCss(...styles) {
		return mergeProps(...resolve(styles));
	}
	function assignCss(...styles) {
		return Object.assign({}, ...resolve(styles));
	}
	return {
		mergeCss: memo$1(mergeCss),
		assignCss
	};
}
var wordRegex = /([A-Z])/g;
var msRegex = /^ms-/;
var hypenateProperty = memo$1((property) => {
	if (property.startsWith("--")) return property;
	return property.replace(wordRegex, "-$1").replace(msRegex, "-ms-").toLowerCase();
});
var fnRegExp = new RegExp(`^(${[
	"min",
	"max",
	"clamp",
	"calc"
].join("|")})\\(.*\\)`);
var isCssFunction = (v) => typeof v === "string" && fnRegExp.test(v);
var lengthUnitsPattern = `(?:${"cm,mm,Q,in,pc,pt,px,em,ex,ch,rem,lh,rlh,vw,vh,vmin,vmax,vb,vi,svw,svh,lvw,lvh,dvw,dvh,cqw,cqh,cqi,cqb,cqmin,cqmax,%".split(",").join("|")})`;
var lengthRegExp = new RegExp(`^[+-]?[0-9]*.?[0-9]+(?:[eE][+-]?[0-9]+)?${lengthUnitsPattern}$`);
var isCssUnit = (v) => typeof v === "string" && lengthRegExp.test(v);
var isCssVar = (v) => typeof v === "string" && /^var\(--.+\)$/.test(v);
var patternFns = {
	map: mapObject,
	isCssFunction,
	isCssVar,
	isCssUnit
};
var getPatternStyles = (pattern, styles) => {
	if (!pattern?.defaultValues) return styles;
	const defaults = typeof pattern.defaultValues === "function" ? pattern.defaultValues(styles) : pattern.defaultValues;
	return Object.assign({}, defaults, compact(styles));
};
var getSlotRecipes = (recipe = {}) => {
	const init = (slot) => ({
		className: [recipe.className, slot].filter(Boolean).join("__"),
		base: recipe.base?.[slot] ?? {},
		variants: {},
		defaultVariants: recipe.defaultVariants ?? {},
		compoundVariants: recipe.compoundVariants ? getSlotCompoundVariant(recipe.compoundVariants, slot) : []
	});
	const recipeParts = (recipe.slots ?? []).map((slot) => [slot, init(slot)]);
	for (const [variantsKey, variantsSpec] of Object.entries(recipe.variants ?? {})) for (const [variantKey, variantSpec] of Object.entries(variantsSpec)) recipeParts.forEach(([slot, slotRecipe]) => {
		slotRecipe.variants[variantsKey] ??= {};
		slotRecipe.variants[variantsKey][variantKey] = variantSpec[slot] ?? {};
	});
	return Object.fromEntries(recipeParts);
};
var getSlotCompoundVariant = (compoundVariants, slotName) => compoundVariants.filter((compoundVariant) => compoundVariant.css[slotName]).map((compoundVariant) => ({
	...compoundVariant,
	css: compoundVariant.css[slotName]
}));
function splitProps(props, ...keys) {
	const descriptors = Object.getOwnPropertyDescriptors(props);
	const dKeys = Object.keys(descriptors);
	const split = (k) => {
		const clone = {};
		for (let i = 0; i < k.length; i++) {
			const key = k[i];
			if (descriptors[key]) {
				Object.defineProperty(clone, key, descriptors[key]);
				delete descriptors[key];
			}
		}
		return clone;
	};
	const fn = (key) => split(Array.isArray(key) ? key : dKeys.filter(key));
	return keys.map(fn).concat(split(dKeys));
}
var uniq = (...items) => {
	const set = items.reduce((acc, currItems) => {
		if (currItems) currItems.forEach((item) => acc.add(item));
		return acc;
	}, /* @__PURE__ */ new Set([]));
	return Array.from(set);
};
var htmlProps = [
	"htmlSize",
	"htmlTranslate",
	"htmlWidth",
	"htmlHeight"
];
function convert(key) {
	return htmlProps.includes(key) ? key.replace("html", "").toLowerCase() : key;
}
function normalizeHTMLProps(props) {
	return Object.fromEntries(Object.entries(props).map(([key, value]) => [convert(key), value]));
}
normalizeHTMLProps.keys = htmlProps;
//#endregion
//#region styled-system/css/conditions.mjs
var conditions = new Set("_hover,_focus,_focusWithin,_focusVisible,_disabled,_active,_visited,_target,_readOnly,_readWrite,_empty,_checked,_enabled,_expanded,_highlighted,_complete,_incomplete,_dragging,_before,_after,_firstLetter,_firstLine,_marker,_selection,_file,_backdrop,_first,_last,_only,_even,_odd,_firstOfType,_lastOfType,_onlyOfType,_peerFocus,_peerHover,_peerActive,_peerFocusWithin,_peerFocusVisible,_peerDisabled,_peerChecked,_peerInvalid,_peerExpanded,_peerPlaceholderShown,_groupFocus,_groupHover,_groupActive,_groupFocusWithin,_groupFocusVisible,_groupDisabled,_groupChecked,_groupExpanded,_groupInvalid,_indeterminate,_required,_valid,_invalid,_autofill,_inRange,_outOfRange,_placeholder,_placeholderShown,_pressed,_selected,_grabbed,_underValue,_overValue,_atValue,_default,_optional,_open,_closed,_fullscreen,_loading,_hidden,_current,_currentPage,_currentStep,_today,_unavailable,_rangeStart,_rangeEnd,_now,_topmost,_motionReduce,_motionSafe,_print,_landscape,_portrait,_dark,_light,_osDark,_osLight,_highContrast,_lessContrast,_moreContrast,_ltr,_rtl,_scrollbar,_scrollbarThumb,_scrollbarTrack,_horizontal,_vertical,_icon,_starting,_noscript,_invertedColors,_shapeSizeXs,_shapeSizeSm,_shapeSizeMd,_shapeSizeLg,_shapeSizeXl,_shapeRectangle,_shapePerson,_shapeBrowser,_shapeMobile,_shapeCylinder,_shapeStorage,_shapeQueue,_shapeBucket,_shapeDocument,_shapeComponent,_shapeAgent,_notDisabled,_reduceGraphics,_reduceGraphicsOnPan,_noReduceGraphics,_whenPanning,_smallZoom,_compoundTransparent,_edgeActive,_whenHovered,_whenSelectable,_whenSelected,_whenDimmed,_whenFocused,xs,xsOnly,xsDown,sm,smOnly,smDown,md,mdOnly,mdDown,lg,lgOnly,lgDown,xl,xlOnly,xlDown,xsToSm,xsToMd,xsToLg,xsToXl,smToMd,smToLg,smToXl,mdToLg,mdToXl,lgToXl,@/xs,@/sm,@/md,@/lg,@likec4-root/xs,@likec4-root/sm,@likec4-root/md,@likec4-root/lg,@likec4-dialog/xs,@likec4-dialog/sm,@likec4-dialog/md,@likec4-dialog/lg,base".split(","));
var conditionRegex = /^@|&|&$/;
function isCondition(value) {
	return conditions.has(value) || conditionRegex.test(value);
}
var underscoreRegex = /^_/;
var conditionsSelectorRegex = /&|@/;
function finalizeConditions(paths) {
	return paths.map((path) => {
		if (conditions.has(path)) return path.replace(underscoreRegex, "");
		if (conditionsSelectorRegex.test(path)) return `[${withoutSpace(path.trim())}]`;
		return path;
	});
}
function sortConditions(paths) {
	return paths.sort((a, b) => {
		const aa = isCondition(a);
		const bb = isCondition(b);
		if (aa && !bb) return 1;
		if (!aa && bb) return -1;
		return 0;
	});
}
//#endregion
//#region styled-system/css/css.mjs
var utilities = "aspectRatio:asp,boxDecorationBreak:bx-db,zIndex:z,boxSizing:bx-s,objectPosition:obj-p,objectFit:obj-f,overscrollBehavior:ovs-b,overscrollBehaviorX:ovs-bx,overscrollBehaviorY:ovs-by,position:pos/1,top:top,left:left,inset:inset,insetInline:inset-x/insetX,insetBlock:inset-y/insetY,insetBlockEnd:inset-be,insetBlockStart:inset-bs,insetInlineEnd:inset-e/insetEnd/end,insetInlineStart:inset-s/insetStart/start,right:right,bottom:bottom,float:float,visibility:vis,display:d,hideFrom:hide,hideBelow:show,flexBasis:flex-b,flex:flex,flexDirection:flex-d/flexDir,flexGrow:flex-g,flexShrink:flex-sh,gridTemplateColumns:grid-tc,gridTemplateRows:grid-tr,gridColumn:grid-c,gridRow:grid-r,gridColumnStart:grid-cs,gridColumnEnd:grid-ce,gridAutoFlow:grid-af,gridAutoColumns:grid-ac,gridAutoRows:grid-ar,gap:gap,gridGap:grid-g,gridRowGap:grid-rg,gridColumnGap:grid-cg,rowGap:rg,columnGap:cg,justifyContent:jc,alignContent:ac,alignItems:ai,alignSelf:as,padding:p/1,paddingLeft:pl/1,paddingRight:pr/1,paddingTop:pt/1,paddingBottom:pb/1,paddingBlock:py/1/paddingY,paddingBlockEnd:pbe,paddingBlockStart:pbs,paddingInline:px/paddingX/1,paddingInlineEnd:pe/1/paddingEnd,paddingInlineStart:ps/1/paddingStart,marginLeft:ml/1,marginRight:mr/1,marginTop:mt/1,marginBottom:mb/1,margin:m/1,marginBlock:my/1/marginY,marginBlockEnd:mbe,marginBlockStart:mbs,marginInline:mx/1/marginX,marginInlineEnd:me/1/marginEnd,marginInlineStart:ms/1/marginStart,spaceX:sx,spaceY:sy,outlineWidth:ring-w/ringWidth,outlineColor:ring-c/ringColor,outline:ring/1,outlineOffset:ring-o/ringOffset,focusRing:focus-ring,focusVisibleRing:focus-v-ring,focusRingColor:focus-ring-c,focusRingOffset:focus-ring-o,focusRingWidth:focus-ring-w,focusRingStyle:focus-ring-s,divideX:dvd-x,divideY:dvd-y,divideColor:dvd-c,divideStyle:dvd-s,width:w/1,inlineSize:w-is,minWidth:min-w/minW,minInlineSize:min-w-is,maxWidth:max-w/maxW,maxInlineSize:max-w-is,height:h/1,blockSize:h-bs,minHeight:min-h/minH,minBlockSize:min-h-bs,maxHeight:max-h/maxH,maxBlockSize:max-b,boxSize:size,color:c,fontFamily:ff,fontSize:fs,fontSizeAdjust:fs-a,fontPalette:fp,fontKerning:fk,fontFeatureSettings:ff-s,fontWeight:fw,fontSmoothing:fsmt,fontVariant:fv,fontVariantAlternates:fv-alt,fontVariantCaps:fv-caps,fontVariationSettings:fv-s,fontVariantNumeric:fv-num,letterSpacing:ls,lineHeight:lh,textAlign:ta,textDecoration:td,textDecorationColor:td-c,textEmphasisColor:te-c,textDecorationStyle:td-s,textDecorationThickness:td-t,textUnderlineOffset:tu-o,textTransform:tt,textIndent:ti,textShadow:tsh,textShadowColor:tsh-c/textShadowColor,WebkitTextFillColor:wktf-c,textOverflow:tov,verticalAlign:va,wordBreak:wb,textWrap:tw,truncate:trunc,lineClamp:lc,listStyleType:li-t,listStylePosition:li-pos,listStyleImage:li-img,listStyle:li-s,backgroundPosition:bg-p/bgPosition,backgroundPositionX:bg-p-x/bgPositionX,backgroundPositionY:bg-p-y/bgPositionY,backgroundAttachment:bg-a/bgAttachment,backgroundClip:bg-cp/bgClip,background:bg/1,backgroundColor:bg-c/bgColor,backgroundOrigin:bg-o/bgOrigin,backgroundImage:bg-i/bgImage,backgroundRepeat:bg-r/bgRepeat,backgroundBlendMode:bg-bm/bgBlendMode,backgroundSize:bg-s/bgSize,backgroundGradient:bg-grad/bgGradient,backgroundLinear:bg-linear/bgLinear,backgroundRadial:bg-radial/bgRadial,backgroundConic:bg-conic/bgConic,textGradient:txt-grad,gradientFromPosition:grad-from-pos,gradientToPosition:grad-to-pos,gradientFrom:grad-from,gradientTo:grad-to,gradientVia:grad-via,gradientViaPosition:grad-via-pos,borderRadius:bdr/rounded,borderTopLeftRadius:bdr-tl/roundedTopLeft,borderTopRightRadius:bdr-tr/roundedTopRight,borderBottomRightRadius:bdr-br/roundedBottomRight,borderBottomLeftRadius:bdr-bl/roundedBottomLeft,borderTopRadius:bdr-t/roundedTop,borderRightRadius:bdr-r/roundedRight,borderBottomRadius:bdr-b/roundedBottom,borderLeftRadius:bdr-l/roundedLeft,borderStartStartRadius:bdr-ss/roundedStartStart,borderStartEndRadius:bdr-se/roundedStartEnd,borderStartRadius:bdr-s/roundedStart,borderEndStartRadius:bdr-es/roundedEndStart,borderEndEndRadius:bdr-ee/roundedEndEnd,borderEndRadius:bdr-e/roundedEnd,border:bd,borderWidth:bd-w,borderTopWidth:bd-t-w,borderLeftWidth:bd-l-w,borderRightWidth:bd-r-w,borderBottomWidth:bd-b-w,borderBlockStartWidth:bd-bs-w,borderBlockEndWidth:bd-be-w,borderColor:bd-c,borderInline:bd-x/borderX,borderInlineWidth:bd-x-w/borderXWidth,borderInlineColor:bd-x-c/borderXColor,borderBlock:bd-y/borderY,borderBlockWidth:bd-y-w/borderYWidth,borderBlockColor:bd-y-c/borderYColor,borderLeft:bd-l,borderLeftColor:bd-l-c,borderInlineStart:bd-s/borderStart,borderInlineStartWidth:bd-s-w/borderStartWidth,borderInlineStartColor:bd-s-c/borderStartColor,borderRight:bd-r,borderRightColor:bd-r-c,borderInlineEnd:bd-e/borderEnd,borderInlineEndWidth:bd-e-w/borderEndWidth,borderInlineEndColor:bd-e-c/borderEndColor,borderTop:bd-t,borderTopColor:bd-t-c,borderBottom:bd-b,borderBottomColor:bd-b-c,borderBlockEnd:bd-be,borderBlockEndColor:bd-be-c,borderBlockStart:bd-bs,borderBlockStartColor:bd-bs-c,opacity:op,boxShadow:bx-sh/shadow,boxShadowColor:bx-sh-c/shadowColor,mixBlendMode:mix-bm,filter:filter,brightness:brightness,contrast:contrast,grayscale:grayscale,hueRotate:hue-rotate,invert:invert,saturate:saturate,sepia:sepia,dropShadow:drop-shadow,blur:blur,backdropFilter:bkdp,backdropBlur:bkdp-blur,backdropBrightness:bkdp-brightness,backdropContrast:bkdp-contrast,backdropGrayscale:bkdp-grayscale,backdropHueRotate:bkdp-hue-rotate,backdropInvert:bkdp-invert,backdropOpacity:bkdp-opacity,backdropSaturate:bkdp-saturate,backdropSepia:bkdp-sepia,borderCollapse:bd-cl,borderSpacing:bd-sp,borderSpacingX:bd-sx,borderSpacingY:bd-sy,tableLayout:tbl,transitionTimingFunction:trs-tmf,transitionDelay:trs-dly,transitionDuration:trs-dur,transitionProperty:trs-prop,transition:transition,animation:anim,animationName:anim-n,animationTimingFunction:anim-tmf,animationDuration:anim-dur,animationDelay:anim-dly,animationPlayState:anim-ps,animationComposition:anim-comp,animationFillMode:anim-fm,animationDirection:anim-dir,animationIterationCount:anim-ic,animationRange:anim-r,animationState:anim-s,animationRangeStart:anim-rs,animationRangeEnd:anim-re,animationTimeline:anim-tl,transformOrigin:trf-o,transformBox:trf-b,transformStyle:trf-s,transform:trf,rotate:rotate,rotateX:rotate-x,rotateY:rotate-y,rotateZ:rotate-z,scale:scale,scaleX:scale-x,scaleY:scale-y,translate:translate,translateX:translate-x/x,translateY:translate-y/y,translateZ:translate-z/z,accentColor:ac-c,caretColor:ca-c,scrollBehavior:scr-bhv,scrollbar:scr-bar,scrollbarColor:scr-bar-c,scrollbarGutter:scr-bar-g,scrollbarWidth:scr-bar-w,scrollMargin:scr-m,scrollMarginLeft:scr-ml,scrollMarginRight:scr-mr,scrollMarginTop:scr-mt,scrollMarginBottom:scr-mb,scrollMarginBlock:scr-my/scrollMarginY,scrollMarginBlockEnd:scr-mbe,scrollMarginBlockStart:scr-mbt,scrollMarginInline:scr-mx/scrollMarginX,scrollMarginInlineEnd:scr-me,scrollMarginInlineStart:scr-ms,scrollPadding:scr-p,scrollPaddingBlock:scr-py/scrollPaddingY,scrollPaddingBlockStart:scr-pbs,scrollPaddingBlockEnd:scr-pbe,scrollPaddingInline:scr-px/scrollPaddingX,scrollPaddingInlineEnd:scr-pe,scrollPaddingInlineStart:scr-ps,scrollPaddingLeft:scr-pl,scrollPaddingRight:scr-pr,scrollPaddingTop:scr-pt,scrollPaddingBottom:scr-pb,scrollSnapAlign:scr-sa,scrollSnapStop:scrs-s,scrollSnapType:scrs-t,scrollSnapStrictness:scrs-strt,scrollSnapMargin:scrs-m,scrollSnapMarginTop:scrs-mt,scrollSnapMarginBottom:scrs-mb,scrollSnapMarginLeft:scrs-ml,scrollSnapMarginRight:scrs-mr,scrollSnapCoordinate:scrs-c,scrollSnapDestination:scrs-d,scrollSnapPointsX:scrs-px,scrollSnapPointsY:scrs-py,scrollSnapTypeX:scrs-tx,scrollSnapTypeY:scrs-ty,scrollTimeline:scrtl,scrollTimelineAxis:scrtl-a,scrollTimelineName:scrtl-n,touchAction:tch-a,userSelect:us,overflow:ov,overflowWrap:ov-wrap,overflowX:ov-x,overflowY:ov-y,overflowAnchor:ov-a,overflowBlock:ov-b,overflowInline:ov-i,overflowClipBox:ovcp-bx,overflowClipMargin:ovcp-m,overscrollBehaviorBlock:ovs-bb,overscrollBehaviorInline:ovs-bi,fill:fill,stroke:stk,strokeWidth:stk-w,strokeDasharray:stk-dsh,strokeDashoffset:stk-do,strokeLinecap:stk-lc,strokeLinejoin:stk-lj,strokeMiterlimit:stk-ml,strokeOpacity:stk-op,srOnly:sr,debug:debug,appearance:ap,backfaceVisibility:bfv,clipPath:cp-path,hyphens:hy,mask:msk,maskImage:msk-i,maskSize:msk-s,textSizeAdjust:txt-adj,container:cq,containerName:cq-n,containerType:cq-t,cursor:cursor,textStyle:textStyle,layerStyle:layerStyle,animationStyle:animationStyle";
var classNameByProp = /* @__PURE__ */ new Map();
var shorthands = /* @__PURE__ */ new Map();
utilities.split(",").forEach((utility) => {
	const [prop, meta] = utility.split(":");
	const [className, ...shorthandList] = meta.split("/");
	classNameByProp.set(prop, className);
	if (shorthandList.length) shorthandList.forEach((shorthand) => {
		shorthands.set(shorthand === "1" ? className : shorthand, prop);
	});
});
var resolveShorthand = (prop) => shorthands.get(prop) || prop;
var context = {
	conditions: {
		shift: sortConditions,
		finalize: finalizeConditions,
		breakpoints: { keys: [
			"base",
			"xs",
			"sm",
			"md",
			"lg",
			"xl"
		] }
	},
	utility: {
		transform: (prop, value) => {
			const key = resolveShorthand(prop);
			return { className: `${classNameByProp.get(key) || hypenateProperty(key)}_${withoutSpace(value)}` };
		},
		hasShorthand: true,
		toHash: (path, hashFn) => hashFn(path.join(":")),
		resolveShorthand
	}
};
var cssFn = createCss(context);
var css = (...styles) => cssFn(mergeCss(...styles));
css.raw = (...styles) => mergeCss(...styles);
var { mergeCss, assignCss } = createMergeCss(context);
//#endregion
//#region styled-system/css/cx.mjs
function cx() {
	let str = "";
	let i = 0;
	let arg;
	for (; i < arguments.length;) if ((arg = arguments[i++]) && typeof arg === "string") {
		str && (str += " ");
		str += arg;
	}
	return str;
}
//#endregion
//#region styled-system/css/cva.mjs
var defaults = (conf) => ({
	base: {},
	variants: {},
	defaultVariants: {},
	compoundVariants: [],
	...conf
});
function cva(config) {
	const { base, variants, defaultVariants, compoundVariants } = defaults(config);
	const getVariantProps = (variants) => ({
		...defaultVariants,
		...compact(variants)
	});
	function resolve(props = {}) {
		const computedVariants = getVariantProps(props);
		let variantCss = { ...base };
		for (const [key, value] of Object.entries(computedVariants)) if (variants[key]?.[value]) variantCss = mergeCss(variantCss, variants[key][value]);
		const compoundVariantCss = getCompoundVariantCss(compoundVariants, computedVariants);
		return mergeCss(variantCss, compoundVariantCss);
	}
	function merge(__cva) {
		const override = defaults(__cva.config);
		const variantKeys = uniq(__cva.variantKeys, Object.keys(variants));
		return cva({
			base: mergeCss(base, override.base),
			variants: Object.fromEntries(variantKeys.map((key) => [key, mergeCss(variants[key], override.variants[key])])),
			defaultVariants: mergeProps(defaultVariants, override.defaultVariants),
			compoundVariants: [...compoundVariants, ...override.compoundVariants]
		});
	}
	function cvaFn(props) {
		return css(resolve(props));
	}
	const variantKeys = Object.keys(variants);
	function splitVariantProps(props) {
		return splitProps(props, variantKeys);
	}
	const variantMap = Object.fromEntries(Object.entries(variants).map(([key, value]) => [key, Object.keys(value)]));
	return Object.assign(memo$1(cvaFn), {
		__cva__: true,
		variantMap,
		variantKeys,
		raw: resolve,
		config,
		merge,
		splitVariantProps,
		getVariantProps
	});
}
function getCompoundVariantCss(compoundVariants, variantMap) {
	let result = {};
	compoundVariants.forEach((compoundVariant) => {
		if (Object.entries(compoundVariant).every(([key, value]) => {
			if (key === "css") return true;
			return (Array.isArray(value) ? value : [value]).some((value) => variantMap[key] === value);
		})) result = mergeCss(result, compoundVariant.css);
	});
	return result;
}
function assertCompoundVariant(name, compoundVariants, variants, prop) {
	if (compoundVariants.length > 0 && typeof variants?.[prop] === "object") throw new Error(`[recipe:${name}:${prop}] Conditions are not supported when using compound variants.`);
}
//#endregion
//#region styled-system/css/sva.mjs
function sva(config) {
	const slots = Object.entries(getSlotRecipes(config)).map(([slot, slotCva]) => [slot, cva(slotCva)]);
	const defaultVariants = config.defaultVariants ?? {};
	const classNameMap = slots.reduce((acc, [slot, cvaFn]) => {
		if (config.className) acc[slot] = cvaFn.config.className;
		return acc;
	}, {});
	function svaFn(props) {
		const result = slots.map(([slot, cvaFn]) => [slot, cx(cvaFn(props), classNameMap[slot])]);
		return Object.fromEntries(result);
	}
	function raw(props) {
		const result = slots.map(([slot, cvaFn]) => [slot, cvaFn.raw(props)]);
		return Object.fromEntries(result);
	}
	const variants = config.variants ?? {};
	const variantKeys = Object.keys(variants);
	function splitVariantProps(props) {
		return splitProps(props, variantKeys);
	}
	const getVariantProps = (variants) => ({
		...defaultVariants,
		...compact(variants)
	});
	const variantMap = Object.fromEntries(Object.entries(variants).map(([key, value]) => [key, Object.keys(value)]));
	return Object.assign(memo$1(svaFn), {
		__cva__: false,
		raw,
		config,
		variantMap,
		variantKeys,
		classNameMap,
		splitVariantProps,
		getVariantProps
	});
}
//#endregion
//#region styled-system/tokens/index.mjs
var tokens = {
	"fontSizes.xxs": {
		"value": "10px",
		"variable": "var(--font-sizes-xxs)"
	},
	"fontSizes.xs": {
		"value": "12px",
		"variable": "var(--font-sizes-xs)"
	},
	"fontSizes.sm": {
		"value": "13px",
		"variable": "var(--font-sizes-sm)"
	},
	"fontSizes.md": {
		"value": "14px",
		"variable": "var(--font-sizes-md)"
	},
	"fontSizes.lg": {
		"value": "16px",
		"variable": "var(--font-sizes-lg)"
	},
	"fontSizes.xl": {
		"value": "18px",
		"variable": "var(--font-sizes-xl)"
	},
	"fontSizes.likec4.xs": {
		"value": "13.33px",
		"variable": "var(--font-sizes-likec4-xs)"
	},
	"fontSizes.likec4.sm": {
		"value": "16px",
		"variable": "var(--font-sizes-likec4-sm)"
	},
	"fontSizes.likec4.md": {
		"value": "19.2px",
		"variable": "var(--font-sizes-likec4-md)"
	},
	"fontSizes.likec4.lg": {
		"value": "23.04px",
		"variable": "var(--font-sizes-likec4-lg)"
	},
	"fontSizes.likec4.xl": {
		"value": "27.65px",
		"variable": "var(--font-sizes-likec4-xl)"
	},
	"fontSizes.h1": {
		"value": "2.125rem",
		"variable": "var(--font-sizes-h1)"
	},
	"fontSizes.h2": {
		"value": "1.625rem",
		"variable": "var(--font-sizes-h2)"
	},
	"fontSizes.h3": {
		"value": "1.375rem",
		"variable": "var(--font-sizes-h3)"
	},
	"fontSizes.h4": {
		"value": "1.125rem",
		"variable": "var(--font-sizes-h4)"
	},
	"fontSizes.h5": {
		"value": "1rem",
		"variable": "var(--font-sizes-h5)"
	},
	"fontSizes.h6": {
		"value": "0.875rem",
		"variable": "var(--font-sizes-h6)"
	},
	"fontWeights.normal": {
		"value": "400",
		"variable": "var(--font-weights-normal)"
	},
	"fontWeights.medium": {
		"value": "500",
		"variable": "var(--font-weights-medium)"
	},
	"fontWeights.semibold": {
		"value": "600",
		"variable": "var(--font-weights-semibold)"
	},
	"fontWeights.bold": {
		"value": "600",
		"variable": "var(--font-weights-bold)"
	},
	"fontWeights.extrabold": {
		"value": "700",
		"variable": "var(--font-weights-extrabold)"
	},
	"fontWeights.display": {
		"value": "700",
		"variable": "var(--font-weights-display)"
	},
	"lineHeights.1": {
		"value": "1",
		"variable": "var(--line-heights-1)"
	},
	"lineHeights.tight": {
		"value": "1.05",
		"variable": "var(--line-heights-tight)"
	},
	"lineHeights.snug": {
		"value": "1.1",
		"variable": "var(--line-heights-snug)"
	},
	"lineHeights.xs": {
		"value": "1.2",
		"variable": "var(--line-heights-xs)"
	},
	"lineHeights.sm": {
		"value": "1.35",
		"variable": "var(--line-heights-sm)"
	},
	"lineHeights.md": {
		"value": "1.45",
		"variable": "var(--line-heights-md)"
	},
	"lineHeights.lg": {
		"value": "1.5",
		"variable": "var(--line-heights-lg)"
	},
	"lineHeights.xl": {
		"value": "1.5",
		"variable": "var(--line-heights-xl)"
	},
	"fonts.display": {
		"value": "'IBM Plex Sans Variable',ui-sans-serif,system-ui,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\",\"Segoe UI Symbol\",\"Noto Color Emoji\"",
		"variable": "var(--fonts-display)"
	},
	"fonts.mono": {
		"value": "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace",
		"variable": "var(--fonts-mono)"
	},
	"fonts.body": {
		"value": "'IBM Plex Sans Variable',ui-sans-serif,system-ui,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\",\"Segoe UI Symbol\",\"Noto Color Emoji\"",
		"variable": "var(--fonts-body)"
	},
	"fonts.likec4": {
		"value": "var(--likec4-app-font, var(--likec4-app-font-default, var(--fonts-body)))",
		"variable": "var(--fonts-likec4)"
	},
	"fonts.likec4.element": {
		"value": "var(--likec4-element-font, var(--fonts-likec4))",
		"variable": "var(--fonts-likec4-element)"
	},
	"fonts.likec4.compound": {
		"value": "var(--likec4-compound-font, var(--fonts-likec4))",
		"variable": "var(--fonts-likec4-compound)"
	},
	"fonts.likec4.relation": {
		"value": "var(--likec4-relation-font, var(--fonts-likec4))",
		"variable": "var(--fonts-likec4-relation)"
	},
	"letterSpacings.display": {
		"value": "-0.02em",
		"variable": "var(--letter-spacings-display)"
	},
	"letterSpacings.tight": {
		"value": "-0.025em",
		"variable": "var(--letter-spacings-tight)"
	},
	"letterSpacings.normal": {
		"value": "0em",
		"variable": "var(--letter-spacings-normal)"
	},
	"letterSpacings.caps": {
		"value": "0.12em",
		"variable": "var(--letter-spacings-caps)"
	},
	"letterSpacings.caps.sm": {
		"value": "0.06em",
		"variable": "var(--letter-spacings-caps-sm)"
	},
	"sizes.0": {
		"value": "0",
		"variable": "var(--sizes-0)"
	},
	"sizes.auto": {
		"value": "auto",
		"variable": "var(--sizes-auto)"
	},
	"sizes.max-content": {
		"value": "max-content",
		"variable": "var(--sizes-max-content)"
	},
	"sizes.min-content": {
		"value": "min-content",
		"variable": "var(--sizes-min-content)"
	},
	"sizes.fit-content": {
		"value": "fit-content",
		"variable": "var(--sizes-fit-content)"
	},
	"sizes.stretch": {
		"value": "stretch",
		"variable": "var(--sizes-stretch)"
	},
	"sizes.100cqw": {
		"value": "100cqw",
		"variable": "var(--sizes-100cqw)"
	},
	"sizes.100cqh": {
		"value": "100cqh",
		"variable": "var(--sizes-100cqh)"
	},
	"sizes.100vw": {
		"value": "100vw",
		"variable": "var(--sizes-100vw)"
	},
	"sizes.100vh": {
		"value": "100vh",
		"variable": "var(--sizes-100vh)"
	},
	"sizes.100%": {
		"value": "100%",
		"variable": "var(--sizes-100\\%)"
	},
	"sizes.50%": {
		"value": "50%",
		"variable": "var(--sizes-50\\%)"
	},
	"sizes.full": {
		"value": "100%",
		"variable": "var(--sizes-full)"
	},
	"sizes.control.sm": {
		"value": "30px",
		"variable": "var(--sizes-control-sm)"
	},
	"sizes.control.md": {
		"value": "36px",
		"variable": "var(--sizes-control-md)"
	},
	"sizes.control.lg": {
		"value": "42px",
		"variable": "var(--sizes-control-lg)"
	},
	"sizes.action-icon": {
		"value": "28px",
		"variable": "var(--sizes-action-icon)"
	},
	"sizes.icon": {
		"value": "16px",
		"variable": "var(--sizes-icon)"
	},
	"sizes.icon.xxs": {
		"value": "10px",
		"variable": "var(--sizes-icon-xxs)"
	},
	"sizes.icon.xs": {
		"value": "12px",
		"variable": "var(--sizes-icon-xs)"
	},
	"sizes.icon.sm": {
		"value": "14px",
		"variable": "var(--sizes-icon-sm)"
	},
	"sizes.icon.md": {
		"value": "16px",
		"variable": "var(--sizes-icon-md)"
	},
	"sizes.icon.lg": {
		"value": "18px",
		"variable": "var(--sizes-icon-lg)"
	},
	"sizes.icon.xl": {
		"value": "22px",
		"variable": "var(--sizes-icon-xl)"
	},
	"sizes.breakpoint-xs": {
		"value": "36em",
		"variable": "var(--sizes-breakpoint-xs)"
	},
	"sizes.breakpoint-sm": {
		"value": "48em",
		"variable": "var(--sizes-breakpoint-sm)"
	},
	"sizes.breakpoint-md": {
		"value": "62em",
		"variable": "var(--sizes-breakpoint-md)"
	},
	"sizes.breakpoint-lg": {
		"value": "75em",
		"variable": "var(--sizes-breakpoint-lg)"
	},
	"sizes.breakpoint-xl": {
		"value": "88em",
		"variable": "var(--sizes-breakpoint-xl)"
	},
	"borders.none": {
		"value": "none",
		"variable": "var(--borders-none)"
	},
	"borders.transparent": {
		"value": "0px solid transparent",
		"variable": "var(--borders-transparent)"
	},
	"borders.subtle": {
		"value": "var(--border-widths-default) solid var(--colors-border-subtle)",
		"variable": "var(--borders-subtle)"
	},
	"borders.default": {
		"value": "var(--border-widths-default) solid var(--colors-border-default)",
		"variable": "var(--borders-default)"
	},
	"borders.strong": {
		"value": "var(--border-widths-strong) solid var(--colors-border-strong)",
		"variable": "var(--borders-strong)"
	},
	"borders.outline": {
		"value": "var(--border-widths-strong) solid var(--colors-border-outline)",
		"variable": "var(--borders-outline)"
	},
	"borders.panel": {
		"value": "var(--border-widths-default) solid var(--colors-likec4-panel-border)",
		"variable": "var(--borders-panel)"
	},
	"borderWidths.0": {
		"value": "0px",
		"variable": "var(--border-widths-0)"
	},
	"borderWidths.1": {
		"value": "1px",
		"variable": "var(--border-widths-1)"
	},
	"borderWidths.2": {
		"value": "2px",
		"variable": "var(--border-widths-2)"
	},
	"borderWidths.3": {
		"value": "3px",
		"variable": "var(--border-widths-3)"
	},
	"borderWidths.4": {
		"value": "4px",
		"variable": "var(--border-widths-4)"
	},
	"borderWidths.default": {
		"value": "1px",
		"variable": "var(--border-widths-default)"
	},
	"borderWidths.strong": {
		"value": "2px",
		"variable": "var(--border-widths-strong)"
	},
	"borderWidths.extra": {
		"value": "3px",
		"variable": "var(--border-widths-extra)"
	},
	"spacing.0": {
		"value": "0px",
		"variable": "var(--spacing-0)"
	},
	"spacing.1": {
		"value": "4px",
		"variable": "var(--spacing-1)"
	},
	"spacing.2": {
		"value": "8px",
		"variable": "var(--spacing-2)"
	},
	"spacing.3": {
		"value": "12px",
		"variable": "var(--spacing-3)"
	},
	"spacing.4": {
		"value": "16px",
		"variable": "var(--spacing-4)"
	},
	"spacing.5": {
		"value": "20px",
		"variable": "var(--spacing-5)"
	},
	"spacing.6": {
		"value": "24px",
		"variable": "var(--spacing-6)"
	},
	"spacing.7": {
		"value": "28px",
		"variable": "var(--spacing-7)"
	},
	"spacing.8": {
		"value": "32px",
		"variable": "var(--spacing-8)"
	},
	"spacing.9": {
		"value": "36px",
		"variable": "var(--spacing-9)"
	},
	"spacing.10": {
		"value": "40px",
		"variable": "var(--spacing-10)"
	},
	"spacing.12": {
		"value": "48px",
		"variable": "var(--spacing-12)"
	},
	"spacing.16": {
		"value": "64px",
		"variable": "var(--spacing-16)"
	},
	"spacing.0.5": {
		"value": "2px",
		"variable": "var(--spacing-0\\.5)"
	},
	"spacing.1.5": {
		"value": "6px",
		"variable": "var(--spacing-1\\.5)"
	},
	"spacing.2.5": {
		"value": "10px",
		"variable": "var(--spacing-2\\.5)"
	},
	"spacing.3.5": {
		"value": "14px",
		"variable": "var(--spacing-3\\.5)"
	},
	"spacing.4.5": {
		"value": "18px",
		"variable": "var(--spacing-4\\.5)"
	},
	"spacing.xxs": {
		"value": "calc(8px * var(--mantine-scale))",
		"variable": "var(--spacing-xxs)"
	},
	"spacing.xs": {
		"value": "calc(10px * var(--mantine-scale))",
		"variable": "var(--spacing-xs)"
	},
	"spacing.sm": {
		"value": "calc(12px * var(--mantine-scale))",
		"variable": "var(--spacing-sm)"
	},
	"spacing.md": {
		"value": "calc(16px * var(--mantine-scale))",
		"variable": "var(--spacing-md)"
	},
	"spacing.lg": {
		"value": "calc(20px * var(--mantine-scale))",
		"variable": "var(--spacing-lg)"
	},
	"spacing.xl": {
		"value": "calc(32px * var(--mantine-scale))",
		"variable": "var(--spacing-xl)"
	},
	"spacing.likec4.xs": {
		"value": "8px",
		"variable": "var(--spacing-likec4-xs)"
	},
	"spacing.likec4.sm": {
		"value": "10px",
		"variable": "var(--spacing-likec4-sm)"
	},
	"spacing.likec4.md": {
		"value": "16px",
		"variable": "var(--spacing-likec4-md)"
	},
	"spacing.likec4.lg": {
		"value": "24px",
		"variable": "var(--spacing-likec4-lg)"
	},
	"spacing.likec4.xl": {
		"value": "32px",
		"variable": "var(--spacing-likec4-xl)"
	},
	"radii.0": {
		"value": "0px",
		"variable": "var(--radii-0)"
	},
	"radii.xs": {
		"value": "2px",
		"variable": "var(--radii-xs)"
	},
	"radii.sm": {
		"value": "4px",
		"variable": "var(--radii-sm)"
	},
	"radii.md": {
		"value": "8px",
		"variable": "var(--radii-md)"
	},
	"radii.lg": {
		"value": "16px",
		"variable": "var(--radii-lg)"
	},
	"radii.xl": {
		"value": "24px",
		"variable": "var(--radii-xl)"
	},
	"radii.pill": {
		"value": "999px",
		"variable": "var(--radii-pill)"
	},
	"colors.mantine.gray[0]": {
		"value": "#f8f9fa",
		"variable": "var(--colors-mantine-gray\\[0\\])"
	},
	"colors.mantine.gray[1]": {
		"value": "#f1f3f5",
		"variable": "var(--colors-mantine-gray\\[1\\])"
	},
	"colors.mantine.gray[2]": {
		"value": "#e9ecef",
		"variable": "var(--colors-mantine-gray\\[2\\])"
	},
	"colors.mantine.gray[3]": {
		"value": "#dee2e6",
		"variable": "var(--colors-mantine-gray\\[3\\])"
	},
	"colors.mantine.gray[4]": {
		"value": "#ced4da",
		"variable": "var(--colors-mantine-gray\\[4\\])"
	},
	"colors.mantine.gray[5]": {
		"value": "#adb5bd",
		"variable": "var(--colors-mantine-gray\\[5\\])"
	},
	"colors.mantine.gray[6]": {
		"value": "#868e96",
		"variable": "var(--colors-mantine-gray\\[6\\])"
	},
	"colors.mantine.gray[7]": {
		"value": "#495057",
		"variable": "var(--colors-mantine-gray\\[7\\])"
	},
	"colors.mantine.gray[8]": {
		"value": "#343a40",
		"variable": "var(--colors-mantine-gray\\[8\\])"
	},
	"colors.mantine.gray[9]": {
		"value": "#212529",
		"variable": "var(--colors-mantine-gray\\[9\\])"
	},
	"colors.mantine.dark[0]": {
		"value": "#C9C9C9",
		"variable": "var(--colors-mantine-dark\\[0\\])"
	},
	"colors.mantine.dark[1]": {
		"value": "#b8b8b8",
		"variable": "var(--colors-mantine-dark\\[1\\])"
	},
	"colors.mantine.dark[2]": {
		"value": "#828282",
		"variable": "var(--colors-mantine-dark\\[2\\])"
	},
	"colors.mantine.dark[3]": {
		"value": "#696969",
		"variable": "var(--colors-mantine-dark\\[3\\])"
	},
	"colors.mantine.dark[4]": {
		"value": "#424242",
		"variable": "var(--colors-mantine-dark\\[4\\])"
	},
	"colors.mantine.dark[5]": {
		"value": "#3b3b3b",
		"variable": "var(--colors-mantine-dark\\[5\\])"
	},
	"colors.mantine.dark[6]": {
		"value": "#2e2e2e",
		"variable": "var(--colors-mantine-dark\\[6\\])"
	},
	"colors.mantine.dark[7]": {
		"value": "#242424",
		"variable": "var(--colors-mantine-dark\\[7\\])"
	},
	"colors.mantine.dark[8]": {
		"value": "#1f1f1f",
		"variable": "var(--colors-mantine-dark\\[8\\])"
	},
	"colors.mantine.dark[9]": {
		"value": "#141414",
		"variable": "var(--colors-mantine-dark\\[9\\])"
	},
	"colors.mantine.orange[0]": {
		"value": "#fff4e6",
		"variable": "var(--colors-mantine-orange\\[0\\])"
	},
	"colors.mantine.orange[1]": {
		"value": "#ffe8cc",
		"variable": "var(--colors-mantine-orange\\[1\\])"
	},
	"colors.mantine.orange[2]": {
		"value": "#ffd8a8",
		"variable": "var(--colors-mantine-orange\\[2\\])"
	},
	"colors.mantine.orange[3]": {
		"value": "#ffc078",
		"variable": "var(--colors-mantine-orange\\[3\\])"
	},
	"colors.mantine.orange[4]": {
		"value": "#ffa94d",
		"variable": "var(--colors-mantine-orange\\[4\\])"
	},
	"colors.mantine.orange[5]": {
		"value": "#ff922b",
		"variable": "var(--colors-mantine-orange\\[5\\])"
	},
	"colors.mantine.orange[6]": {
		"value": "#fd7e14",
		"variable": "var(--colors-mantine-orange\\[6\\])"
	},
	"colors.mantine.orange[7]": {
		"value": "#f76707",
		"variable": "var(--colors-mantine-orange\\[7\\])"
	},
	"colors.mantine.orange[8]": {
		"value": "#e8590c",
		"variable": "var(--colors-mantine-orange\\[8\\])"
	},
	"colors.mantine.orange[9]": {
		"value": "#d9480f",
		"variable": "var(--colors-mantine-orange\\[9\\])"
	},
	"colors.mantine.yellow[0]": {
		"value": "#fff9db",
		"variable": "var(--colors-mantine-yellow\\[0\\])"
	},
	"colors.mantine.yellow[1]": {
		"value": "#fff3bf",
		"variable": "var(--colors-mantine-yellow\\[1\\])"
	},
	"colors.mantine.yellow[2]": {
		"value": "#ffec99",
		"variable": "var(--colors-mantine-yellow\\[2\\])"
	},
	"colors.mantine.yellow[3]": {
		"value": "#ffe066",
		"variable": "var(--colors-mantine-yellow\\[3\\])"
	},
	"colors.mantine.yellow[4]": {
		"value": "#ffd43b",
		"variable": "var(--colors-mantine-yellow\\[4\\])"
	},
	"colors.mantine.yellow[5]": {
		"value": "#fcc419",
		"variable": "var(--colors-mantine-yellow\\[5\\])"
	},
	"colors.mantine.yellow[6]": {
		"value": "#fab005",
		"variable": "var(--colors-mantine-yellow\\[6\\])"
	},
	"colors.mantine.yellow[7]": {
		"value": "#f59f00",
		"variable": "var(--colors-mantine-yellow\\[7\\])"
	},
	"colors.mantine.yellow[8]": {
		"value": "#f08c00",
		"variable": "var(--colors-mantine-yellow\\[8\\])"
	},
	"colors.mantine.yellow[9]": {
		"value": "#e67700",
		"variable": "var(--colors-mantine-yellow\\[9\\])"
	},
	"colors.transparent": {
		"value": "transparent",
		"variable": "var(--colors-transparent)"
	},
	"colors.none": {
		"value": "none",
		"variable": "var(--colors-none)"
	},
	"colors.inherit": {
		"value": "inherit",
		"variable": "var(--colors-inherit)"
	},
	"colors.current": {
		"value": "current",
		"variable": "var(--colors-current)"
	},
	"colors.currentColor": {
		"value": "currentColor",
		"variable": "var(--colors-current-color)"
	},
	"colors.white": {
		"value": "#fff",
		"variable": "var(--colors-white)"
	},
	"colors.black": {
		"value": "#000",
		"variable": "var(--colors-black)"
	},
	"colors.likec4.accent.0": {
		"value": "#eff7fa",
		"variable": "var(--colors-likec4-accent-0)"
	},
	"colors.likec4.accent.1": {
		"value": "#ddedf4",
		"variable": "var(--colors-likec4-accent-1)"
	},
	"colors.likec4.accent.2": {
		"value": "#bcdae6",
		"variable": "var(--colors-likec4-accent-2)"
	},
	"colors.likec4.accent.3": {
		"value": "#97c2d3",
		"variable": "var(--colors-likec4-accent-3)"
	},
	"colors.likec4.accent.4": {
		"value": "#5e98af",
		"variable": "var(--colors-likec4-accent-4)"
	},
	"colors.likec4.accent.5": {
		"value": "#4587a1",
		"variable": "var(--colors-likec4-accent-5)"
	},
	"colors.likec4.accent.6": {
		"value": "#34748d",
		"variable": "var(--colors-likec4-accent-6)"
	},
	"colors.likec4.accent.7": {
		"value": "#2a637a",
		"variable": "var(--colors-likec4-accent-7)"
	},
	"colors.likec4.accent.8": {
		"value": "#205165",
		"variable": "var(--colors-likec4-accent-8)"
	},
	"colors.likec4.accent.9": {
		"value": "#184253",
		"variable": "var(--colors-likec4-accent-9)"
	},
	"colors.likec4.accent": {
		"value": "#34748d",
		"variable": "var(--colors-likec4-accent)"
	},
	"easings.default": {
		"value": "cubic-bezier(0.4, 0, 0.2, 1)",
		"variable": "var(--easings-default)"
	},
	"easings.in": {
		"value": "cubic-bezier(0.4, 0, 1, 1)",
		"variable": "var(--easings-in)"
	},
	"easings.out": {
		"value": "cubic-bezier(0.2, 0.8, 0.2, 1)",
		"variable": "var(--easings-out)"
	},
	"easings.inOut": {
		"value": "cubic-bezier(0.50, 0, 0.2, 1)",
		"variable": "var(--easings-in-out)"
	},
	"durations.0": {
		"value": "0s",
		"variable": "var(--durations-0)"
	},
	"durations.fastest": {
		"value": "80ms",
		"variable": "var(--durations-fastest)"
	},
	"durations.fast": {
		"value": "120ms",
		"variable": "var(--durations-fast)"
	},
	"durations.medium": {
		"value": "170ms",
		"variable": "var(--durations-medium)"
	},
	"durations.slow": {
		"value": "240ms",
		"variable": "var(--durations-slow)"
	},
	"durations.slowest": {
		"value": "500ms",
		"variable": "var(--durations-slowest)"
	},
	"shadows.none": {
		"value": "none",
		"variable": "var(--shadows-none)"
	},
	"shadows.xs": {
		"value": "0 1px 3px rgb(0 0 0/5%), 0 1px 2px rgb(0 0 0/10%)",
		"variable": "var(--shadows-xs)"
	},
	"shadows.sm": {
		"value": "0 1px 3px rgb(0 0 0/5%), 0 10px 15px -5px rgb(0 0 0/5%), 0 7px 7px -5px rgb(0 0 0/4%)",
		"variable": "var(--shadows-sm)"
	},
	"shadows.md": {
		"value": "0 1px 3px rgb(0 0 0/5%), 0 20px 25px -5px rgb(0 0 0/5%), 0 10px 10px -5px rgb(0 0 0/4%)",
		"variable": "var(--shadows-md)"
	},
	"shadows.lg": {
		"value": "0 1px 3px rgb(0 0 0/5%), 0 28px 23px -7px rgb(0 0 0/5%), 0 12px 12px -7px rgb(0 0 0/4%)",
		"variable": "var(--shadows-lg)"
	},
	"shadows.xl": {
		"value": "0 1px 3px rgb(0 0 0/5%), 0 36px 28px -7px rgb(0 0 0/5%), 0 17px 17px -7px rgb(0 0 0/4%)",
		"variable": "var(--shadows-xl)"
	},
	"zIndex.0": {
		"value": 0,
		"variable": "var(--z-index-0)"
	},
	"zIndex.-1": {
		"value": -1,
		"variable": "var(--z-index--1)"
	},
	"zIndex.base": {
		"value": 0,
		"variable": "var(--z-index-base)"
	},
	"zIndex.sticky": {
		"value": 100,
		"variable": "var(--z-index-sticky)"
	},
	"zIndex.floating": {
		"value": 150,
		"variable": "var(--z-index-floating)"
	},
	"zIndex.panel": {
		"value": 200,
		"variable": "var(--z-index-panel)"
	},
	"zIndex.dropdown": {
		"value": 1e3,
		"variable": "var(--z-index-dropdown)"
	},
	"zIndex.overlay": {
		"value": 2e3,
		"variable": "var(--z-index-overlay)"
	},
	"zIndex.tooltip": {
		"value": 3e3,
		"variable": "var(--z-index-tooltip)"
	},
	"zIndex.toast": {
		"value": 4e3,
		"variable": "var(--z-index-toast)"
	},
	"zIndex.diagram.edge": {
		"value": 20,
		"variable": "var(--z-index-diagram-edge)"
	},
	"zIndex.diagram.edge.label": {
		"value": 25,
		"variable": "var(--z-index-diagram-edge-label)"
	},
	"zIndex.diagram.edge.controlPoint": {
		"value": 30,
		"variable": "var(--z-index-diagram-edge-control-point)"
	},
	"zIndex.diagram.node.compound": {
		"value": 10,
		"variable": "var(--z-index-diagram-node-compound)"
	},
	"zIndex.diagram.node.element": {
		"value": 40,
		"variable": "var(--z-index-diagram-node-element)"
	},
	"opacity.0": {
		"value": 0,
		"variable": "var(--opacity-0)"
	},
	"opacity.1": {
		"value": 1,
		"variable": "var(--opacity-1)"
	},
	"opacity.0.05": {
		"value": .05,
		"variable": "var(--opacity-0\\.05)"
	},
	"opacity.0.1": {
		"value": .1,
		"variable": "var(--opacity-0\\.1)"
	},
	"opacity.0.15": {
		"value": .15,
		"variable": "var(--opacity-0\\.15)"
	},
	"opacity.0.2": {
		"value": .2,
		"variable": "var(--opacity-0\\.2)"
	},
	"opacity.0.25": {
		"value": .25,
		"variable": "var(--opacity-0\\.25)"
	},
	"opacity.0.3": {
		"value": .3,
		"variable": "var(--opacity-0\\.3)"
	},
	"opacity.0.35": {
		"value": .35,
		"variable": "var(--opacity-0\\.35)"
	},
	"opacity.0.4": {
		"value": .4,
		"variable": "var(--opacity-0\\.4)"
	},
	"opacity.0.45": {
		"value": .45,
		"variable": "var(--opacity-0\\.45)"
	},
	"opacity.0.5": {
		"value": .5,
		"variable": "var(--opacity-0\\.5)"
	},
	"opacity.0.55": {
		"value": .55,
		"variable": "var(--opacity-0\\.55)"
	},
	"opacity.0.6": {
		"value": .6,
		"variable": "var(--opacity-0\\.6)"
	},
	"opacity.0.65": {
		"value": .65,
		"variable": "var(--opacity-0\\.65)"
	},
	"opacity.0.7": {
		"value": .7,
		"variable": "var(--opacity-0\\.7)"
	},
	"opacity.0.75": {
		"value": .75,
		"variable": "var(--opacity-0\\.75)"
	},
	"opacity.0.8": {
		"value": .8,
		"variable": "var(--opacity-0\\.8)"
	},
	"opacity.0.85": {
		"value": .85,
		"variable": "var(--opacity-0\\.85)"
	},
	"opacity.0.9": {
		"value": .9,
		"variable": "var(--opacity-0\\.9)"
	},
	"opacity.0.95": {
		"value": .95,
		"variable": "var(--opacity-0\\.95)"
	},
	"opacity.disabled": {
		"value": .6,
		"variable": "var(--opacity-disabled)"
	},
	"cursor.default": {
		"value": "default",
		"variable": "var(--cursor-default)"
	},
	"cursor.pointer": {
		"value": "pointer",
		"variable": "var(--cursor-pointer)"
	},
	"cursor.none": {
		"value": "none",
		"variable": "var(--cursor-none)"
	},
	"cursor.inherit": {
		"value": "inherit",
		"variable": "var(--cursor-inherit)"
	},
	"cursor.grab": {
		"value": "grab",
		"variable": "var(--cursor-grab)"
	},
	"cursor.grabbing": {
		"value": "grabbing",
		"variable": "var(--cursor-grabbing)"
	},
	"cursor.move": {
		"value": "move",
		"variable": "var(--cursor-move)"
	},
	"cursor.zoom-out": {
		"value": "zoom-out",
		"variable": "var(--cursor-zoom-out)"
	},
	"breakpoints.xs": {
		"value": "36em",
		"variable": "var(--breakpoints-xs)"
	},
	"breakpoints.sm": {
		"value": "48em",
		"variable": "var(--breakpoints-sm)"
	},
	"breakpoints.md": {
		"value": "62em",
		"variable": "var(--breakpoints-md)"
	},
	"breakpoints.lg": {
		"value": "75em",
		"variable": "var(--breakpoints-lg)"
	},
	"breakpoints.xl": {
		"value": "88em",
		"variable": "var(--breakpoints-xl)"
	},
	"colors.surface.canvas": {
		"value": "var(--colors-surface-canvas)",
		"variable": "var(--colors-surface-canvas)"
	},
	"colors.surface.default": {
		"value": "var(--colors-surface-default)",
		"variable": "var(--colors-surface-default)"
	},
	"colors.surface.sunken": {
		"value": "var(--colors-surface-sunken)",
		"variable": "var(--colors-surface-sunken)"
	},
	"colors.surface.sunken.hover": {
		"value": "var(--colors-surface-sunken-hover)",
		"variable": "var(--colors-surface-sunken-hover)"
	},
	"colors.surface.code": {
		"value": "var(--colors-surface-code)",
		"variable": "var(--colors-surface-code)"
	},
	"colors.surface.field": {
		"value": "var(--colors-surface-field)",
		"variable": "var(--colors-surface-field)"
	},
	"colors.surface.field.hover": {
		"value": "var(--colors-surface-field-hover)",
		"variable": "var(--colors-surface-field-hover)"
	},
	"colors.surface.hover": {
		"value": "var(--colors-surface-hover)",
		"variable": "var(--colors-surface-hover)"
	},
	"colors.surface.selected": {
		"value": "var(--colors-surface-selected)",
		"variable": "var(--colors-surface-selected)"
	},
	"colors.text": {
		"value": "var(--colors-text)",
		"variable": "var(--colors-text)"
	},
	"colors.text.default": {
		"value": "var(--colors-text)",
		"variable": "var(--colors-text-default)"
	},
	"colors.text.bright": {
		"value": "var(--colors-text-bright)",
		"variable": "var(--colors-text-bright)"
	},
	"colors.text.dimmed": {
		"value": "var(--colors-text-dimmed)",
		"variable": "var(--colors-text-dimmed)"
	},
	"colors.text.non-essential": {
		"value": "var(--colors-text-non-essential)",
		"variable": "var(--colors-text-non-essential)"
	},
	"colors.text.display": {
		"value": "var(--colors-text-display)",
		"variable": "var(--colors-text-display)"
	},
	"colors.text.heading": {
		"value": "var(--colors-text-heading)",
		"variable": "var(--colors-text-heading)"
	},
	"colors.text.link": {
		"value": "var(--colors-text-link)",
		"variable": "var(--colors-text-link)"
	},
	"colors.text.on-primary": {
		"value": "#ffffff",
		"variable": "var(--colors-text-on-primary)"
	},
	"colors.text.on-inverse": {
		"value": "var(--colors-text-on-inverse)",
		"variable": "var(--colors-text-on-inverse)"
	},
	"colors.text.warning": {
		"value": "var(--colors-text-warning)",
		"variable": "var(--colors-text-warning)"
	},
	"colors.border.subtle": {
		"value": "var(--colors-border-subtle)",
		"variable": "var(--colors-border-subtle)"
	},
	"colors.border.default": {
		"value": "var(--colors-border-default)",
		"variable": "var(--colors-border-default)"
	},
	"colors.border.strong": {
		"value": "var(--colors-border-strong)",
		"variable": "var(--colors-border-strong)"
	},
	"colors.border.focus": {
		"value": "var(--colors-likec4-accent-6)",
		"variable": "var(--colors-border-focus)"
	},
	"colors.border.outline": {
		"value": "var(--colors-likec4-accent-7)",
		"variable": "var(--colors-border-outline)"
	},
	"colors.disabled.body": {
		"value": "var(--colors-disabled-body)",
		"variable": "var(--colors-disabled-body)"
	},
	"colors.disabled.text": {
		"value": "var(--colors-disabled-text)",
		"variable": "var(--colors-disabled-text)"
	},
	"colors.disabled.border": {
		"value": "var(--colors-disabled-border)",
		"variable": "var(--colors-disabled-border)"
	},
	"colors.highlight.body": {
		"value": "var(--colors-highlight-body)",
		"variable": "var(--colors-highlight-body)"
	},
	"colors.highlight.text": {
		"value": "#000000",
		"variable": "var(--colors-highlight-text)"
	},
	"colors.primary.body": {
		"value": "var(--colors-likec4-accent-6)",
		"variable": "var(--colors-primary-body)"
	},
	"colors.primary.body.hover": {
		"value": "var(--colors-likec4-accent-5)",
		"variable": "var(--colors-primary-body-hover)"
	},
	"colors.primary.body.focused": {
		"value": "var(--colors-likec4-accent-7)",
		"variable": "var(--colors-primary-body-focused)"
	},
	"colors.primary.body.light": {
		"value": "var(--colors-primary-body-light)",
		"variable": "var(--colors-primary-body-light)"
	},
	"colors.primary.body.lightHover": {
		"value": "var(--colors-primary-body-light-hover)",
		"variable": "var(--colors-primary-body-light-hover)"
	},
	"colors.primary.text": {
		"value": "#ffffff",
		"variable": "var(--colors-primary-text)"
	},
	"colors.primary.text.light": {
		"value": "var(--colors-primary-text-light)",
		"variable": "var(--colors-primary-text-light)"
	},
	"colors.primary.border": {
		"value": "var(--colors-likec4-accent-6)",
		"variable": "var(--colors-primary-border)"
	},
	"colors.primary.border.hover": {
		"value": "var(--colors-likec4-accent-5)",
		"variable": "var(--colors-primary-border-hover)"
	},
	"colors.primary.border.focused": {
		"value": "var(--colors-likec4-accent-7)",
		"variable": "var(--colors-primary-border-focused)"
	},
	"colors.warning.body": {
		"value": "var(--colors-warning-body)",
		"variable": "var(--colors-warning-body)"
	},
	"colors.warning.text": {
		"value": "#000000",
		"variable": "var(--colors-warning-text)"
	},
	"colors.diagram.background": {
		"value": "var(--colors-surface-canvas)",
		"variable": "var(--colors-diagram-background)"
	},
	"colors.diagram.background.pattern": {
		"value": "var(--colors-diagram-background-pattern)",
		"variable": "var(--colors-diagram-background-pattern)"
	},
	"colors.likec4.mixColor": {
		"value": "var(--colors-likec4-mix-color)",
		"variable": "var(--colors-likec4-mix-color)"
	},
	"colors.likec4.tag.bg": {
		"value": "var(--colors-tomato-9)",
		"variable": "var(--colors-likec4-tag-bg)"
	},
	"colors.likec4.tag.bg.hover": {
		"value": "var(--colors-tomato-10)",
		"variable": "var(--colors-likec4-tag-bg-hover)"
	},
	"colors.likec4.tag.border": {
		"value": "var(--colors-tomato-8)",
		"variable": "var(--colors-likec4-tag-border)"
	},
	"colors.likec4.tag.text": {
		"value": "var(--colors-tomato-3)",
		"variable": "var(--colors-likec4-tag-text)"
	},
	"colors.likec4.panel.bg": {
		"value": "var(--colors-likec4-panel-bg)",
		"variable": "var(--colors-likec4-panel-bg)"
	},
	"colors.likec4.panel.border": {
		"value": "var(--colors-likec4-panel-border)",
		"variable": "var(--colors-likec4-panel-border)"
	},
	"colors.likec4.panel.text": {
		"value": "color-mix(in srgb, var(--colors-text-default) 85%, transparent)",
		"variable": "var(--colors-likec4-panel-text)"
	},
	"colors.likec4.panel.text.dimmed": {
		"value": "var(--colors-text-dimmed)",
		"variable": "var(--colors-likec4-panel-text-dimmed)"
	},
	"colors.likec4.panel.action": {
		"value": "color-mix(in srgb, var(--colors-text-default) 90%, transparent)",
		"variable": "var(--colors-likec4-panel-action)"
	},
	"colors.likec4.panel.action.disabled": {
		"value": "var(--colors-text-dimmed)",
		"variable": "var(--colors-likec4-panel-action-disabled)"
	},
	"colors.likec4.panel.action.hover": {
		"value": "var(--colors-text-bright)",
		"variable": "var(--colors-likec4-panel-action-hover)"
	},
	"colors.likec4.panel.action.bg": {
		"value": "var(--colors-likec4-panel-action-bg)",
		"variable": "var(--colors-likec4-panel-action-bg)"
	},
	"colors.likec4.panel.action.bg.hover": {
		"value": "var(--colors-likec4-panel-action-bg-hover)",
		"variable": "var(--colors-likec4-panel-action-bg-hover)"
	},
	"colors.likec4.panel.action.warning": {
		"value": "#fd7e14",
		"variable": "var(--colors-likec4-panel-action-warning)"
	},
	"colors.likec4.panel.action.warning.hover": {
		"value": "var(--colors-likec4-panel-action-warning-hover)",
		"variable": "var(--colors-likec4-panel-action-warning-hover)"
	},
	"colors.likec4.panel.action.warning.bg": {
		"value": "var(--colors-likec4-panel-action-warning-bg)",
		"variable": "var(--colors-likec4-panel-action-warning-bg)"
	},
	"colors.likec4.panel.action.warning.bg.hover": {
		"value": "var(--colors-likec4-panel-action-warning-bg-hover)",
		"variable": "var(--colors-likec4-panel-action-warning-bg-hover)"
	},
	"colors.likec4.dropdown.bg": {
		"value": "var(--colors-likec4-dropdown-bg)",
		"variable": "var(--colors-likec4-dropdown-bg)"
	},
	"colors.likec4.dropdown.border": {
		"value": "var(--colors-likec4-panel-border)",
		"variable": "var(--colors-likec4-dropdown-border)"
	},
	"colors.likec4.overlay.backdrop": {
		"value": "var(--colors-likec4-overlay-backdrop)",
		"variable": "var(--colors-likec4-overlay-backdrop)"
	},
	"colors.likec4.overlay.body": {
		"value": "var(--colors-likec4-overlay-body)",
		"variable": "var(--colors-likec4-overlay-body)"
	},
	"colors.likec4.overlay.border": {
		"value": "color-mix(in srgb, var(--colors-border-default) 50%, transparent)",
		"variable": "var(--colors-likec4-overlay-border)"
	},
	"colors.likec4.walkthrough.parallelFrame": {
		"value": "var(--colors-likec4-walkthrough-parallel-frame)",
		"variable": "var(--colors-likec4-walkthrough-parallel-frame)"
	},
	"colors.likec4.compare.manual": {
		"value": "var(--colors-likec4-compare-manual)",
		"variable": "var(--colors-likec4-compare-manual)"
	},
	"colors.likec4.compare.outline": {
		"value": "var(--colors-likec4-compare-outline)",
		"variable": "var(--colors-likec4-compare-outline)"
	},
	"colors.likec4.compare.latest": {
		"value": "#40c057",
		"variable": "var(--colors-likec4-compare-latest)"
	},
	"colors.subflow.opt": {
		"value": "oklch(from #3b5bdb l c h / 8%)",
		"variable": "var(--colors-subflow-opt)"
	},
	"colors.subflow.opt.hovered": {
		"value": "oklch(from #3b5bdb l c h / 13%)",
		"variable": "var(--colors-subflow-opt-hovered)"
	},
	"colors.subflow.opt.text": {
		"value": "var(--colors-subflow-opt-text)",
		"variable": "var(--colors-subflow-opt-text)"
	},
	"colors.subflow.opt.border": {
		"value": "oklch(from #4263eb l c h / 65%)",
		"variable": "var(--colors-subflow-opt-border)"
	},
	"colors.subflow.opt.label": {
		"value": "oklch(from #4263eb l c h / 20%)",
		"variable": "var(--colors-subflow-opt-label)"
	},
	"colors.subflow.loop": {
		"value": "var(--colors-subflow-loop)",
		"variable": "var(--colors-subflow-loop)"
	},
	"colors.subflow.loop.hovered": {
		"value": "var(--colors-subflow-loop-hovered)",
		"variable": "var(--colors-subflow-loop-hovered)"
	},
	"colors.subflow.loop.text": {
		"value": "var(--colors-subflow-loop-text)",
		"variable": "var(--colors-subflow-loop-text)"
	},
	"colors.subflow.loop.border": {
		"value": "var(--colors-subflow-loop-border)",
		"variable": "var(--colors-subflow-loop-border)"
	},
	"colors.subflow.loop.header": {
		"value": "oklch(from #099268 l c h / 40%)",
		"variable": "var(--colors-subflow-loop-header)"
	},
	"colors.subflow.loop.label": {
		"value": "oklch(from #099268 l c h / 20%)",
		"variable": "var(--colors-subflow-loop-label)"
	},
	"colors.subflow.try": {
		"value": "var(--colors-subflow-try)",
		"variable": "var(--colors-subflow-try)"
	},
	"colors.subflow.try.hovered": {
		"value": "var(--colors-subflow-try-hovered)",
		"variable": "var(--colors-subflow-try-hovered)"
	},
	"colors.subflow.try.text": {
		"value": "var(--colors-subflow-try-text)",
		"variable": "var(--colors-subflow-try-text)"
	},
	"colors.subflow.try.border": {
		"value": "var(--colors-subflow-try-border)",
		"variable": "var(--colors-subflow-try-border)"
	},
	"colors.subflow.try.header": {
		"value": "var(--colors-subflow-try-header)",
		"variable": "var(--colors-subflow-try-header)"
	},
	"colors.subflow.try.label": {
		"value": "oklch(from #f08c00 l c h / 20%)",
		"variable": "var(--colors-subflow-try-label)"
	},
	"colors.subflow.break": {
		"value": "var(--colors-subflow-break)",
		"variable": "var(--colors-subflow-break)"
	},
	"colors.subflow.break.hovered": {
		"value": "var(--colors-subflow-break-hovered)",
		"variable": "var(--colors-subflow-break-hovered)"
	},
	"colors.subflow.break.text": {
		"value": "var(--colors-subflow-break-text)",
		"variable": "var(--colors-subflow-break-text)"
	},
	"colors.subflow.break.border": {
		"value": "oklch(from #f03e3e l c h / 65%)",
		"variable": "var(--colors-subflow-break-border)"
	},
	"colors.subflow.break.header": {
		"value": "var(--colors-subflow-break-header)",
		"variable": "var(--colors-subflow-break-header)"
	},
	"colors.subflow.break.label": {
		"value": "oklch(from #e03131 l c h / 25%)",
		"variable": "var(--colors-subflow-break-label)"
	},
	"colors.subflow.par": {
		"value": "oklch(from #9c36b5 l c h / 8%)",
		"variable": "var(--colors-subflow-par)"
	},
	"colors.subflow.par.hovered": {
		"value": "oklch(from #9c36b5 l c h / 13%)",
		"variable": "var(--colors-subflow-par-hovered)"
	},
	"colors.subflow.par.text": {
		"value": "var(--colors-subflow-par-text)",
		"variable": "var(--colors-subflow-par-text)"
	},
	"colors.subflow.par.border": {
		"value": "oklch(from #ae3ec9 l c h / 65%)",
		"variable": "var(--colors-subflow-par-border)"
	},
	"colors.subflow.par.header": {
		"value": "oklch(from #9c36b5 l c h / 40%)",
		"variable": "var(--colors-subflow-par-header)"
	},
	"colors.subflow.par.label": {
		"value": "oklch(from #ae3ec9 l c h / 20%)",
		"variable": "var(--colors-subflow-par-label)"
	},
	"colors.subflow.alt": {
		"value": "var(--colors-subflow-alt)",
		"variable": "var(--colors-subflow-alt)"
	},
	"colors.subflow.alt.hovered": {
		"value": "var(--colors-subflow-alt-hovered)",
		"variable": "var(--colors-subflow-alt-hovered)"
	},
	"colors.subflow.alt.header": {
		"value": "oklch(from #6741d9 l c h / 50%)",
		"variable": "var(--colors-subflow-alt-header)"
	},
	"colors.subflow.alt.text": {
		"value": "var(--colors-subflow-alt-text)",
		"variable": "var(--colors-subflow-alt-text)"
	},
	"colors.subflow.alt.border": {
		"value": "oklch(from #7048e8 l c h / 65%)",
		"variable": "var(--colors-subflow-alt-border)"
	},
	"colors.subflow.alt.label": {
		"value": "oklch(from #7048e8 l c h / 30%)",
		"variable": "var(--colors-subflow-alt-label)"
	},
	"colors.amber.1": {
		"value": "var(--colors-amber-1)",
		"variable": "var(--colors-amber-1)"
	},
	"colors.amber.2": {
		"value": "var(--colors-amber-2)",
		"variable": "var(--colors-amber-2)"
	},
	"colors.amber.3": {
		"value": "var(--colors-amber-3)",
		"variable": "var(--colors-amber-3)"
	},
	"colors.amber.4": {
		"value": "var(--colors-amber-4)",
		"variable": "var(--colors-amber-4)"
	},
	"colors.amber.5": {
		"value": "var(--colors-amber-5)",
		"variable": "var(--colors-amber-5)"
	},
	"colors.amber.6": {
		"value": "var(--colors-amber-6)",
		"variable": "var(--colors-amber-6)"
	},
	"colors.amber.7": {
		"value": "var(--colors-amber-7)",
		"variable": "var(--colors-amber-7)"
	},
	"colors.amber.8": {
		"value": "var(--colors-amber-8)",
		"variable": "var(--colors-amber-8)"
	},
	"colors.amber.9": {
		"value": "var(--colors-amber-9)",
		"variable": "var(--colors-amber-9)"
	},
	"colors.amber.10": {
		"value": "var(--colors-amber-10)",
		"variable": "var(--colors-amber-10)"
	},
	"colors.amber.11": {
		"value": "var(--colors-amber-11)",
		"variable": "var(--colors-amber-11)"
	},
	"colors.amber.12": {
		"value": "var(--colors-amber-12)",
		"variable": "var(--colors-amber-12)"
	},
	"colors.blue.1": {
		"value": "var(--colors-blue-1)",
		"variable": "var(--colors-blue-1)"
	},
	"colors.blue.2": {
		"value": "var(--colors-blue-2)",
		"variable": "var(--colors-blue-2)"
	},
	"colors.blue.3": {
		"value": "var(--colors-blue-3)",
		"variable": "var(--colors-blue-3)"
	},
	"colors.blue.4": {
		"value": "var(--colors-blue-4)",
		"variable": "var(--colors-blue-4)"
	},
	"colors.blue.5": {
		"value": "var(--colors-blue-5)",
		"variable": "var(--colors-blue-5)"
	},
	"colors.blue.6": {
		"value": "var(--colors-blue-6)",
		"variable": "var(--colors-blue-6)"
	},
	"colors.blue.7": {
		"value": "var(--colors-blue-7)",
		"variable": "var(--colors-blue-7)"
	},
	"colors.blue.8": {
		"value": "var(--colors-blue-8)",
		"variable": "var(--colors-blue-8)"
	},
	"colors.blue.9": {
		"value": "var(--colors-blue-9)",
		"variable": "var(--colors-blue-9)"
	},
	"colors.blue.10": {
		"value": "var(--colors-blue-10)",
		"variable": "var(--colors-blue-10)"
	},
	"colors.blue.11": {
		"value": "var(--colors-blue-11)",
		"variable": "var(--colors-blue-11)"
	},
	"colors.blue.12": {
		"value": "var(--colors-blue-12)",
		"variable": "var(--colors-blue-12)"
	},
	"colors.crimson.1": {
		"value": "var(--colors-crimson-1)",
		"variable": "var(--colors-crimson-1)"
	},
	"colors.crimson.2": {
		"value": "var(--colors-crimson-2)",
		"variable": "var(--colors-crimson-2)"
	},
	"colors.crimson.3": {
		"value": "var(--colors-crimson-3)",
		"variable": "var(--colors-crimson-3)"
	},
	"colors.crimson.4": {
		"value": "var(--colors-crimson-4)",
		"variable": "var(--colors-crimson-4)"
	},
	"colors.crimson.5": {
		"value": "var(--colors-crimson-5)",
		"variable": "var(--colors-crimson-5)"
	},
	"colors.crimson.6": {
		"value": "var(--colors-crimson-6)",
		"variable": "var(--colors-crimson-6)"
	},
	"colors.crimson.7": {
		"value": "var(--colors-crimson-7)",
		"variable": "var(--colors-crimson-7)"
	},
	"colors.crimson.8": {
		"value": "var(--colors-crimson-8)",
		"variable": "var(--colors-crimson-8)"
	},
	"colors.crimson.9": {
		"value": "var(--colors-crimson-9)",
		"variable": "var(--colors-crimson-9)"
	},
	"colors.crimson.10": {
		"value": "var(--colors-crimson-10)",
		"variable": "var(--colors-crimson-10)"
	},
	"colors.crimson.11": {
		"value": "var(--colors-crimson-11)",
		"variable": "var(--colors-crimson-11)"
	},
	"colors.crimson.12": {
		"value": "var(--colors-crimson-12)",
		"variable": "var(--colors-crimson-12)"
	},
	"colors.grass.1": {
		"value": "var(--colors-grass-1)",
		"variable": "var(--colors-grass-1)"
	},
	"colors.grass.2": {
		"value": "var(--colors-grass-2)",
		"variable": "var(--colors-grass-2)"
	},
	"colors.grass.3": {
		"value": "var(--colors-grass-3)",
		"variable": "var(--colors-grass-3)"
	},
	"colors.grass.4": {
		"value": "var(--colors-grass-4)",
		"variable": "var(--colors-grass-4)"
	},
	"colors.grass.5": {
		"value": "var(--colors-grass-5)",
		"variable": "var(--colors-grass-5)"
	},
	"colors.grass.6": {
		"value": "var(--colors-grass-6)",
		"variable": "var(--colors-grass-6)"
	},
	"colors.grass.7": {
		"value": "var(--colors-grass-7)",
		"variable": "var(--colors-grass-7)"
	},
	"colors.grass.8": {
		"value": "var(--colors-grass-8)",
		"variable": "var(--colors-grass-8)"
	},
	"colors.grass.9": {
		"value": "var(--colors-grass-9)",
		"variable": "var(--colors-grass-9)"
	},
	"colors.grass.10": {
		"value": "var(--colors-grass-10)",
		"variable": "var(--colors-grass-10)"
	},
	"colors.grass.11": {
		"value": "var(--colors-grass-11)",
		"variable": "var(--colors-grass-11)"
	},
	"colors.grass.12": {
		"value": "var(--colors-grass-12)",
		"variable": "var(--colors-grass-12)"
	},
	"colors.indigo.1": {
		"value": "var(--colors-indigo-1)",
		"variable": "var(--colors-indigo-1)"
	},
	"colors.indigo.2": {
		"value": "var(--colors-indigo-2)",
		"variable": "var(--colors-indigo-2)"
	},
	"colors.indigo.3": {
		"value": "var(--colors-indigo-3)",
		"variable": "var(--colors-indigo-3)"
	},
	"colors.indigo.4": {
		"value": "var(--colors-indigo-4)",
		"variable": "var(--colors-indigo-4)"
	},
	"colors.indigo.5": {
		"value": "var(--colors-indigo-5)",
		"variable": "var(--colors-indigo-5)"
	},
	"colors.indigo.6": {
		"value": "var(--colors-indigo-6)",
		"variable": "var(--colors-indigo-6)"
	},
	"colors.indigo.7": {
		"value": "var(--colors-indigo-7)",
		"variable": "var(--colors-indigo-7)"
	},
	"colors.indigo.8": {
		"value": "var(--colors-indigo-8)",
		"variable": "var(--colors-indigo-8)"
	},
	"colors.indigo.9": {
		"value": "var(--colors-indigo-9)",
		"variable": "var(--colors-indigo-9)"
	},
	"colors.indigo.10": {
		"value": "var(--colors-indigo-10)",
		"variable": "var(--colors-indigo-10)"
	},
	"colors.indigo.11": {
		"value": "var(--colors-indigo-11)",
		"variable": "var(--colors-indigo-11)"
	},
	"colors.indigo.12": {
		"value": "var(--colors-indigo-12)",
		"variable": "var(--colors-indigo-12)"
	},
	"colors.lime.1": {
		"value": "var(--colors-lime-1)",
		"variable": "var(--colors-lime-1)"
	},
	"colors.lime.2": {
		"value": "var(--colors-lime-2)",
		"variable": "var(--colors-lime-2)"
	},
	"colors.lime.3": {
		"value": "var(--colors-lime-3)",
		"variable": "var(--colors-lime-3)"
	},
	"colors.lime.4": {
		"value": "var(--colors-lime-4)",
		"variable": "var(--colors-lime-4)"
	},
	"colors.lime.5": {
		"value": "var(--colors-lime-5)",
		"variable": "var(--colors-lime-5)"
	},
	"colors.lime.6": {
		"value": "var(--colors-lime-6)",
		"variable": "var(--colors-lime-6)"
	},
	"colors.lime.7": {
		"value": "var(--colors-lime-7)",
		"variable": "var(--colors-lime-7)"
	},
	"colors.lime.8": {
		"value": "var(--colors-lime-8)",
		"variable": "var(--colors-lime-8)"
	},
	"colors.lime.9": {
		"value": "var(--colors-lime-9)",
		"variable": "var(--colors-lime-9)"
	},
	"colors.lime.10": {
		"value": "var(--colors-lime-10)",
		"variable": "var(--colors-lime-10)"
	},
	"colors.lime.11": {
		"value": "var(--colors-lime-11)",
		"variable": "var(--colors-lime-11)"
	},
	"colors.lime.12": {
		"value": "var(--colors-lime-12)",
		"variable": "var(--colors-lime-12)"
	},
	"colors.orange.1": {
		"value": "var(--colors-orange-1)",
		"variable": "var(--colors-orange-1)"
	},
	"colors.orange.2": {
		"value": "var(--colors-orange-2)",
		"variable": "var(--colors-orange-2)"
	},
	"colors.orange.3": {
		"value": "var(--colors-orange-3)",
		"variable": "var(--colors-orange-3)"
	},
	"colors.orange.4": {
		"value": "var(--colors-orange-4)",
		"variable": "var(--colors-orange-4)"
	},
	"colors.orange.5": {
		"value": "var(--colors-orange-5)",
		"variable": "var(--colors-orange-5)"
	},
	"colors.orange.6": {
		"value": "var(--colors-orange-6)",
		"variable": "var(--colors-orange-6)"
	},
	"colors.orange.7": {
		"value": "var(--colors-orange-7)",
		"variable": "var(--colors-orange-7)"
	},
	"colors.orange.8": {
		"value": "var(--colors-orange-8)",
		"variable": "var(--colors-orange-8)"
	},
	"colors.orange.9": {
		"value": "var(--colors-orange-9)",
		"variable": "var(--colors-orange-9)"
	},
	"colors.orange.10": {
		"value": "var(--colors-orange-10)",
		"variable": "var(--colors-orange-10)"
	},
	"colors.orange.11": {
		"value": "var(--colors-orange-11)",
		"variable": "var(--colors-orange-11)"
	},
	"colors.orange.12": {
		"value": "var(--colors-orange-12)",
		"variable": "var(--colors-orange-12)"
	},
	"colors.pink.1": {
		"value": "var(--colors-pink-1)",
		"variable": "var(--colors-pink-1)"
	},
	"colors.pink.2": {
		"value": "var(--colors-pink-2)",
		"variable": "var(--colors-pink-2)"
	},
	"colors.pink.3": {
		"value": "var(--colors-pink-3)",
		"variable": "var(--colors-pink-3)"
	},
	"colors.pink.4": {
		"value": "var(--colors-pink-4)",
		"variable": "var(--colors-pink-4)"
	},
	"colors.pink.5": {
		"value": "var(--colors-pink-5)",
		"variable": "var(--colors-pink-5)"
	},
	"colors.pink.6": {
		"value": "var(--colors-pink-6)",
		"variable": "var(--colors-pink-6)"
	},
	"colors.pink.7": {
		"value": "var(--colors-pink-7)",
		"variable": "var(--colors-pink-7)"
	},
	"colors.pink.8": {
		"value": "var(--colors-pink-8)",
		"variable": "var(--colors-pink-8)"
	},
	"colors.pink.9": {
		"value": "var(--colors-pink-9)",
		"variable": "var(--colors-pink-9)"
	},
	"colors.pink.10": {
		"value": "var(--colors-pink-10)",
		"variable": "var(--colors-pink-10)"
	},
	"colors.pink.11": {
		"value": "var(--colors-pink-11)",
		"variable": "var(--colors-pink-11)"
	},
	"colors.pink.12": {
		"value": "var(--colors-pink-12)",
		"variable": "var(--colors-pink-12)"
	},
	"colors.purple.1": {
		"value": "var(--colors-purple-1)",
		"variable": "var(--colors-purple-1)"
	},
	"colors.purple.2": {
		"value": "var(--colors-purple-2)",
		"variable": "var(--colors-purple-2)"
	},
	"colors.purple.3": {
		"value": "var(--colors-purple-3)",
		"variable": "var(--colors-purple-3)"
	},
	"colors.purple.4": {
		"value": "var(--colors-purple-4)",
		"variable": "var(--colors-purple-4)"
	},
	"colors.purple.5": {
		"value": "var(--colors-purple-5)",
		"variable": "var(--colors-purple-5)"
	},
	"colors.purple.6": {
		"value": "var(--colors-purple-6)",
		"variable": "var(--colors-purple-6)"
	},
	"colors.purple.7": {
		"value": "var(--colors-purple-7)",
		"variable": "var(--colors-purple-7)"
	},
	"colors.purple.8": {
		"value": "var(--colors-purple-8)",
		"variable": "var(--colors-purple-8)"
	},
	"colors.purple.9": {
		"value": "var(--colors-purple-9)",
		"variable": "var(--colors-purple-9)"
	},
	"colors.purple.10": {
		"value": "var(--colors-purple-10)",
		"variable": "var(--colors-purple-10)"
	},
	"colors.purple.11": {
		"value": "var(--colors-purple-11)",
		"variable": "var(--colors-purple-11)"
	},
	"colors.purple.12": {
		"value": "var(--colors-purple-12)",
		"variable": "var(--colors-purple-12)"
	},
	"colors.red.1": {
		"value": "var(--colors-red-1)",
		"variable": "var(--colors-red-1)"
	},
	"colors.red.2": {
		"value": "var(--colors-red-2)",
		"variable": "var(--colors-red-2)"
	},
	"colors.red.3": {
		"value": "var(--colors-red-3)",
		"variable": "var(--colors-red-3)"
	},
	"colors.red.4": {
		"value": "var(--colors-red-4)",
		"variable": "var(--colors-red-4)"
	},
	"colors.red.5": {
		"value": "var(--colors-red-5)",
		"variable": "var(--colors-red-5)"
	},
	"colors.red.6": {
		"value": "var(--colors-red-6)",
		"variable": "var(--colors-red-6)"
	},
	"colors.red.7": {
		"value": "var(--colors-red-7)",
		"variable": "var(--colors-red-7)"
	},
	"colors.red.8": {
		"value": "var(--colors-red-8)",
		"variable": "var(--colors-red-8)"
	},
	"colors.red.9": {
		"value": "var(--colors-red-9)",
		"variable": "var(--colors-red-9)"
	},
	"colors.red.10": {
		"value": "var(--colors-red-10)",
		"variable": "var(--colors-red-10)"
	},
	"colors.red.11": {
		"value": "var(--colors-red-11)",
		"variable": "var(--colors-red-11)"
	},
	"colors.red.12": {
		"value": "var(--colors-red-12)",
		"variable": "var(--colors-red-12)"
	},
	"colors.ruby.1": {
		"value": "var(--colors-ruby-1)",
		"variable": "var(--colors-ruby-1)"
	},
	"colors.ruby.2": {
		"value": "var(--colors-ruby-2)",
		"variable": "var(--colors-ruby-2)"
	},
	"colors.ruby.3": {
		"value": "var(--colors-ruby-3)",
		"variable": "var(--colors-ruby-3)"
	},
	"colors.ruby.4": {
		"value": "var(--colors-ruby-4)",
		"variable": "var(--colors-ruby-4)"
	},
	"colors.ruby.5": {
		"value": "var(--colors-ruby-5)",
		"variable": "var(--colors-ruby-5)"
	},
	"colors.ruby.6": {
		"value": "var(--colors-ruby-6)",
		"variable": "var(--colors-ruby-6)"
	},
	"colors.ruby.7": {
		"value": "var(--colors-ruby-7)",
		"variable": "var(--colors-ruby-7)"
	},
	"colors.ruby.8": {
		"value": "var(--colors-ruby-8)",
		"variable": "var(--colors-ruby-8)"
	},
	"colors.ruby.9": {
		"value": "var(--colors-ruby-9)",
		"variable": "var(--colors-ruby-9)"
	},
	"colors.ruby.10": {
		"value": "var(--colors-ruby-10)",
		"variable": "var(--colors-ruby-10)"
	},
	"colors.ruby.11": {
		"value": "var(--colors-ruby-11)",
		"variable": "var(--colors-ruby-11)"
	},
	"colors.ruby.12": {
		"value": "var(--colors-ruby-12)",
		"variable": "var(--colors-ruby-12)"
	},
	"colors.teal.1": {
		"value": "var(--colors-teal-1)",
		"variable": "var(--colors-teal-1)"
	},
	"colors.teal.2": {
		"value": "var(--colors-teal-2)",
		"variable": "var(--colors-teal-2)"
	},
	"colors.teal.3": {
		"value": "var(--colors-teal-3)",
		"variable": "var(--colors-teal-3)"
	},
	"colors.teal.4": {
		"value": "var(--colors-teal-4)",
		"variable": "var(--colors-teal-4)"
	},
	"colors.teal.5": {
		"value": "var(--colors-teal-5)",
		"variable": "var(--colors-teal-5)"
	},
	"colors.teal.6": {
		"value": "var(--colors-teal-6)",
		"variable": "var(--colors-teal-6)"
	},
	"colors.teal.7": {
		"value": "var(--colors-teal-7)",
		"variable": "var(--colors-teal-7)"
	},
	"colors.teal.8": {
		"value": "var(--colors-teal-8)",
		"variable": "var(--colors-teal-8)"
	},
	"colors.teal.9": {
		"value": "var(--colors-teal-9)",
		"variable": "var(--colors-teal-9)"
	},
	"colors.teal.10": {
		"value": "var(--colors-teal-10)",
		"variable": "var(--colors-teal-10)"
	},
	"colors.teal.11": {
		"value": "var(--colors-teal-11)",
		"variable": "var(--colors-teal-11)"
	},
	"colors.teal.12": {
		"value": "var(--colors-teal-12)",
		"variable": "var(--colors-teal-12)"
	},
	"colors.tomato.1": {
		"value": "var(--colors-tomato-1)",
		"variable": "var(--colors-tomato-1)"
	},
	"colors.tomato.2": {
		"value": "var(--colors-tomato-2)",
		"variable": "var(--colors-tomato-2)"
	},
	"colors.tomato.3": {
		"value": "var(--colors-tomato-3)",
		"variable": "var(--colors-tomato-3)"
	},
	"colors.tomato.4": {
		"value": "var(--colors-tomato-4)",
		"variable": "var(--colors-tomato-4)"
	},
	"colors.tomato.5": {
		"value": "var(--colors-tomato-5)",
		"variable": "var(--colors-tomato-5)"
	},
	"colors.tomato.6": {
		"value": "var(--colors-tomato-6)",
		"variable": "var(--colors-tomato-6)"
	},
	"colors.tomato.7": {
		"value": "var(--colors-tomato-7)",
		"variable": "var(--colors-tomato-7)"
	},
	"colors.tomato.8": {
		"value": "var(--colors-tomato-8)",
		"variable": "var(--colors-tomato-8)"
	},
	"colors.tomato.9": {
		"value": "var(--colors-tomato-9)",
		"variable": "var(--colors-tomato-9)"
	},
	"colors.tomato.10": {
		"value": "var(--colors-tomato-10)",
		"variable": "var(--colors-tomato-10)"
	},
	"colors.tomato.11": {
		"value": "var(--colors-tomato-11)",
		"variable": "var(--colors-tomato-11)"
	},
	"colors.tomato.12": {
		"value": "var(--colors-tomato-12)",
		"variable": "var(--colors-tomato-12)"
	},
	"colors.violet.1": {
		"value": "var(--colors-violet-1)",
		"variable": "var(--colors-violet-1)"
	},
	"colors.violet.2": {
		"value": "var(--colors-violet-2)",
		"variable": "var(--colors-violet-2)"
	},
	"colors.violet.3": {
		"value": "var(--colors-violet-3)",
		"variable": "var(--colors-violet-3)"
	},
	"colors.violet.4": {
		"value": "var(--colors-violet-4)",
		"variable": "var(--colors-violet-4)"
	},
	"colors.violet.5": {
		"value": "var(--colors-violet-5)",
		"variable": "var(--colors-violet-5)"
	},
	"colors.violet.6": {
		"value": "var(--colors-violet-6)",
		"variable": "var(--colors-violet-6)"
	},
	"colors.violet.7": {
		"value": "var(--colors-violet-7)",
		"variable": "var(--colors-violet-7)"
	},
	"colors.violet.8": {
		"value": "var(--colors-violet-8)",
		"variable": "var(--colors-violet-8)"
	},
	"colors.violet.9": {
		"value": "var(--colors-violet-9)",
		"variable": "var(--colors-violet-9)"
	},
	"colors.violet.10": {
		"value": "var(--colors-violet-10)",
		"variable": "var(--colors-violet-10)"
	},
	"colors.violet.11": {
		"value": "var(--colors-violet-11)",
		"variable": "var(--colors-violet-11)"
	},
	"colors.violet.12": {
		"value": "var(--colors-violet-12)",
		"variable": "var(--colors-violet-12)"
	},
	"colors.yellow.1": {
		"value": "var(--colors-yellow-1)",
		"variable": "var(--colors-yellow-1)"
	},
	"colors.yellow.2": {
		"value": "var(--colors-yellow-2)",
		"variable": "var(--colors-yellow-2)"
	},
	"colors.yellow.3": {
		"value": "var(--colors-yellow-3)",
		"variable": "var(--colors-yellow-3)"
	},
	"colors.yellow.4": {
		"value": "var(--colors-yellow-4)",
		"variable": "var(--colors-yellow-4)"
	},
	"colors.yellow.5": {
		"value": "var(--colors-yellow-5)",
		"variable": "var(--colors-yellow-5)"
	},
	"colors.yellow.6": {
		"value": "var(--colors-yellow-6)",
		"variable": "var(--colors-yellow-6)"
	},
	"colors.yellow.7": {
		"value": "var(--colors-yellow-7)",
		"variable": "var(--colors-yellow-7)"
	},
	"colors.yellow.8": {
		"value": "var(--colors-yellow-8)",
		"variable": "var(--colors-yellow-8)"
	},
	"colors.yellow.9": {
		"value": "var(--colors-yellow-9)",
		"variable": "var(--colors-yellow-9)"
	},
	"colors.yellow.10": {
		"value": "var(--colors-yellow-10)",
		"variable": "var(--colors-yellow-10)"
	},
	"colors.yellow.11": {
		"value": "var(--colors-yellow-11)",
		"variable": "var(--colors-yellow-11)"
	},
	"colors.yellow.12": {
		"value": "var(--colors-yellow-12)",
		"variable": "var(--colors-yellow-12)"
	},
	"spacing.-0": {
		"value": "calc(var(--spacing-0) * -1)",
		"variable": "var(--spacing-0)"
	},
	"spacing.-1": {
		"value": "calc(var(--spacing-1) * -1)",
		"variable": "var(--spacing-1)"
	},
	"spacing.-2": {
		"value": "calc(var(--spacing-2) * -1)",
		"variable": "var(--spacing-2)"
	},
	"spacing.-3": {
		"value": "calc(var(--spacing-3) * -1)",
		"variable": "var(--spacing-3)"
	},
	"spacing.-4": {
		"value": "calc(var(--spacing-4) * -1)",
		"variable": "var(--spacing-4)"
	},
	"spacing.-5": {
		"value": "calc(var(--spacing-5) * -1)",
		"variable": "var(--spacing-5)"
	},
	"spacing.-6": {
		"value": "calc(var(--spacing-6) * -1)",
		"variable": "var(--spacing-6)"
	},
	"spacing.-7": {
		"value": "calc(var(--spacing-7) * -1)",
		"variable": "var(--spacing-7)"
	},
	"spacing.-8": {
		"value": "calc(var(--spacing-8) * -1)",
		"variable": "var(--spacing-8)"
	},
	"spacing.-9": {
		"value": "calc(var(--spacing-9) * -1)",
		"variable": "var(--spacing-9)"
	},
	"spacing.-10": {
		"value": "calc(var(--spacing-10) * -1)",
		"variable": "var(--spacing-10)"
	},
	"spacing.-12": {
		"value": "calc(var(--spacing-12) * -1)",
		"variable": "var(--spacing-12)"
	},
	"spacing.-16": {
		"value": "calc(var(--spacing-16) * -1)",
		"variable": "var(--spacing-16)"
	},
	"spacing.-0.5": {
		"value": "calc(var(--spacing-0\\.5) * -1)",
		"variable": "var(--spacing-0\\.5)"
	},
	"spacing.-1.5": {
		"value": "calc(var(--spacing-1\\.5) * -1)",
		"variable": "var(--spacing-1\\.5)"
	},
	"spacing.-2.5": {
		"value": "calc(var(--spacing-2\\.5) * -1)",
		"variable": "var(--spacing-2\\.5)"
	},
	"spacing.-3.5": {
		"value": "calc(var(--spacing-3\\.5) * -1)",
		"variable": "var(--spacing-3\\.5)"
	},
	"spacing.-4.5": {
		"value": "calc(var(--spacing-4\\.5) * -1)",
		"variable": "var(--spacing-4\\.5)"
	},
	"spacing.-xxs": {
		"value": "calc(var(--spacing-xxs) * -1)",
		"variable": "var(--spacing-xxs)"
	},
	"spacing.-xs": {
		"value": "calc(var(--spacing-xs) * -1)",
		"variable": "var(--spacing-xs)"
	},
	"spacing.-sm": {
		"value": "calc(var(--spacing-sm) * -1)",
		"variable": "var(--spacing-sm)"
	},
	"spacing.-md": {
		"value": "calc(var(--spacing-md) * -1)",
		"variable": "var(--spacing-md)"
	},
	"spacing.-lg": {
		"value": "calc(var(--spacing-lg) * -1)",
		"variable": "var(--spacing-lg)"
	},
	"spacing.-xl": {
		"value": "calc(var(--spacing-xl) * -1)",
		"variable": "var(--spacing-xl)"
	},
	"spacing.likec4.-xs": {
		"value": "calc(var(--spacing-likec4-xs) * -1)",
		"variable": "var(--spacing-likec4-xs)"
	},
	"spacing.likec4.-sm": {
		"value": "calc(var(--spacing-likec4-sm) * -1)",
		"variable": "var(--spacing-likec4-sm)"
	},
	"spacing.likec4.-md": {
		"value": "calc(var(--spacing-likec4-md) * -1)",
		"variable": "var(--spacing-likec4-md)"
	},
	"spacing.likec4.-lg": {
		"value": "calc(var(--spacing-likec4-lg) * -1)",
		"variable": "var(--spacing-likec4-lg)"
	},
	"spacing.likec4.-xl": {
		"value": "calc(var(--spacing-likec4-xl) * -1)",
		"variable": "var(--spacing-likec4-xl)"
	},
	"colors.colorPalette.opt": {
		"value": "var(--colors-color-palette-opt)",
		"variable": "var(--colors-color-palette-opt)"
	},
	"colors.colorPalette": {
		"value": "var(--colors-color-palette)",
		"variable": "var(--colors-color-palette)"
	},
	"colors.colorPalette.opt.hovered": {
		"value": "var(--colors-color-palette-opt-hovered)",
		"variable": "var(--colors-color-palette-opt-hovered)"
	},
	"colors.colorPalette.hovered": {
		"value": "var(--colors-color-palette-hovered)",
		"variable": "var(--colors-color-palette-hovered)"
	},
	"colors.colorPalette.opt.text": {
		"value": "var(--colors-color-palette-opt-text)",
		"variable": "var(--colors-color-palette-opt-text)"
	},
	"colors.colorPalette.text": {
		"value": "var(--colors-color-palette-text)",
		"variable": "var(--colors-color-palette-text)"
	},
	"colors.colorPalette.opt.border": {
		"value": "var(--colors-color-palette-opt-border)",
		"variable": "var(--colors-color-palette-opt-border)"
	},
	"colors.colorPalette.border": {
		"value": "var(--colors-color-palette-border)",
		"variable": "var(--colors-color-palette-border)"
	},
	"colors.colorPalette.opt.label": {
		"value": "var(--colors-color-palette-opt-label)",
		"variable": "var(--colors-color-palette-opt-label)"
	},
	"colors.colorPalette.label": {
		"value": "var(--colors-color-palette-label)",
		"variable": "var(--colors-color-palette-label)"
	},
	"colors.colorPalette.loop": {
		"value": "var(--colors-color-palette-loop)",
		"variable": "var(--colors-color-palette-loop)"
	},
	"colors.colorPalette.loop.hovered": {
		"value": "var(--colors-color-palette-loop-hovered)",
		"variable": "var(--colors-color-palette-loop-hovered)"
	},
	"colors.colorPalette.loop.text": {
		"value": "var(--colors-color-palette-loop-text)",
		"variable": "var(--colors-color-palette-loop-text)"
	},
	"colors.colorPalette.loop.border": {
		"value": "var(--colors-color-palette-loop-border)",
		"variable": "var(--colors-color-palette-loop-border)"
	},
	"colors.colorPalette.loop.header": {
		"value": "var(--colors-color-palette-loop-header)",
		"variable": "var(--colors-color-palette-loop-header)"
	},
	"colors.colorPalette.header": {
		"value": "var(--colors-color-palette-header)",
		"variable": "var(--colors-color-palette-header)"
	},
	"colors.colorPalette.loop.label": {
		"value": "var(--colors-color-palette-loop-label)",
		"variable": "var(--colors-color-palette-loop-label)"
	},
	"colors.colorPalette.try": {
		"value": "var(--colors-color-palette-try)",
		"variable": "var(--colors-color-palette-try)"
	},
	"colors.colorPalette.try.hovered": {
		"value": "var(--colors-color-palette-try-hovered)",
		"variable": "var(--colors-color-palette-try-hovered)"
	},
	"colors.colorPalette.try.text": {
		"value": "var(--colors-color-palette-try-text)",
		"variable": "var(--colors-color-palette-try-text)"
	},
	"colors.colorPalette.try.border": {
		"value": "var(--colors-color-palette-try-border)",
		"variable": "var(--colors-color-palette-try-border)"
	},
	"colors.colorPalette.try.header": {
		"value": "var(--colors-color-palette-try-header)",
		"variable": "var(--colors-color-palette-try-header)"
	},
	"colors.colorPalette.try.label": {
		"value": "var(--colors-color-palette-try-label)",
		"variable": "var(--colors-color-palette-try-label)"
	},
	"colors.colorPalette.break": {
		"value": "var(--colors-color-palette-break)",
		"variable": "var(--colors-color-palette-break)"
	},
	"colors.colorPalette.break.hovered": {
		"value": "var(--colors-color-palette-break-hovered)",
		"variable": "var(--colors-color-palette-break-hovered)"
	},
	"colors.colorPalette.break.text": {
		"value": "var(--colors-color-palette-break-text)",
		"variable": "var(--colors-color-palette-break-text)"
	},
	"colors.colorPalette.break.border": {
		"value": "var(--colors-color-palette-break-border)",
		"variable": "var(--colors-color-palette-break-border)"
	},
	"colors.colorPalette.break.header": {
		"value": "var(--colors-color-palette-break-header)",
		"variable": "var(--colors-color-palette-break-header)"
	},
	"colors.colorPalette.break.label": {
		"value": "var(--colors-color-palette-break-label)",
		"variable": "var(--colors-color-palette-break-label)"
	},
	"colors.colorPalette.par": {
		"value": "var(--colors-color-palette-par)",
		"variable": "var(--colors-color-palette-par)"
	},
	"colors.colorPalette.par.hovered": {
		"value": "var(--colors-color-palette-par-hovered)",
		"variable": "var(--colors-color-palette-par-hovered)"
	},
	"colors.colorPalette.par.text": {
		"value": "var(--colors-color-palette-par-text)",
		"variable": "var(--colors-color-palette-par-text)"
	},
	"colors.colorPalette.par.border": {
		"value": "var(--colors-color-palette-par-border)",
		"variable": "var(--colors-color-palette-par-border)"
	},
	"colors.colorPalette.par.header": {
		"value": "var(--colors-color-palette-par-header)",
		"variable": "var(--colors-color-palette-par-header)"
	},
	"colors.colorPalette.par.label": {
		"value": "var(--colors-color-palette-par-label)",
		"variable": "var(--colors-color-palette-par-label)"
	},
	"colors.colorPalette.alt": {
		"value": "var(--colors-color-palette-alt)",
		"variable": "var(--colors-color-palette-alt)"
	},
	"colors.colorPalette.alt.hovered": {
		"value": "var(--colors-color-palette-alt-hovered)",
		"variable": "var(--colors-color-palette-alt-hovered)"
	},
	"colors.colorPalette.alt.header": {
		"value": "var(--colors-color-palette-alt-header)",
		"variable": "var(--colors-color-palette-alt-header)"
	},
	"colors.colorPalette.alt.text": {
		"value": "var(--colors-color-palette-alt-text)",
		"variable": "var(--colors-color-palette-alt-text)"
	},
	"colors.colorPalette.alt.border": {
		"value": "var(--colors-color-palette-alt-border)",
		"variable": "var(--colors-color-palette-alt-border)"
	},
	"colors.colorPalette.alt.label": {
		"value": "var(--colors-color-palette-alt-label)",
		"variable": "var(--colors-color-palette-alt-label)"
	}
};
function token(path, fallback) {
	return tokens[path]?.value || fallback;
}
function tokenVar(path, fallback) {
	return tokens[path]?.variable || fallback;
}
token.var = tokenVar;
//#endregion
//#region styled-system/jsx/is-valid-prop.mjs
var userGenerated = "css,pos,insetX,insetY,insetEnd,end,insetStart,start,flexDir,p,pl,pr,pt,pb,py,paddingY,paddingX,px,pe,paddingEnd,ps,paddingStart,ml,mr,mt,mb,m,my,marginY,mx,marginX,me,marginEnd,ms,marginStart,ringWidth,ringColor,ring,ringOffset,w,minW,maxW,h,minH,maxH,textShadowColor,bgPosition,bgPositionX,bgPositionY,bgAttachment,bgClip,bg,bgColor,bgOrigin,bgImage,bgRepeat,bgBlendMode,bgSize,bgGradient,bgLinear,bgRadial,bgConic,rounded,roundedTopLeft,roundedTopRight,roundedBottomRight,roundedBottomLeft,roundedTop,roundedRight,roundedBottom,roundedLeft,roundedStartStart,roundedStartEnd,roundedStart,roundedEndStart,roundedEndEnd,roundedEnd,borderX,borderXWidth,borderXColor,borderY,borderYWidth,borderYColor,borderStart,borderStartWidth,borderStartColor,borderEnd,borderEndWidth,borderEndColor,shadow,shadowColor,x,y,z,scrollMarginY,scrollMarginX,scrollPaddingY,scrollPaddingX,aspectRatio,boxDecorationBreak,zIndex,boxSizing,objectPosition,objectFit,overscrollBehavior,overscrollBehaviorX,overscrollBehaviorY,position,top,left,inset,insetInline,insetBlock,insetBlockEnd,insetBlockStart,insetInlineEnd,insetInlineStart,right,bottom,float,visibility,display,hideFrom,hideBelow,flexBasis,flex,flexDirection,flexGrow,flexShrink,gridTemplateColumns,gridTemplateRows,gridColumn,gridRow,gridColumnStart,gridColumnEnd,gridAutoFlow,gridAutoColumns,gridAutoRows,gap,gridGap,gridRowGap,gridColumnGap,rowGap,columnGap,justifyContent,alignContent,alignItems,alignSelf,padding,paddingLeft,paddingRight,paddingTop,paddingBottom,paddingBlock,paddingBlockEnd,paddingBlockStart,paddingInline,paddingInlineEnd,paddingInlineStart,marginLeft,marginRight,marginTop,marginBottom,margin,marginBlock,marginBlockEnd,marginBlockStart,marginInline,marginInlineEnd,marginInlineStart,spaceX,spaceY,outlineWidth,outlineColor,outline,outlineOffset,focusRing,focusVisibleRing,focusRingColor,focusRingOffset,focusRingWidth,focusRingStyle,divideX,divideY,divideColor,divideStyle,width,inlineSize,minWidth,minInlineSize,maxWidth,maxInlineSize,height,blockSize,minHeight,minBlockSize,maxHeight,maxBlockSize,boxSize,color,fontFamily,fontSize,fontSizeAdjust,fontPalette,fontKerning,fontFeatureSettings,fontWeight,fontSmoothing,fontVariant,fontVariantAlternates,fontVariantCaps,fontVariationSettings,fontVariantNumeric,letterSpacing,lineHeight,textAlign,textDecoration,textDecorationColor,textEmphasisColor,textDecorationStyle,textDecorationThickness,textUnderlineOffset,textTransform,textIndent,textShadow,WebkitTextFillColor,textOverflow,verticalAlign,wordBreak,textWrap,truncate,lineClamp,listStyleType,listStylePosition,listStyleImage,listStyle,backgroundPosition,backgroundPositionX,backgroundPositionY,backgroundAttachment,backgroundClip,background,backgroundColor,backgroundOrigin,backgroundImage,backgroundRepeat,backgroundBlendMode,backgroundSize,backgroundGradient,backgroundLinear,backgroundRadial,backgroundConic,textGradient,gradientFromPosition,gradientToPosition,gradientFrom,gradientTo,gradientVia,gradientViaPosition,borderRadius,borderTopLeftRadius,borderTopRightRadius,borderBottomRightRadius,borderBottomLeftRadius,borderTopRadius,borderRightRadius,borderBottomRadius,borderLeftRadius,borderStartStartRadius,borderStartEndRadius,borderStartRadius,borderEndStartRadius,borderEndEndRadius,borderEndRadius,border,borderWidth,borderTopWidth,borderLeftWidth,borderRightWidth,borderBottomWidth,borderBlockStartWidth,borderBlockEndWidth,borderColor,borderInline,borderInlineWidth,borderInlineColor,borderBlock,borderBlockWidth,borderBlockColor,borderLeft,borderLeftColor,borderInlineStart,borderInlineStartWidth,borderInlineStartColor,borderRight,borderRightColor,borderInlineEnd,borderInlineEndWidth,borderInlineEndColor,borderTop,borderTopColor,borderBottom,borderBottomColor,borderBlockEnd,borderBlockEndColor,borderBlockStart,borderBlockStartColor,opacity,boxShadow,boxShadowColor,mixBlendMode,filter,brightness,contrast,grayscale,hueRotate,invert,saturate,sepia,dropShadow,blur,backdropFilter,backdropBlur,backdropBrightness,backdropContrast,backdropGrayscale,backdropHueRotate,backdropInvert,backdropOpacity,backdropSaturate,backdropSepia,borderCollapse,borderSpacing,borderSpacingX,borderSpacingY,tableLayout,transitionTimingFunction,transitionDelay,transitionDuration,transitionProperty,transition,animation,animationName,animationTimingFunction,animationDuration,animationDelay,animationPlayState,animationComposition,animationFillMode,animationDirection,animationIterationCount,animationRange,animationState,animationRangeStart,animationRangeEnd,animationTimeline,transformOrigin,transformBox,transformStyle,transform,rotate,rotateX,rotateY,rotateZ,scale,scaleX,scaleY,translate,translateX,translateY,translateZ,accentColor,caretColor,scrollBehavior,scrollbar,scrollbarColor,scrollbarGutter,scrollbarWidth,scrollMargin,scrollMarginLeft,scrollMarginRight,scrollMarginTop,scrollMarginBottom,scrollMarginBlock,scrollMarginBlockEnd,scrollMarginBlockStart,scrollMarginInline,scrollMarginInlineEnd,scrollMarginInlineStart,scrollPadding,scrollPaddingBlock,scrollPaddingBlockStart,scrollPaddingBlockEnd,scrollPaddingInline,scrollPaddingInlineEnd,scrollPaddingInlineStart,scrollPaddingLeft,scrollPaddingRight,scrollPaddingTop,scrollPaddingBottom,scrollSnapAlign,scrollSnapStop,scrollSnapType,scrollSnapStrictness,scrollSnapMargin,scrollSnapMarginTop,scrollSnapMarginBottom,scrollSnapMarginLeft,scrollSnapMarginRight,scrollSnapCoordinate,scrollSnapDestination,scrollSnapPointsX,scrollSnapPointsY,scrollSnapTypeX,scrollSnapTypeY,scrollTimeline,scrollTimelineAxis,scrollTimelineName,touchAction,userSelect,overflow,overflowWrap,overflowX,overflowY,overflowAnchor,overflowBlock,overflowInline,overflowClipBox,overflowClipMargin,overscrollBehaviorBlock,overscrollBehaviorInline,fill,stroke,strokeWidth,strokeDasharray,strokeDashoffset,strokeLinecap,strokeLinejoin,strokeMiterlimit,strokeOpacity,srOnly,debug,appearance,backfaceVisibility,clipPath,hyphens,mask,maskImage,maskSize,textSizeAdjust,container,containerName,containerType,cursor,colorPalette,_hover,_focus,_focusWithin,_focusVisible,_disabled,_active,_visited,_target,_readOnly,_readWrite,_empty,_checked,_enabled,_expanded,_highlighted,_complete,_incomplete,_dragging,_before,_after,_firstLetter,_firstLine,_marker,_selection,_file,_backdrop,_first,_last,_only,_even,_odd,_firstOfType,_lastOfType,_onlyOfType,_peerFocus,_peerHover,_peerActive,_peerFocusWithin,_peerFocusVisible,_peerDisabled,_peerChecked,_peerInvalid,_peerExpanded,_peerPlaceholderShown,_groupFocus,_groupHover,_groupActive,_groupFocusWithin,_groupFocusVisible,_groupDisabled,_groupChecked,_groupExpanded,_groupInvalid,_indeterminate,_required,_valid,_invalid,_autofill,_inRange,_outOfRange,_placeholder,_placeholderShown,_pressed,_selected,_grabbed,_underValue,_overValue,_atValue,_default,_optional,_open,_closed,_fullscreen,_loading,_hidden,_current,_currentPage,_currentStep,_today,_unavailable,_rangeStart,_rangeEnd,_now,_topmost,_motionReduce,_motionSafe,_print,_landscape,_portrait,_dark,_light,_osDark,_osLight,_highContrast,_lessContrast,_moreContrast,_ltr,_rtl,_scrollbar,_scrollbarThumb,_scrollbarTrack,_horizontal,_vertical,_icon,_starting,_noscript,_invertedColors,_shapeSizeXs,_shapeSizeSm,_shapeSizeMd,_shapeSizeLg,_shapeSizeXl,_shapeRectangle,_shapePerson,_shapeBrowser,_shapeMobile,_shapeCylinder,_shapeStorage,_shapeQueue,_shapeBucket,_shapeDocument,_shapeComponent,_shapeAgent,_notDisabled,_reduceGraphics,_reduceGraphicsOnPan,_noReduceGraphics,_whenPanning,_smallZoom,_compoundTransparent,_edgeActive,_whenHovered,_whenSelectable,_whenSelected,_whenDimmed,_whenFocused,xs,xsOnly,xsDown,sm,smOnly,smDown,md,mdOnly,mdDown,lg,lgOnly,lgDown,xl,xlOnly,xlDown,xsToSm,xsToMd,xsToLg,xsToXl,smToMd,smToLg,smToXl,mdToLg,mdToXl,lgToXl,@/xs,@/sm,@/md,@/lg,@likec4-root/xs,@likec4-root/sm,@likec4-root/md,@likec4-root/lg,@likec4-dialog/xs,@likec4-dialog/sm,@likec4-dialog/md,@likec4-dialog/lg,textStyle,layerStyle,animationStyle".split(",");
var allCssProperties = "WebkitAppearance,WebkitBorderBefore,WebkitBorderBeforeColor,WebkitBorderBeforeStyle,WebkitBorderBeforeWidth,WebkitBoxReflect,WebkitLineClamp,WebkitMask,WebkitMaskAttachment,WebkitMaskClip,WebkitMaskComposite,WebkitMaskImage,WebkitMaskOrigin,WebkitMaskPosition,WebkitMaskPositionX,WebkitMaskPositionY,WebkitMaskRepeat,WebkitMaskRepeatX,WebkitMaskRepeatY,WebkitMaskSize,WebkitOverflowScrolling,WebkitTapHighlightColor,WebkitTextFillColor,WebkitTextStroke,WebkitTextStrokeColor,WebkitTextStrokeWidth,WebkitTouchCallout,WebkitUserModify,WebkitUserSelect,accentColor,alignContent,alignItems,alignSelf,alignTracks,all,anchorName,anchorScope,animation,animationComposition,animationDelay,animationDirection,animationDuration,animationFillMode,animationIterationCount,animationName,animationPlayState,animationRange,animationRangeEnd,animationRangeStart,animationTimeline,animationTimingFunction,appearance,aspectRatio,backdropFilter,backfaceVisibility,background,backgroundAttachment,backgroundBlendMode,backgroundClip,backgroundColor,backgroundImage,backgroundOrigin,backgroundPosition,backgroundPositionX,backgroundPositionY,backgroundRepeat,backgroundSize,blockSize,border,borderBlock,borderBlockColor,borderBlockEnd,borderBlockEndColor,borderBlockEndStyle,borderBlockEndWidth,borderBlockStart,borderBlockStartColor,borderBlockStartStyle,borderBlockStartWidth,borderBlockStyle,borderBlockWidth,borderBottom,borderBottomColor,borderBottomLeftRadius,borderBottomRightRadius,borderBottomStyle,borderBottomWidth,borderCollapse,borderColor,borderEndEndRadius,borderEndStartRadius,borderImage,borderImageOutset,borderImageRepeat,borderImageSlice,borderImageSource,borderImageWidth,borderInline,borderInlineColor,borderInlineEnd,borderInlineEndColor,borderInlineEndStyle,borderInlineEndWidth,borderInlineStart,borderInlineStartColor,borderInlineStartStyle,borderInlineStartWidth,borderInlineStyle,borderInlineWidth,borderLeft,borderLeftColor,borderLeftStyle,borderLeftWidth,borderRadius,borderRight,borderRightColor,borderRightStyle,borderRightWidth,borderSpacing,borderStartEndRadius,borderStartStartRadius,borderStyle,borderTop,borderTopColor,borderTopLeftRadius,borderTopRightRadius,borderTopStyle,borderTopWidth,borderWidth,bottom,boxAlign,boxDecorationBreak,boxDirection,boxFlex,boxFlexGroup,boxLines,boxOrdinalGroup,boxOrient,boxPack,boxShadow,boxSizing,breakAfter,breakBefore,breakInside,captionSide,caret,caretColor,caretShape,clear,clip,clipPath,clipRule,color,colorInterpolationFilters,colorScheme,columnCount,columnFill,columnGap,columnRule,columnRuleColor,columnRuleStyle,columnRuleWidth,columnSpan,columnWidth,columns,contain,containIntrinsicBlockSize,containIntrinsicHeight,containIntrinsicInlineSize,containIntrinsicSize,containIntrinsicWidth,container,containerName,containerType,content,contentVisibility,cornerShape,counterIncrement,counterReset,counterSet,cursor,cx,cy,d,direction,display,dominantBaseline,emptyCells,fieldSizing,fill,fillOpacity,fillRule,filter,flex,flexBasis,flexDirection,flexFlow,flexGrow,flexShrink,flexWrap,float,floodColor,floodOpacity,font,fontFamily,fontFeatureSettings,fontKerning,fontLanguageOverride,fontOpticalSizing,fontPalette,fontSize,fontSizeAdjust,fontSmooth,fontStretch,fontStyle,fontSynthesis,fontSynthesisPosition,fontSynthesisSmallCaps,fontSynthesisStyle,fontSynthesisWeight,fontVariant,fontVariantAlternates,fontVariantCaps,fontVariantEastAsian,fontVariantEmoji,fontVariantLigatures,fontVariantNumeric,fontVariantPosition,fontVariationSettings,fontWeight,forcedColorAdjust,gap,grid,gridArea,gridAutoColumns,gridAutoFlow,gridAutoRows,gridColumn,gridColumnEnd,gridColumnGap,gridColumnStart,gridGap,gridRow,gridRowEnd,gridRowGap,gridRowStart,gridTemplate,gridTemplateAreas,gridTemplateColumns,gridTemplateRows,hangingPunctuation,height,hyphenateCharacter,hyphenateLimitChars,hyphens,imageOrientation,imageRendering,imageResolution,imeMode,initialLetter,initialLetterAlign,inlineSize,inset,insetBlock,insetBlockEnd,insetBlockStart,insetInline,insetInlineEnd,insetInlineStart,interpolateSize,isolation,justifyContent,justifyItems,justifySelf,justifyTracks,left,letterSpacing,lightingColor,lineBreak,lineClamp,lineHeight,lineHeightStep,listStyle,listStyleImage,listStylePosition,listStyleType,margin,marginBlock,marginBlockEnd,marginBlockStart,marginBottom,marginInline,marginInlineEnd,marginInlineStart,marginLeft,marginRight,marginTop,marginTrim,marker,markerEnd,markerMid,markerStart,mask,maskBorder,maskBorderMode,maskBorderOutset,maskBorderRepeat,maskBorderSlice,maskBorderSource,maskBorderWidth,maskClip,maskComposite,maskImage,maskMode,maskOrigin,maskPosition,maskRepeat,maskSize,maskType,masonryAutoFlow,mathDepth,mathShift,mathStyle,maxBlockSize,maxHeight,maxInlineSize,maxLines,maxWidth,minBlockSize,minHeight,minInlineSize,minWidth,mixBlendMode,objectFit,objectPosition,offset,offsetAnchor,offsetDistance,offsetPath,offsetPosition,offsetRotate,opacity,order,orphans,outline,outlineColor,outlineOffset,outlineStyle,outlineWidth,overflow,overflowAnchor,overflowBlock,overflowClipBox,overflowClipMargin,overflowInline,overflowWrap,overflowX,overflowY,overlay,overscrollBehavior,overscrollBehaviorBlock,overscrollBehaviorInline,overscrollBehaviorX,overscrollBehaviorY,padding,paddingBlock,paddingBlockEnd,paddingBlockStart,paddingBottom,paddingInline,paddingInlineEnd,paddingInlineStart,paddingLeft,paddingRight,paddingTop,page,pageBreakAfter,pageBreakBefore,pageBreakInside,paintOrder,perspective,perspectiveOrigin,placeContent,placeItems,placeSelf,pointerEvents,position,positionAnchor,positionArea,positionTry,positionTryFallbacks,positionTryOrder,positionVisibility,printColorAdjust,quotes,r,resize,right,rotate,rowGap,rubyAlign,rubyMerge,rubyPosition,rx,ry,scale,scrollBehavior,scrollMargin,scrollMarginBlock,scrollMarginBlockEnd,scrollMarginBlockStart,scrollMarginBottom,scrollMarginInline,scrollMarginInlineEnd,scrollMarginInlineStart,scrollMarginLeft,scrollMarginRight,scrollMarginTop,scrollPadding,scrollPaddingBlock,scrollPaddingBlockEnd,scrollPaddingBlockStart,scrollPaddingBottom,scrollPaddingInline,scrollPaddingInlineEnd,scrollPaddingInlineStart,scrollPaddingLeft,scrollPaddingRight,scrollPaddingTop,scrollSnapAlign,scrollSnapCoordinate,scrollSnapDestination,scrollSnapPointsX,scrollSnapPointsY,scrollSnapStop,scrollSnapType,scrollSnapTypeX,scrollSnapTypeY,scrollTimeline,scrollTimelineAxis,scrollTimelineName,scrollbarColor,scrollbarGutter,scrollbarWidth,shapeImageThreshold,shapeMargin,shapeOutside,shapeRendering,stopColor,stopOpacity,stroke,strokeDasharray,strokeDashoffset,strokeLinecap,strokeLinejoin,strokeMiterlimit,strokeOpacity,strokeWidth,tabSize,tableLayout,textAlign,textAlignLast,textAnchor,textBox,textBoxEdge,textBoxTrim,textCombineUpright,textDecoration,textDecorationColor,textDecorationLine,textDecorationSkip,textDecorationSkipInk,textDecorationStyle,textDecorationThickness,textEmphasis,textEmphasisColor,textEmphasisPosition,textEmphasisStyle,textIndent,textJustify,textOrientation,textOverflow,textRendering,textShadow,textSizeAdjust,textSpacingTrim,textTransform,textUnderlineOffset,textUnderlinePosition,textWrap,textWrapMode,textWrapStyle,timelineScope,top,touchAction,transform,transformBox,transformOrigin,transformStyle,transition,transitionBehavior,transitionDelay,transitionDuration,transitionProperty,transitionTimingFunction,translate,unicodeBidi,userSelect,vectorEffect,verticalAlign,viewTimeline,viewTimelineAxis,viewTimelineInset,viewTimelineName,viewTransitionName,visibility,whiteSpace,whiteSpaceCollapse,widows,width,willChange,wordBreak,wordSpacing,wordWrap,writingMode,x,y,zIndex,zoom,alignmentBaseline,baselineShift,colorInterpolation,colorRendering,glyphOrientationVertical".split(",").concat(userGenerated);
var properties = new Map(allCssProperties.map((prop) => [prop, true]));
var cssPropertySelectorRegex = /&|@/;
var isCssProperty = /* @__PURE__ */ memo$1((prop) => {
	return properties.has(prop) || prop.startsWith("--") || cssPropertySelectorRegex.test(prop);
});
//#endregion
//#region styled-system/jsx/factory-helper.mjs
var defaultShouldForwardProp = (prop, variantKeys) => !variantKeys.includes(prop) && !isCssProperty(prop);
var composeShouldForwardProps = (tag, shouldForwardProp) => tag.__shouldForwardProps__ && shouldForwardProp ? (propName) => tag.__shouldForwardProps__(propName) && shouldForwardProp(propName) : shouldForwardProp;
var composeCvaFn = (cvaA, cvaB) => {
	if (cvaA && !cvaB) return cvaA;
	if (!cvaA && cvaB) return cvaB;
	if (cvaA.__cva__ && cvaB.__cva__ || cvaA.__recipe__ && cvaB.__recipe__) return cvaA.merge(cvaB);
	const error = /* @__PURE__ */ new TypeError("Cannot merge cva with recipe. Please use either cva or recipe.");
	TypeError.captureStackTrace?.(error);
	throw error;
};
var getDisplayName = (Component) => {
	if (typeof Component === "string") return Component;
	return Component?.displayName || Component?.name || "Component";
};
//#endregion
//#region styled-system/jsx/factory.mjs
function styledFn(Dynamic, configOrCva = {}, options = {}) {
	const cvaFn = configOrCva.__cva__ || configOrCva.__recipe__ ? configOrCva : cva(configOrCva);
	const forwardFn = options.shouldForwardProp || defaultShouldForwardProp;
	const shouldForwardProp = (prop) => {
		if (options.forwardProps?.includes(prop)) return true;
		return forwardFn(prop, cvaFn.variantKeys);
	};
	const defaultProps = Object.assign(options.dataAttr && configOrCva.__name__ ? { "data-recipe": configOrCva.__name__ } : {}, options.defaultProps);
	const __cvaFn__ = composeCvaFn(Dynamic.__cva__, cvaFn);
	const __shouldForwardProps__ = composeShouldForwardProps(Dynamic, shouldForwardProp);
	const __base__ = Dynamic.__base__ || Dynamic;
	const StyledComponent = /* @__PURE__ */ forwardRef(function StyledComponent(props, ref) {
		const { as: Element = __base__, unstyled, children, ...restProps } = props;
		const combinedProps = useMemo(() => Object.assign({}, defaultProps, restProps), [restProps]);
		const [htmlProps, forwardedProps, variantProps, styleProps, elementProps] = useMemo(() => {
			return splitProps(combinedProps, normalizeHTMLProps.keys, __shouldForwardProps__, __cvaFn__.variantKeys, isCssProperty);
		}, [combinedProps]);
		function recipeClass() {
			const { css: cssStyles, ...propStyles } = styleProps;
			const compoundVariantStyles = __cvaFn__.__getCompoundVariantCss__?.(variantProps);
			return cx(__cvaFn__(variantProps, false), css(compoundVariantStyles, propStyles, cssStyles), combinedProps.className);
		}
		function cvaClass() {
			const { css: cssStyles, ...propStyles } = styleProps;
			return cx(css(__cvaFn__.raw(variantProps), propStyles, cssStyles), combinedProps.className);
		}
		const classes = () => {
			if (unstyled) {
				const { css: cssStyles, ...propStyles } = styleProps;
				return cx(css(propStyles, cssStyles), combinedProps.className);
			}
			return configOrCva.__recipe__ ? recipeClass() : cvaClass();
		};
		return createElement(Element, {
			ref,
			...forwardedProps,
			...elementProps,
			...normalizeHTMLProps(htmlProps),
			className: classes()
		}, children ?? combinedProps.children);
	});
	StyledComponent.displayName = `styled.${getDisplayName(__base__)}`;
	StyledComponent.__cva__ = __cvaFn__;
	StyledComponent.__base__ = __base__;
	StyledComponent.__shouldForwardProps__ = shouldForwardProp;
	return StyledComponent;
}
function createJsxFactory() {
	const cache = /* @__PURE__ */ new Map();
	return new Proxy(styledFn, {
		apply(_, __, args) {
			return styledFn(...args);
		},
		get(_, el) {
			if (!cache.has(el)) cache.set(el, styledFn(el));
			return cache.get(el);
		}
	});
}
var styled = /* @__PURE__ */ createJsxFactory();
//#endregion
//#region styled-system/jsx/create-style-context.mjs
function createSafeContext(contextName) {
	const Context = createContext(void 0);
	const useStyleContext = (componentName, slot) => {
		const context = useContext(Context);
		if (context === void 0) {
			const componentInfo = componentName ? `Component "${componentName}"` : "A component";
			const slotInfo = slot ? ` (slot: "${slot}")` : "";
			throw new Error(`${componentInfo}${slotInfo} cannot access ${contextName} because it's missing its Provider.`);
		}
		return context;
	};
	return [Context, useStyleContext];
}
function createStyleContext(recipe) {
	const isConfigRecipe = "__recipe__" in recipe;
	const recipeName = isConfigRecipe && recipe.__name__ ? recipe.__name__ : void 0;
	const [StyleContext, useStyleContext] = createSafeContext(recipeName ? `createStyleContext("${recipeName}")` : "createStyleContext");
	const svaFn = isConfigRecipe ? recipe : sva(recipe.config);
	const getResolvedProps = (props, slotStyles) => {
		const { unstyled, ...restProps } = props;
		if (unstyled) return restProps;
		if (isConfigRecipe) return {
			...restProps,
			className: cx(slotStyles, restProps.className)
		};
		return {
			...slotStyles,
			...restProps
		};
	};
	const withRootProvider = (Component, options) => {
		const WithRootProvider = (props) => {
			const [variantProps, otherProps] = svaFn.splitVariantProps(props);
			const slotStyles = isConfigRecipe ? svaFn(variantProps) : svaFn.raw(variantProps);
			slotStyles._classNameMap = svaFn.classNameMap;
			const mergedProps = options?.defaultProps ? {
				...options.defaultProps,
				...otherProps
			} : otherProps;
			return createElement(StyleContext.Provider, {
				value: slotStyles,
				children: createElement(Component, mergedProps)
			});
		};
		WithRootProvider.displayName = `withRootProvider(${getDisplayName(Component)})`;
		return WithRootProvider;
	};
	const withProvider = (Component, slot, options) => {
		const StyledComponent = styled(Component, {}, options);
		const WithProvider = forwardRef((props, ref) => {
			const [variantProps, restProps] = svaFn.splitVariantProps(props);
			options?.forwardProps?.forEach((key) => {
				if (key in variantProps) restProps[key] = variantProps[key];
			});
			const slotStyles = isConfigRecipe ? svaFn(variantProps) : svaFn.raw(variantProps);
			slotStyles._classNameMap = svaFn.classNameMap;
			const propsWithClass = {
				...restProps,
				className: restProps.className ?? options?.defaultProps?.className
			};
			const resolvedProps = getResolvedProps(propsWithClass, slotStyles[slot]);
			return createElement(StyleContext.Provider, {
				value: slotStyles,
				children: createElement(StyledComponent, {
					...resolvedProps,
					className: cx(resolvedProps.className, slotStyles._classNameMap[slot]),
					ref
				})
			});
		});
		WithProvider.displayName = `withProvider(${getDisplayName(Component)})`;
		return WithProvider;
	};
	const withContext = (Component, slot, options) => {
		const StyledComponent = styled(Component, {}, options);
		const componentName = getDisplayName(Component);
		const WithContext = forwardRef((props, ref) => {
			const slotStyles = useStyleContext(componentName, slot);
			const propsWithClass = {
				...props,
				className: props.className ?? options?.defaultProps?.className
			};
			const resolvedProps = getResolvedProps(propsWithClass, slotStyles[slot]);
			return createElement(StyledComponent, {
				...resolvedProps,
				className: cx(resolvedProps.className, slotStyles._classNameMap[slot]),
				ref
			});
		});
		WithContext.displayName = `withContext(${componentName})`;
		return WithContext;
	};
	return {
		withRootProvider,
		withProvider,
		withContext
	};
}
//#endregion
//#region styled-system/patterns/box.mjs
var boxConfig = { transform(props) {
	return props;
} };
var getBoxStyle = (styles = {}) => {
	const _styles = getPatternStyles(boxConfig, styles);
	return boxConfig.transform(_styles, patternFns);
};
var box = (styles) => css(getBoxStyle(styles));
box.raw = getBoxStyle;
//#endregion
//#region styled-system/jsx/box.mjs
var Box = /* @__PURE__ */ forwardRef(function Box(props, ref) {
	const [patternProps, restProps] = splitProps(props, []);
	const mergedProps = {
		ref,
		...getBoxStyle(patternProps),
		...restProps
	};
	return createElement(styled.div, mergedProps);
});
//#endregion
//#region styled-system/patterns/flex.mjs
var flexConfig = { transform(props) {
	const { direction, align, justify, wrap: wrap2, basis, grow, shrink, ...rest } = props;
	return {
		display: "flex",
		flexDirection: direction,
		alignItems: align,
		justifyContent: justify,
		flexWrap: wrap2,
		flexBasis: basis,
		flexGrow: grow,
		flexShrink: shrink,
		...rest
	};
} };
var getFlexStyle = (styles = {}) => {
	const _styles = getPatternStyles(flexConfig, styles);
	return flexConfig.transform(_styles, patternFns);
};
var flex = (styles) => css(getFlexStyle(styles));
flex.raw = getFlexStyle;
//#endregion
//#region styled-system/jsx/flex.mjs
var Flex = /* @__PURE__ */ forwardRef(function Flex(props, ref) {
	const [patternProps, restProps] = splitProps(props, [
		"align",
		"justify",
		"direction",
		"wrap",
		"basis",
		"grow",
		"shrink"
	]);
	const mergedProps = {
		ref,
		...getFlexStyle(patternProps),
		...restProps
	};
	return createElement(styled.div, mergedProps);
});
//#endregion
//#region styled-system/patterns/vstack.mjs
var vstackConfig = {
	transform(props) {
		const { justify, gap, ...rest } = props;
		return {
			display: "flex",
			alignItems: "center",
			justifyContent: justify,
			gap,
			flexDirection: "column",
			...rest
		};
	},
	defaultValues: {
		alignItems: "stretch",
		gap: "sm"
	}
};
var getVstackStyle = (styles = {}) => {
	const _styles = getPatternStyles(vstackConfig, styles);
	return vstackConfig.transform(_styles, patternFns);
};
var vstack = (styles) => css(getVstackStyle(styles));
vstack.raw = getVstackStyle;
//#endregion
//#region styled-system/jsx/vstack.mjs
var VStack = /* @__PURE__ */ forwardRef(function VStack(props, ref) {
	const [patternProps, restProps] = splitProps(props, ["justify", "gap"]);
	const mergedProps = {
		ref,
		...getVstackStyle(patternProps),
		...restProps
	};
	return createElement(styled.div, mergedProps);
});
//#endregion
//#region styled-system/patterns/hstack.mjs
var hstackConfig = {
	transform(props) {
		const { justify, gap, ...rest } = props;
		return {
			display: "flex",
			alignItems: "center",
			justifyContent: justify,
			gap,
			flexDirection: "row",
			...rest
		};
	},
	defaultValues: { gap: "sm" }
};
var getHstackStyle = (styles = {}) => {
	const _styles = getPatternStyles(hstackConfig, styles);
	return hstackConfig.transform(_styles, patternFns);
};
var hstack = (styles) => css(getHstackStyle(styles));
hstack.raw = getHstackStyle;
//#endregion
//#region styled-system/jsx/hstack.mjs
var HStack = /* @__PURE__ */ forwardRef(function HStack(props, ref) {
	const [patternProps, restProps] = splitProps(props, ["justify", "gap"]);
	const mergedProps = {
		ref,
		...getHstackStyle(patternProps),
		...restProps
	};
	return createElement(styled.div, mergedProps);
});
//#endregion
//#region styled-system/patterns/container.mjs
var containerConfig = { transform(props) {
	return {
		position: "relative",
		maxWidth: "8xl",
		mx: "auto",
		px: {
			base: "4",
			md: "6",
			lg: "8"
		},
		...props
	};
} };
var getContainerStyle = (styles = {}) => {
	const _styles = getPatternStyles(containerConfig, styles);
	return containerConfig.transform(_styles, patternFns);
};
var container = (styles) => css(getContainerStyle(styles));
container.raw = getContainerStyle;
//#endregion
//#region styled-system/patterns/bleed.mjs
var bleedConfig = {
	transform(props, { map, isCssUnit, isCssVar }) {
		const { inline, block, ...rest } = props;
		const valueFn = (v) => isCssUnit(v) || isCssVar(v) ? v : `token(spacing.${v}, ${v})`;
		return {
			"--bleed-x": map(inline, valueFn),
			"--bleed-y": map(block, valueFn),
			marginInline: "calc(var(--bleed-x, 0) * -1)",
			marginBlock: "calc(var(--bleed-y, 0) * -1)",
			...rest
		};
	},
	defaultValues: {
		inline: "0",
		block: "0"
	}
};
var getBleedStyle = (styles = {}) => {
	const _styles = getPatternStyles(bleedConfig, styles);
	return bleedConfig.transform(_styles, patternFns);
};
var bleed = (styles) => css(getBleedStyle(styles));
bleed.raw = getBleedStyle;
//#endregion
//#region styled-system/patterns/txt.mjs
var txtConfig = {
	transform(props, _helpers) {
		const { inline, size, dimmed, lh, fw, likec4color, nouserselect, medium, semibold, ...rest } = props;
		if (dimmed && likec4color) throw new Error("dimmed and likec4color are mutually exclusive");
		const hasNoTextStyle = !(typeof rest["textStyle"] === "string" && rest["textStyle"] !== "");
		const hasLhOrFw = !!lh || !!fw;
		return {
			cursor: "default",
			...inline && { display: "inline-block" },
			...likec4color && { "data-likec4-color": likec4color },
			...nouserselect && { userSelect: "none" },
			...hasNoTextStyle && !hasLhOrFw && { textStyle: dimmed ? `dimmed.${size}` : size },
			...hasNoTextStyle && hasLhOrFw && { fontSize: size },
			...medium && { fontWeight: "medium" },
			...semibold && { fontWeight: "semibold" },
			...lh && { lineHeight: lh },
			...fw && { fontWeight: fw },
			...rest
		};
	},
	defaultValues: { size: "md" }
};
var getTxtStyle = (styles = {}) => {
	const _styles = getPatternStyles(txtConfig, styles);
	return txtConfig.transform(_styles, patternFns);
};
var txt = (styles) => css(getTxtStyle(styles));
txt.raw = getTxtStyle;
//#endregion
//#region styled-system/jsx/txt.mjs
var Txt = /* @__PURE__ */ forwardRef(function Txt(props, ref) {
	const [patternProps, restProps] = splitProps(props, [
		"inline",
		"medium",
		"semibold",
		"dimmed",
		"nouserselect",
		"lh",
		"size",
		"fw",
		"likec4color"
	]);
	const mergedProps = {
		ref,
		...getTxtStyle(patternProps),
		...restProps
	};
	return createElement(styled.div, mergedProps);
});
//#endregion
//#region styled-system/recipes/create-recipe.mjs
var createRecipe = (name, defaultVariants, compoundVariants) => {
	const getVariantProps = (variants) => {
		return {
			[name]: "__ignore__",
			...defaultVariants,
			...compact(variants)
		};
	};
	const recipeFn = (variants, withCompoundVariants = true) => {
		const transform = (prop, value) => {
			assertCompoundVariant(name, compoundVariants, variants, prop);
			if (value === "__ignore__") return { className: name };
			value = withoutSpace(value);
			return { className: `${name}--${prop}_${value}` };
		};
		const recipeCss = createCss({
			conditions: {
				shift: sortConditions,
				finalize: finalizeConditions,
				breakpoints: { keys: [
					"base",
					"xs",
					"sm",
					"md",
					"lg",
					"xl"
				] }
			},
			utility: {
				toHash: (path, hashFn) => hashFn(path.join(":")),
				transform
			}
		});
		const recipeStyles = getVariantProps(variants);
		if (withCompoundVariants) {
			const compoundVariantStyles = getCompoundVariantCss(compoundVariants, recipeStyles);
			return cx(recipeCss(recipeStyles), css(compoundVariantStyles));
		}
		return recipeCss(recipeStyles);
	};
	return {
		recipeFn,
		getVariantProps,
		__getCompoundVariantCss__: (variants) => {
			return getCompoundVariantCss(compoundVariants, getVariantProps(variants));
		}
	};
};
var mergeRecipes = (recipeA, recipeB) => {
	if (recipeA && !recipeB) return recipeA;
	if (!recipeA && recipeB) return recipeB;
	const recipeFn = (...args) => cx(recipeA(...args), recipeB(...args));
	const variantKeys = uniq(recipeA.variantKeys, recipeB.variantKeys);
	const variantMap = variantKeys.reduce((acc, key) => {
		acc[key] = uniq(recipeA.variantMap[key], recipeB.variantMap[key]);
		return acc;
	}, {});
	return Object.assign(recipeFn, {
		__recipe__: true,
		__name__: `${recipeA.__name__} ${recipeB.__name__}`,
		raw: (props) => props,
		variantKeys,
		variantMap,
		splitVariantProps(props) {
			return splitProps(props, variantKeys);
		}
	});
};
//#endregion
//#region styled-system/recipes/action-btn.mjs
var actionBtnFn = /* @__PURE__ */ createRecipe("action-btn", {
	"size": "md",
	"radius": "md",
	"variant": "filled"
}, []);
var actionBtnVariantMap = {
	"variant": ["transparent", "filled"],
	"size": ["sm", "md"],
	"radius": ["sm", "md"]
};
var actionBtnVariantKeys = Object.keys(actionBtnVariantMap);
var actionBtn = /* @__PURE__ */ Object.assign(memo$1(actionBtnFn.recipeFn), {
	__recipe__: true,
	__name__: "actionBtn",
	__getCompoundVariantCss__: actionBtnFn.__getCompoundVariantCss__,
	raw: (props) => props,
	variantKeys: actionBtnVariantKeys,
	variantMap: actionBtnVariantMap,
	merge(recipe) {
		return mergeRecipes(this, recipe);
	},
	splitVariantProps(props) {
		return splitProps(props, actionBtnVariantKeys);
	},
	getVariantProps: actionBtnFn.getVariantProps
});
//#endregion
//#region styled-system/recipes/action-buttons.mjs
var actionButtonsFn = /* @__PURE__ */ createRecipe("action-buttons", {}, []);
var actionButtonsVariantMap = {};
var actionButtonsVariantKeys = Object.keys(actionButtonsVariantMap);
var actionButtons = /* @__PURE__ */ Object.assign(memo$1(actionButtonsFn.recipeFn), {
	__recipe__: true,
	__name__: "actionButtons",
	__getCompoundVariantCss__: actionButtonsFn.__getCompoundVariantCss__,
	raw: (props) => props,
	variantKeys: actionButtonsVariantKeys,
	variantMap: actionButtonsVariantMap,
	merge(recipe) {
		return mergeRecipes(this, recipe);
	},
	splitVariantProps(props) {
		return splitProps(props, actionButtonsVariantKeys);
	},
	getVariantProps: actionButtonsFn.getVariantProps
});
//#endregion
//#region styled-system/recipes/compound-node.mjs
var compoundNodeFn = /* @__PURE__ */ createRecipe("likec4-compound-node", {
	"isTransparent": false,
	"inverseColor": false,
	"borderStyle": "none"
}, []);
var compoundNodeVariantMap = {
	"isTransparent": ["false", "true"],
	"inverseColor": ["true", "false"],
	"borderStyle": [
		"solid",
		"dashed",
		"dotted",
		"none"
	]
};
var compoundNodeVariantKeys = Object.keys(compoundNodeVariantMap);
var compoundNode = /* @__PURE__ */ Object.assign(memo$1(compoundNodeFn.recipeFn), {
	__recipe__: true,
	__name__: "compoundNode",
	__getCompoundVariantCss__: compoundNodeFn.__getCompoundVariantCss__,
	raw: (props) => props,
	variantKeys: compoundNodeVariantKeys,
	variantMap: compoundNodeVariantMap,
	merge(recipe) {
		return mergeRecipes(this, recipe);
	},
	splitVariantProps(props) {
		return splitProps(props, compoundNodeVariantKeys);
	},
	getVariantProps: compoundNodeFn.getVariantProps
});
//#endregion
//#region styled-system/recipes/edge-action-btn.mjs
var edgeActionBtnFn = /* @__PURE__ */ createRecipe("likec4-edge-action-btn", {}, []);
var edgeActionBtnVariantMap = {};
var edgeActionBtnVariantKeys = Object.keys(edgeActionBtnVariantMap);
var edgeActionBtn = /* @__PURE__ */ Object.assign(memo$1(edgeActionBtnFn.recipeFn), {
	__recipe__: true,
	__name__: "edgeActionBtn",
	__getCompoundVariantCss__: edgeActionBtnFn.__getCompoundVariantCss__,
	raw: (props) => props,
	variantKeys: edgeActionBtnVariantKeys,
	variantMap: edgeActionBtnVariantMap,
	merge(recipe) {
		return mergeRecipes(this, recipe);
	},
	splitVariantProps(props) {
		return splitProps(props, edgeActionBtnVariantKeys);
	},
	getVariantProps: edgeActionBtnFn.getVariantProps
});
//#endregion
//#region styled-system/recipes/edge-label.mjs
var edgeLabelFn = /* @__PURE__ */ createRecipe("likec4-edge-label", {
	"pointerEvents": "all",
	"isStepEdge": false,
	"cursor": "default"
}, []);
var edgeLabelVariantMap = {
	"pointerEvents": ["none", "all"],
	"cursor": ["pointer", "default"],
	"isStepEdge": ["false", "true"]
};
var edgeLabelVariantKeys = Object.keys(edgeLabelVariantMap);
var edgeLabel = /* @__PURE__ */ Object.assign(memo$1(edgeLabelFn.recipeFn), {
	__recipe__: true,
	__name__: "edgeLabel",
	__getCompoundVariantCss__: edgeLabelFn.__getCompoundVariantCss__,
	raw: (props) => props,
	variantKeys: edgeLabelVariantKeys,
	variantMap: edgeLabelVariantMap,
	merge(recipe) {
		return mergeRecipes(this, recipe);
	},
	splitVariantProps(props) {
		return splitProps(props, edgeLabelVariantKeys);
	},
	getVariantProps: edgeLabelFn.getVariantProps
});
//#endregion
//#region styled-system/recipes/edge-path.mjs
var edgePathDefaultVariants = {};
var edgePathCompoundVariants = [];
var edgePathSlotFns = /* @__PURE__ */ [
	["path", "likec4-edge__path"],
	["pathBg", "likec4-edge__pathBg"],
	["markersCtx", "likec4-edge__markersCtx"],
	["middlePoint", "likec4-edge__middlePoint"]
].map(([slotName, slotKey]) => [slotName, createRecipe(slotKey, edgePathDefaultVariants, getSlotCompoundVariant(edgePathCompoundVariants, slotName))]);
var edgePathFn = memo$1((props = {}) => {
	return Object.fromEntries(edgePathSlotFns.map(([slotName, slotFn]) => [slotName, slotFn.recipeFn(props)]));
});
var edgePathVariantKeys = [];
var edgePath = /* @__PURE__ */ Object.assign(edgePathFn, {
	__recipe__: false,
	__name__: "edgePath",
	raw: (props) => props,
	classNameMap: {},
	variantKeys: edgePathVariantKeys,
	variantMap: {},
	splitVariantProps(props) {
		return splitProps(props, edgePathVariantKeys);
	},
	getVariantProps: /* @__PURE__ */ __name((variants) => ({
		...edgePathDefaultVariants,
		...compact(variants)
	}), "getVariantProps")
});
//#endregion
//#region styled-system/recipes/element-node.mjs
var elementNodeFn = /* @__PURE__ */ createRecipe("likec4-element-node", {}, []);
var elementNodeVariantMap = {};
var elementNodeVariantKeys = Object.keys(elementNodeVariantMap);
var elementNode = /* @__PURE__ */ Object.assign(memo$1(elementNodeFn.recipeFn), {
	__recipe__: true,
	__name__: "elementNode",
	__getCompoundVariantCss__: elementNodeFn.__getCompoundVariantCss__,
	raw: (props) => props,
	variantKeys: elementNodeVariantKeys,
	variantMap: elementNodeVariantMap,
	merge(recipe) {
		return mergeRecipes(this, recipe);
	},
	splitVariantProps(props) {
		return splitProps(props, elementNodeVariantKeys);
	},
	getVariantProps: elementNodeFn.getVariantProps
});
//#endregion
//#region styled-system/recipes/element-node-data.mjs
var elementNodeDataFn = /* @__PURE__ */ createRecipe("likec4-element-node-data", {
	"iconPosition": "left",
	"withIconColor": false,
	"withIconBlend": false,
	"sizing": "auto"
}, []);
var elementNodeDataVariantMap = {
	"iconPosition": [
		"left",
		"right",
		"top",
		"bottom"
	],
	"withIconColor": ["true", "false"],
	"withIconBlend": ["true", "false"],
	"sizing": ["fixed", "auto"]
};
var elementNodeDataVariantKeys = Object.keys(elementNodeDataVariantMap);
var elementNodeData = /* @__PURE__ */ Object.assign(memo$1(elementNodeDataFn.recipeFn), {
	__recipe__: true,
	__name__: "elementNodeData",
	__getCompoundVariantCss__: elementNodeDataFn.__getCompoundVariantCss__,
	raw: (props) => props,
	variantKeys: elementNodeDataVariantKeys,
	variantMap: elementNodeDataVariantMap,
	merge(recipe) {
		return mergeRecipes(this, recipe);
	},
	splitVariantProps(props) {
		return splitProps(props, elementNodeDataVariantKeys);
	},
	getVariantProps: elementNodeDataFn.getVariantProps
});
//#endregion
//#region styled-system/recipes/element-shape-recipe.mjs
var elementShapeRecipeFn = /* @__PURE__ */ createRecipe("likec4-element-shape", {
	"withBorder": false,
	"withOutline": false
}, [{
	"shapetype": "html",
	"withBorder": true,
	"css": {
		"&": {
			"borderStyle": "solid",
			"borderWidth": "3px",
			"borderColor": "var(--likec4-palette-stroke)",
			"--likec4-outline-size": "6px"
		},
		"& .likec4-shape-outline": { "borderRadius": "10px" }
	}
}]);
var elementShapeRecipeVariantMap = {
	"shapetype": ["html", "svg"],
	"withBorder": ["true", "false"],
	"withOutline": ["true", "false"]
};
var elementShapeRecipeVariantKeys = Object.keys(elementShapeRecipeVariantMap);
var elementShapeRecipe = /* @__PURE__ */ Object.assign(memo$1(elementShapeRecipeFn.recipeFn), {
	__recipe__: true,
	__name__: "elementShapeRecipe",
	__getCompoundVariantCss__: elementShapeRecipeFn.__getCompoundVariantCss__,
	raw: (props) => props,
	variantKeys: elementShapeRecipeVariantKeys,
	variantMap: elementShapeRecipeVariantMap,
	merge(recipe) {
		return mergeRecipes(this, recipe);
	},
	splitVariantProps(props) {
		return splitProps(props, elementShapeRecipeVariantKeys);
	},
	getVariantProps: elementShapeRecipeFn.getVariantProps
});
//#endregion
//#region styled-system/recipes/empty-box.mjs
var emptyBoxFn = /* @__PURE__ */ createRecipe("empty-box", {}, []);
var emptyBoxVariantMap = { "fullsize": ["true"] };
var emptyBoxVariantKeys = Object.keys(emptyBoxVariantMap);
var emptyBox = /* @__PURE__ */ Object.assign(memo$1(emptyBoxFn.recipeFn), {
	__recipe__: true,
	__name__: "emptyBox",
	__getCompoundVariantCss__: emptyBoxFn.__getCompoundVariantCss__,
	raw: (props) => props,
	variantKeys: emptyBoxVariantKeys,
	variantMap: emptyBoxVariantMap,
	merge(recipe) {
		return mergeRecipes(this, recipe);
	},
	splitVariantProps(props) {
		return splitProps(props, emptyBoxVariantKeys);
	},
	getVariantProps: emptyBoxFn.getVariantProps
});
//#endregion
//#region styled-system/recipes/floating-window.mjs
var floatingWindowFn = /* @__PURE__ */ createRecipe("likec4-floating-window", {}, []);
var floatingWindowVariantMap = {};
var floatingWindowVariantKeys = Object.keys(floatingWindowVariantMap);
var floatingWindow = /* @__PURE__ */ Object.assign(memo$1(floatingWindowFn.recipeFn), {
	__recipe__: true,
	__name__: "floatingWindow",
	__getCompoundVariantCss__: floatingWindowFn.__getCompoundVariantCss__,
	raw: (props) => props,
	variantKeys: floatingWindowVariantKeys,
	variantMap: floatingWindowVariantMap,
	merge(recipe) {
		return mergeRecipes(this, recipe);
	},
	splitVariantProps(props) {
		return splitProps(props, floatingWindowVariantKeys);
	},
	getVariantProps: floatingWindowFn.getVariantProps
});
//#endregion
//#region styled-system/recipes/likec4tag.mjs
var likec4tagFn = /* @__PURE__ */ createRecipe("likec4-tag", {}, []);
var likec4tagVariantMap = {};
var likec4tagVariantKeys = Object.keys(likec4tagVariantMap);
var likec4tag = /* @__PURE__ */ Object.assign(memo$1(likec4tagFn.recipeFn), {
	__recipe__: true,
	__name__: "likec4tag",
	__getCompoundVariantCss__: likec4tagFn.__getCompoundVariantCss__,
	raw: (props) => props,
	variantKeys: likec4tagVariantKeys,
	variantMap: likec4tagVariantMap,
	merge(recipe) {
		return mergeRecipes(this, recipe);
	},
	splitVariantProps(props) {
		return splitProps(props, likec4tagVariantKeys);
	},
	getVariantProps: likec4tagFn.getVariantProps
});
//#endregion
//#region styled-system/recipes/markdown-block.mjs
var markdownBlockFn = /* @__PURE__ */ createRecipe("likec4-markdown-block", {
	"uselikec4palette": false,
	"value": "markdown"
}, []);
var markdownBlockVariantMap = {
	"uselikec4palette": ["true", "false"],
	"value": ["markdown", "plaintext"]
};
var markdownBlockVariantKeys = Object.keys(markdownBlockVariantMap);
var markdownBlock = /* @__PURE__ */ Object.assign(memo$1(markdownBlockFn.recipeFn), {
	__recipe__: true,
	__name__: "markdownBlock",
	__getCompoundVariantCss__: markdownBlockFn.__getCompoundVariantCss__,
	raw: (props) => props,
	variantKeys: markdownBlockVariantKeys,
	variantMap: markdownBlockVariantMap,
	merge(recipe) {
		return mergeRecipes(this, recipe);
	},
	splitVariantProps(props) {
		return splitProps(props, markdownBlockVariantKeys);
	},
	getVariantProps: markdownBlockFn.getVariantProps
});
//#endregion
//#region styled-system/recipes/navigation-panel-action-icon.mjs
var navigationPanelActionIconFn = /* @__PURE__ */ createRecipe("likec4-navigation-panel-icon", {
	"variant": "default",
	"type": "default"
}, [{
	"type": "warning",
	"variant": "filled",
	"css": { "backgroundColor": {
		"base": "likec4.panel.action.warning.bg",
		"_hover": "likec4.panel.action.warning.bg.hover"
	} }
}]);
var navigationPanelActionIconVariantMap = {
	"variant": ["default", "filled"],
	"type": ["default", "warning"]
};
var navigationPanelActionIconVariantKeys = Object.keys(navigationPanelActionIconVariantMap);
var navigationPanelActionIcon = /* @__PURE__ */ Object.assign(memo$1(navigationPanelActionIconFn.recipeFn), {
	__recipe__: true,
	__name__: "navigationPanelActionIcon",
	__getCompoundVariantCss__: navigationPanelActionIconFn.__getCompoundVariantCss__,
	raw: (props) => props,
	variantKeys: navigationPanelActionIconVariantKeys,
	variantMap: navigationPanelActionIconVariantMap,
	merge(recipe) {
		return mergeRecipes(this, recipe);
	},
	splitVariantProps(props) {
		return splitProps(props, navigationPanelActionIconVariantKeys);
	},
	getVariantProps: navigationPanelActionIconFn.getVariantProps
});
//#endregion
//#region styled-system/recipes/node-notes.mjs
var nodeNotesFn = /* @__PURE__ */ createRecipe("likec4-node-notes", { "opened": false }, []);
var nodeNotesVariantMap = { "opened": ["false", "true"] };
var nodeNotesVariantKeys = Object.keys(nodeNotesVariantMap);
var nodeNotes = /* @__PURE__ */ Object.assign(memo$1(nodeNotesFn.recipeFn), {
	__recipe__: true,
	__name__: "nodeNotes",
	__getCompoundVariantCss__: nodeNotesFn.__getCompoundVariantCss__,
	raw: (props) => props,
	variantKeys: nodeNotesVariantKeys,
	variantMap: nodeNotesVariantMap,
	merge(recipe) {
		return mergeRecipes(this, recipe);
	},
	splitVariantProps(props) {
		return splitProps(props, nodeNotesVariantKeys);
	},
	getVariantProps: nodeNotesFn.getVariantProps
});
//#endregion
//#region styled-system/recipes/overlay.mjs
var overlayFn = /* @__PURE__ */ createRecipe("likec4-overlay", {
	"fullscreen": false,
	"withBackdrop": true
}, []);
var overlayVariantMap = {
	"fullscreen": ["false", "true"],
	"withBackdrop": ["false", "true"]
};
var overlayVariantKeys = Object.keys(overlayVariantMap);
var overlay = /* @__PURE__ */ Object.assign(memo$1(overlayFn.recipeFn), {
	__recipe__: true,
	__name__: "overlay",
	__getCompoundVariantCss__: overlayFn.__getCompoundVariantCss__,
	raw: (props) => props,
	variantKeys: overlayVariantKeys,
	variantMap: overlayVariantMap,
	merge(recipe) {
		return mergeRecipes(this, recipe);
	},
	splitVariantProps(props) {
		return splitProps(props, overlayVariantKeys);
	},
	getVariantProps: overlayFn.getVariantProps
});
//#endregion
//#region styled-system/recipes/navigation-link.mjs
var navigationLinkDefaultVariants = { "truncateLabel": false };
var navigationLinkCompoundVariants = [];
var navigationLinkSlotFns = /* @__PURE__ */ [
	["root", "likec4-navlink__root"],
	["body", "likec4-navlink__body"],
	["section", "likec4-navlink__section"],
	["label", "likec4-navlink__label"],
	["description", "likec4-navlink__description"]
].map(([slotName, slotKey]) => [slotName, createRecipe(slotKey, navigationLinkDefaultVariants, getSlotCompoundVariant(navigationLinkCompoundVariants, slotName))]);
var navigationLinkFn = memo$1((props = {}) => {
	return Object.fromEntries(navigationLinkSlotFns.map(([slotName, slotFn]) => [slotName, slotFn.recipeFn(props)]));
});
var navigationLinkVariantKeys = ["truncateLabel"];
var navigationLink = /* @__PURE__ */ Object.assign(navigationLinkFn, {
	__recipe__: false,
	__name__: "navigationLink",
	raw: (props) => props,
	classNameMap: {},
	variantKeys: navigationLinkVariantKeys,
	variantMap: { "truncateLabel": ["true", "false"] },
	splitVariantProps(props) {
		return splitProps(props, navigationLinkVariantKeys);
	},
	getVariantProps: /* @__PURE__ */ __name((variants) => ({
		...navigationLinkDefaultVariants,
		...compact(variants)
	}), "getVariantProps")
});
//#endregion
//#region styled-system/recipes/navigation-panel.mjs
var navigationPanelDefaultVariants = {
	"size": "md",
	"panelPosition": "left"
};
var navigationPanelCompoundVariants = [];
var navigationPanelSlotFns = /* @__PURE__ */ [
	["root", "likec4-navigation-panel__root"],
	["body", "likec4-navigation-panel__body"],
	["logo", "likec4-navigation-panel__logo"],
	["label", "likec4-navigation-panel__label"],
	["dropdown", "likec4-navigation-panel__dropdown"]
].map(([slotName, slotKey]) => [slotName, createRecipe(slotKey, navigationPanelDefaultVariants, getSlotCompoundVariant(navigationPanelCompoundVariants, slotName))]);
var navigationPanelFn = memo$1((props = {}) => {
	return Object.fromEntries(navigationPanelSlotFns.map(([slotName, slotFn]) => [slotName, slotFn.recipeFn(props)]));
});
var navigationPanelVariantKeys = ["size", "panelPosition"];
var getVariantProps = (variants) => ({
	...navigationPanelDefaultVariants,
	...compact(variants)
});
var navigationPanel = /* @__PURE__ */ Object.assign(navigationPanelFn, {
	__recipe__: false,
	__name__: "navigationPanel",
	raw: (props) => props,
	classNameMap: {},
	variantKeys: navigationPanelVariantKeys,
	variantMap: {
		"size": ["md", "lg"],
		"panelPosition": ["left", "right"]
	},
	splitVariantProps(props) {
		return splitProps(props, navigationPanelVariantKeys);
	},
	getVariantProps
});
//#endregion
export { createStyleContext as A, HStack as C, Flex as D, vstack as E, cva as F, cx as I, css as L, isCssProperty as M, token as N, flex as O, sva as P, container as S, VStack as T, actionButtons as _, navigationPanelActionIcon as a, txt as b, floatingWindow as c, elementNodeData as d, elementNode as f, compoundNode as g, edgeActionBtn as h, nodeNotes as i, styled as j, Box as k, emptyBox as l, edgeLabel as m, navigationLink as n, markdownBlock as o, edgePath as p, overlay as r, likec4tag as s, navigationPanel as t, elementShapeRecipe as u, actionBtn as v, hstack as w, bleed as x, Txt as y };
