import "../src/chunks/rolldown-runtime.mjs";
import { $likec4model, IconRenderer as RenderIcon } from "likec4:single-project";
import { LikeC4ModelProvider, LikeC4View, ReactLikeC4, useLikeC4Model, useLikeC4View } from "likec4:react";
//#region codegen/react.tsx
var likec4model = $likec4model.get();
function isLikeC4ViewId(value) {
	return value != null && typeof value === "string" && !!likec4model.findView(value);
}
//#endregion
export { LikeC4ModelProvider, LikeC4View, ReactLikeC4, RenderIcon, isLikeC4ViewId, likec4model, useLikeC4Model, useLikeC4View };
