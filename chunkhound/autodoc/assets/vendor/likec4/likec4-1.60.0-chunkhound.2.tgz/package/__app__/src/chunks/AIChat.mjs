import { i as __name } from "./rolldown-runtime.mjs";
import { c as useNavigate } from "./libs/@tanstack.mjs";
import { A as r, E as IconSparkles, M as t$1, O as t, T as IconPlayerStopFilled, _ as useStore, b as useTimeoutEffect, c as Markdown, m as useDiagram, t as useCurrentProject } from "./hooks.mjs";
import { At as ScrollAreaAutosize, C as Modal, F as Textarea, H as FloatingWindow, Z as Button, _t as CloseButton, b as Notification, et as Badge, nn as useLocalStorage, r as Title, v as Tooltip, vt as ActionIcon } from "./libs/@mantine.mjs";
import { C as HStack, L as css, T as VStack, y as Txt } from "./styled-system.mjs";
import { i as nanostoresGlobal, n as onMount, r as atom } from "./libs/nanostores.mjs";
import { i as m, m as AnimatePresence } from "./libs/framer.mjs";
import { a as literal, c as string, i as discriminatedUnion, n as array, o as number, r as boolean, s as object, t as _enum } from "./libs/zod.mjs";
import { a as toolDefinition, i as fetchServerSentEvents, n as useChat$1, r as clientTools, t as ChatMessage$1 } from "./libs/@tanstack-ai.mjs";
import { createContext, use, useEffect, useRef, useState } from "react";
import { c } from "react/compiler-runtime";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { RichText, nonNullable, nonexhaustive } from "@likec4/core";
import { ElementShapes } from "@likec4/core/styles";
import { AIAdapter } from "likec4:rpc";
//#region ../../node_modules/.pnpm/nanostores@1.5.5/node_modules/nanostores/computed/index.js
var computedStore = (stores, cb, batched) => {
	if (!Array.isArray(stores)) stores = [stores];
	let previousArgs;
	let currentEpoch;
	let set = () => {
		if (currentEpoch === nanostoresGlobal.epoch) return;
		currentEpoch = nanostoresGlobal.epoch;
		let args = stores.map(($store) => $store.get());
		if (!previousArgs?.every((arg, i) => stores[i].eq(arg, args[i]))) {
			previousArgs = args;
			let value = cb(...args);
			if (value && value.then && value.t) value.then((asyncValue) => {
				if (previousArgs === args) $computed.set(asyncValue);
			});
			else {
				$computed.set(value);
				currentEpoch = nanostoresGlobal.epoch;
			}
		}
	};
	let $computed = /* @__PURE__ */ atom();
	let get = $computed.get;
	$computed.get = () => {
		set();
		return get();
	};
	let timer;
	let run = batched ? () => {
		clearTimeout(timer);
		timer = setTimeout(set);
	} : set;
	onMount($computed, () => {
		let unbinds = stores.map(($store) => $store.listen(run));
		set();
		return () => {
			for (let unbind of unbinds) unbind();
		};
	});
	return $computed;
};
var batched = /* @__NO_SIDE_EFFECTS__ */ (stores, fn) => computedStore(stores, fn, true);
//#endregion
//#region src/aichat/ChatContext.tsx
var ChatContext = createContext(null);
function useChatContext() {
	return nonNullable(use(ChatContext), "useChatContext: ChatProvider is not provided");
}
//#endregion
//#region src/aichat/ChatInput.tsx
function ChatInput() {
	const $ = c(22);
	const { sendMessage, isLoading, messages, clear, stop } = useChatContext();
	const [value, setValue] = useState("");
	const inputRef = useRef(null);
	let t0;
	if ($[0] !== isLoading || $[1] !== sendMessage || $[2] !== value) {
		t0 = () => {
			if (!value.trim() || isLoading) return;
			sendMessage(value);
			setValue("");
		};
		$[0] = isLoading;
		$[1] = sendMessage;
		$[2] = value;
		$[3] = t0;
	} else t0 = $[3];
	const handleSubmit = t0;
	let t1;
	if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = (e) => setValue(e.target.value);
		$[4] = t1;
	} else t1 = $[4];
	let t2;
	if ($[5] !== handleSubmit) {
		t2 = (e_0) => {
			if (e_0.key === "Enter" && !e_0.shiftKey && !e_0.ctrlKey && !e_0.metaKey) {
				e_0.preventDefault();
				handleSubmit();
			}
		};
		$[5] = handleSubmit;
		$[6] = t2;
	} else t2 = $[6];
	let t3;
	if ($[7] !== isLoading || $[8] !== t2 || $[9] !== value) {
		t3 = /* @__PURE__ */ jsx(Textarea, {
			flex: 1,
			className: "chat-input",
			placeholder: "Your question...",
			value,
			onChange: t1,
			onKeyDown: t2,
			disabled: isLoading,
			ref: inputRef,
			loading: isLoading,
			autosize: true,
			minRows: 1
		});
		$[7] = isLoading;
		$[8] = t2;
		$[9] = value;
		$[10] = t3;
	} else t3 = $[10];
	let t4;
	if ($[11] !== clear || $[12] !== isLoading || $[13] !== messages.length) {
		t4 = messages.length > 0 && !isLoading && /* @__PURE__ */ jsx(Button, {
			size: "sm",
			color: "red",
			variant: "light",
			onClick: () => clear(),
			children: "Clear"
		});
		$[11] = clear;
		$[12] = isLoading;
		$[13] = messages.length;
		$[14] = t4;
	} else t4 = $[14];
	let t5;
	if ($[15] !== isLoading || $[16] !== stop) {
		t5 = isLoading && /* @__PURE__ */ jsx(ActionIcon, {
			color: "red",
			variant: "light",
			onClick: () => stop(),
			children: /* @__PURE__ */ jsx(IconPlayerStopFilled, {})
		});
		$[15] = isLoading;
		$[16] = stop;
		$[17] = t5;
	} else t5 = $[17];
	let t6;
	if ($[18] !== t3 || $[19] !== t4 || $[20] !== t5) {
		t6 = /* @__PURE__ */ jsxs(HStack, { children: [
			t3,
			t4,
			t5
		] });
		$[18] = t3;
		$[19] = t4;
		$[20] = t5;
		$[21] = t6;
	} else t6 = $[21];
	return t6;
}
//#endregion
//#region src/aichat/ChatMessage.tsx
function ChatMessages() {
	const $ = c(7);
	const { messages, error } = useChatContext();
	let t0;
	if ($[0] !== messages) {
		t0 = messages.map(_temp);
		$[0] = messages;
		$[1] = t0;
	} else t0 = $[1];
	let t1;
	if ($[2] !== error) {
		t1 = error && /* @__PURE__ */ jsx(Notification, {
			styles: { icon: { alignSelf: "flex-start" } },
			color: "red",
			title: "Oops, something went wrong",
			withCloseButton: false,
			children: /* @__PURE__ */ jsxs(Txt, {
				fontSize: "sm",
				fontFamily: "mono",
				whiteSpace: "pre",
				my: "xs",
				children: [error.message, error.stack && "\n" + error.stack]
			})
		});
		$[2] = error;
		$[3] = t1;
	} else t1 = $[3];
	let t2;
	if ($[4] !== t0 || $[5] !== t1) {
		t2 = /* @__PURE__ */ jsxs(Fragment$1, { children: [t0, t1] });
		$[4] = t0;
		$[5] = t1;
		$[6] = t2;
	} else t2 = $[6];
	return t2;
}
function _temp(message) {
	return /* @__PURE__ */ jsx(ChatMessage, { message }, message.id);
}
var ChatMessage = (t0) => {
	const $ = c(4);
	const { message } = t0;
	const role = message.role;
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = css({
			color: "text.bright",
			alignSelf: "flex-end",
			paddingInline: "2",
			paddingBlock: "1",
			marginInlineEnd: "2",
			rounded: "sm",
			backgroundColor: "surface.hover",
			whiteSpace: "pre-wrap"
		});
		$[0] = t1;
	} else t1 = $[0];
	const t2 = role === "user" ? UserMessageTextPart : MarkdownTextPart;
	let t3;
	if ($[1] !== message || $[2] !== t2) {
		t3 = /* @__PURE__ */ jsx(ChatMessage$1, {
			message,
			userClassName: t1,
			textPartRenderer: t2
		});
		$[1] = message;
		$[2] = t2;
		$[3] = t3;
	} else t3 = $[3];
	return t3;
};
var UserMessageTextPart = (t0) => {
	const $ = c(2);
	const { content } = t0;
	let t1;
	if ($[0] !== content) {
		t1 = /* @__PURE__ */ jsx(Fragment$1, { children: content });
		$[0] = content;
		$[1] = t1;
	} else t1 = $[1];
	return t1;
};
var MarkdownTextPart = (t0) => {
	const $ = c(4);
	const { content } = t0;
	let t1;
	if ($[0] !== content) {
		t1 = RichText.from({ md: content });
		$[0] = content;
		$[1] = t1;
	} else t1 = $[1];
	let t2;
	if ($[2] !== t1) {
		t2 = /* @__PURE__ */ jsx(Markdown, {
			textScale: .95,
			value: t1
		});
		$[2] = t1;
		$[3] = t2;
	} else t2 = $[3];
	return t2;
};
//#endregion
//#region src/aichat/semantic-layout-log-state.ts
var $log = /* @__PURE__ */ atom("");
var $status = /* @__PURE__ */ atom("closed");
var $state = /* @__PURE__ */ batched([$log, $status], (log, status) => ({
	log,
	status
}));
function useSemanticLayoutLog() {
	return useStore($state);
}
function closeSemanticLayoutLog() {
	$status.set("closed");
	$log.set("");
}
//#endregion
//#region src/aichat/SemanticLayoutLog.tsx
/**
* Modal that shows the log of the semantic layout application
* (For internal debugging purposes)
*/
function SemanticLayoutLog() {
	const $ = c(6);
	const { log, status } = useSemanticLayoutLog();
	if (status === "closed") return null;
	const closable = status === "completed";
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = /* @__PURE__ */ jsx(Title, {
			order: 4,
			children: "Semantic Layout"
		});
		$[0] = t0;
	} else t0 = $[0];
	const t1 = log || "Waiting for response...";
	let t2;
	if ($[1] !== t1) {
		t2 = /* @__PURE__ */ jsx(Txt, {
			whiteSpace: "pre-wrap",
			children: t1
		});
		$[1] = t1;
		$[2] = t2;
	} else t2 = $[2];
	let t3;
	if ($[3] !== closable || $[4] !== t2) {
		t3 = /* @__PURE__ */ jsx(Modal, {
			size: "xl",
			opened: true,
			onClose: closeSemanticLayoutLog,
			closeOnEscape: closable,
			withCloseButton: closable,
			closeOnClickOutside: closable,
			title: t0,
			children: t2
		});
		$[3] = closable;
		$[4] = t2;
		$[5] = t3;
	} else t3 = $[5];
	return t3;
}
//#endregion
//#region ../vite-plugin/src/ai/tools.ts
var nodeSchema = object({
	id: string().meta({ description: "Node ID" }),
	title: string(),
	shape: _enum(ElementShapes),
	color: string().meta({ description: "Node color, from theme or custom" }),
	icon: string().nullish(),
	parentId: string().nullish().meta({ description: "Parent node ID (if node is nested)" }),
	children: array(string()).nullish().meta({ description: "Nested node IDs (if node is compound)" }),
	x: number(),
	y: number(),
	width: number(),
	height: number(),
	modelFqn: string().nullish().meta({ description: "Model element FQN (if node has reference)" })
});
var readUiStateDef = toolDefinition({
	name: "read_ui",
	description: "Read current UI state. Use arguments to include additional data.",
	needsApproval: false,
	inputSchema: object({
		selectedNode: boolean().default(false).meta({ description: "Include selected node (if any)" }),
		nodes: boolean().default(false).meta({ description: "Include all nodes from the view" })
	}),
	outputSchema: object({
		projectId: string(),
		editMode: boolean().meta({ description: "Whether the UI is in edit mode" }),
		view: object({
			id: string(),
			title: string(),
			type: _enum([
				"element",
				"deployment",
				"dynamic"
			]).meta({ description: "Type of the current view" })
		}).meta({ description: "Current view" }),
		nodes: array(nodeSchema).nullish(),
		selectedNode: nodeSchema.nullish()
	})
});
var focusCommand = object({
	type: literal("focus"),
	elementId: string().meta({ description: "Element ID (FQN)" })
}).meta({ description: "Focus UI on an element by its FQN" });
var fitViewCommand = object({ type: literal("fitview") }).meta({ description: "Zoom out to fit all elements in the viewport, and clear any selection/focus" });
var updateUiStateDef = toolDefinition({
	name: "update_ui",
	description: "Update UI state by executing a command.",
	needsApproval: false,
	inputSchema: object({ command: discriminatedUnion("type", [focusCommand, fitViewCommand]) }),
	outputSchema: object({})
});
var navigateToDef = toolDefinition({
	name: "navigate_to",
	description: "Navigates UI to another view",
	needsApproval: false,
	inputSchema: object({ viewId: string().meta({ description: "View ID" }) }),
	outputSchema: object({})
});
//#endregion
//#region ../../node_modules/.pnpm/superjson@2.2.6/node_modules/superjson/dist/double-indexed-kv.js
var DoubleIndexedKV = class {
	constructor() {
		this.keyToValue = /* @__PURE__ */ new Map();
		this.valueToKey = /* @__PURE__ */ new Map();
	}
	set(key, value) {
		this.keyToValue.set(key, value);
		this.valueToKey.set(value, key);
	}
	getByKey(key) {
		return this.keyToValue.get(key);
	}
	getByValue(value) {
		return this.valueToKey.get(value);
	}
	clear() {
		this.keyToValue.clear();
		this.valueToKey.clear();
	}
};
//#endregion
//#region ../../node_modules/.pnpm/superjson@2.2.6/node_modules/superjson/dist/registry.js
var Registry = class {
	constructor(generateIdentifier) {
		this.generateIdentifier = generateIdentifier;
		this.kv = new DoubleIndexedKV();
	}
	register(value, identifier) {
		if (this.kv.getByValue(value)) return;
		if (!identifier) identifier = this.generateIdentifier(value);
		this.kv.set(identifier, value);
	}
	clear() {
		this.kv.clear();
	}
	getIdentifier(value) {
		return this.kv.getByValue(value);
	}
	getValue(identifier) {
		return this.kv.getByKey(identifier);
	}
};
//#endregion
//#region ../../node_modules/.pnpm/superjson@2.2.6/node_modules/superjson/dist/class-registry.js
var ClassRegistry = class extends Registry {
	constructor() {
		super((c) => c.name);
		this.classToAllowedProps = /* @__PURE__ */ new Map();
	}
	register(value, options) {
		if (typeof options === "object") {
			if (options.allowProps) this.classToAllowedProps.set(value, options.allowProps);
			super.register(value, options.identifier);
		} else super.register(value, options);
	}
	getAllowedProps(value) {
		return this.classToAllowedProps.get(value);
	}
};
//#endregion
//#region ../../node_modules/.pnpm/superjson@2.2.6/node_modules/superjson/dist/util.js
function valuesOfObj(record) {
	if ("values" in Object) return Object.values(record);
	const values = [];
	for (const key in record) if (record.hasOwnProperty(key)) values.push(record[key]);
	return values;
}
function find(record, predicate) {
	const values = valuesOfObj(record);
	if ("find" in values) return values.find(predicate);
	const valuesNotNever = values;
	for (let i = 0; i < valuesNotNever.length; i++) {
		const value = valuesNotNever[i];
		if (predicate(value)) return value;
	}
}
function forEach(record, run) {
	Object.entries(record).forEach(([key, value]) => run(value, key));
}
function includes(arr, value) {
	return arr.indexOf(value) !== -1;
}
function findArr(record, predicate) {
	for (let i = 0; i < record.length; i++) {
		const value = record[i];
		if (predicate(value)) return value;
	}
}
//#endregion
//#region ../../node_modules/.pnpm/superjson@2.2.6/node_modules/superjson/dist/custom-transformer-registry.js
var CustomTransformerRegistry = class {
	constructor() {
		this.transfomers = {};
	}
	register(transformer) {
		this.transfomers[transformer.name] = transformer;
	}
	findApplicable(v) {
		return find(this.transfomers, (transformer) => transformer.isApplicable(v));
	}
	findByName(name) {
		return this.transfomers[name];
	}
};
//#endregion
//#region ../../node_modules/.pnpm/superjson@2.2.6/node_modules/superjson/dist/is.js
var getType$1 = /* @__PURE__ */ __name((payload) => Object.prototype.toString.call(payload).slice(8, -1), "getType");
var isUndefined = (payload) => typeof payload === "undefined";
var isNull = (payload) => payload === null;
var isPlainObject$1 = /* @__PURE__ */ __name((payload) => {
	if (typeof payload !== "object" || payload === null) return false;
	if (payload === Object.prototype) return false;
	if (Object.getPrototypeOf(payload) === null) return true;
	return Object.getPrototypeOf(payload) === Object.prototype;
}, "isPlainObject");
var isEmptyObject = (payload) => isPlainObject$1(payload) && Object.keys(payload).length === 0;
var isArray$1 = /* @__PURE__ */ __name((payload) => Array.isArray(payload), "isArray");
var isString = (payload) => typeof payload === "string";
var isNumber = (payload) => typeof payload === "number" && !isNaN(payload);
var isBoolean = (payload) => typeof payload === "boolean";
var isRegExp = (payload) => payload instanceof RegExp;
var isMap = (payload) => payload instanceof Map;
var isSet = (payload) => payload instanceof Set;
var isSymbol = (payload) => getType$1(payload) === "Symbol";
var isDate = (payload) => payload instanceof Date && !isNaN(payload.valueOf());
var isError = (payload) => payload instanceof Error;
var isNaNValue = (payload) => typeof payload === "number" && isNaN(payload);
var isPrimitive = (payload) => isBoolean(payload) || isNull(payload) || isUndefined(payload) || isNumber(payload) || isString(payload) || isSymbol(payload);
var isBigint = (payload) => typeof payload === "bigint";
var isInfinite = (payload) => payload === Infinity || payload === -Infinity;
var isTypedArray = (payload) => ArrayBuffer.isView(payload) && !(payload instanceof DataView);
var isURL = (payload) => payload instanceof URL;
//#endregion
//#region ../../node_modules/.pnpm/superjson@2.2.6/node_modules/superjson/dist/pathstringifier.js
var escapeKey = (key) => key.replace(/\\/g, "\\\\").replace(/\./g, "\\.");
var stringifyPath = (path) => path.map(String).map(escapeKey).join(".");
var parsePath = (string, legacyPaths) => {
	const result = [];
	let segment = "";
	for (let i = 0; i < string.length; i++) {
		let char = string.charAt(i);
		if (!legacyPaths && char === "\\") {
			const escaped = string.charAt(i + 1);
			if (escaped === "\\") {
				segment += "\\";
				i++;
				continue;
			} else if (escaped !== ".") throw Error("invalid path");
		}
		if (char === "\\" && string.charAt(i + 1) === ".") {
			segment += ".";
			i++;
			continue;
		}
		if (char === ".") {
			result.push(segment);
			segment = "";
			continue;
		}
		segment += char;
	}
	const lastSegment = segment;
	result.push(lastSegment);
	return result;
};
//#endregion
//#region ../../node_modules/.pnpm/superjson@2.2.6/node_modules/superjson/dist/transformer.js
function simpleTransformation(isApplicable, annotation, transform, untransform) {
	return {
		isApplicable,
		annotation,
		transform,
		untransform
	};
}
var simpleRules = [
	simpleTransformation(isUndefined, "undefined", () => null, () => void 0),
	simpleTransformation(isBigint, "bigint", (v) => v.toString(), (v) => {
		if (typeof BigInt !== "undefined") return BigInt(v);
		console.error("Please add a BigInt polyfill.");
		return v;
	}),
	simpleTransformation(isDate, "Date", (v) => v.toISOString(), (v) => new Date(v)),
	simpleTransformation(isError, "Error", (v, superJson) => {
		const baseError = {
			name: v.name,
			message: v.message
		};
		if ("cause" in v) baseError.cause = v.cause;
		superJson.allowedErrorProps.forEach((prop) => {
			baseError[prop] = v[prop];
		});
		return baseError;
	}, (v, superJson) => {
		const e = new Error(v.message, { cause: v.cause });
		e.name = v.name;
		e.stack = v.stack;
		superJson.allowedErrorProps.forEach((prop) => {
			e[prop] = v[prop];
		});
		return e;
	}),
	simpleTransformation(isRegExp, "regexp", (v) => "" + v, (regex) => {
		const body = regex.slice(1, regex.lastIndexOf("/"));
		const flags = regex.slice(regex.lastIndexOf("/") + 1);
		return new RegExp(body, flags);
	}),
	simpleTransformation(isSet, "set", (v) => [...v.values()], (v) => new Set(v)),
	simpleTransformation(isMap, "map", (v) => [...v.entries()], (v) => new Map(v)),
	simpleTransformation((v) => isNaNValue(v) || isInfinite(v), "number", (v) => {
		if (isNaNValue(v)) return "NaN";
		if (v > 0) return "Infinity";
		else return "-Infinity";
	}, Number),
	simpleTransformation((v) => v === 0 && 1 / v === -Infinity, "number", () => {
		return "-0";
	}, Number),
	simpleTransformation(isURL, "URL", (v) => v.toString(), (v) => new URL(v))
];
function compositeTransformation(isApplicable, annotation, transform, untransform) {
	return {
		isApplicable,
		annotation,
		transform,
		untransform
	};
}
var symbolRule = compositeTransformation((s, superJson) => {
	if (isSymbol(s)) return !!superJson.symbolRegistry.getIdentifier(s);
	return false;
}, (s, superJson) => {
	return ["symbol", superJson.symbolRegistry.getIdentifier(s)];
}, (v) => v.description, (_, a, superJson) => {
	const value = superJson.symbolRegistry.getValue(a[1]);
	if (!value) throw new Error("Trying to deserialize unknown symbol");
	return value;
});
var constructorToName = [
	Int8Array,
	Uint8Array,
	Int16Array,
	Uint16Array,
	Int32Array,
	Uint32Array,
	Float32Array,
	Float64Array,
	Uint8ClampedArray
].reduce((obj, ctor) => {
	obj[ctor.name] = ctor;
	return obj;
}, {});
var typedArrayRule = compositeTransformation(isTypedArray, (v) => ["typed-array", v.constructor.name], (v) => [...v], (v, a) => {
	const ctor = constructorToName[a[1]];
	if (!ctor) throw new Error("Trying to deserialize unknown typed array");
	return new ctor(v);
});
function isInstanceOfRegisteredClass(potentialClass, superJson) {
	if (potentialClass?.constructor) return !!superJson.classRegistry.getIdentifier(potentialClass.constructor);
	return false;
}
var classRule = compositeTransformation(isInstanceOfRegisteredClass, (clazz, superJson) => {
	return ["class", superJson.classRegistry.getIdentifier(clazz.constructor)];
}, (clazz, superJson) => {
	const allowedProps = superJson.classRegistry.getAllowedProps(clazz.constructor);
	if (!allowedProps) return { ...clazz };
	const result = {};
	allowedProps.forEach((prop) => {
		result[prop] = clazz[prop];
	});
	return result;
}, (v, a, superJson) => {
	const clazz = superJson.classRegistry.getValue(a[1]);
	if (!clazz) throw new Error(`Trying to deserialize unknown class '${a[1]}' - check https://github.com/blitz-js/superjson/issues/116#issuecomment-773996564`);
	return Object.assign(Object.create(clazz.prototype), v);
});
var customRule = compositeTransformation((value, superJson) => {
	return !!superJson.customTransformerRegistry.findApplicable(value);
}, (value, superJson) => {
	return ["custom", superJson.customTransformerRegistry.findApplicable(value).name];
}, (value, superJson) => {
	return superJson.customTransformerRegistry.findApplicable(value).serialize(value);
}, (v, a, superJson) => {
	const transformer = superJson.customTransformerRegistry.findByName(a[1]);
	if (!transformer) throw new Error("Trying to deserialize unknown custom value");
	return transformer.deserialize(v);
});
var compositeRules = [
	classRule,
	symbolRule,
	customRule,
	typedArrayRule
];
var transformValue = (value, superJson) => {
	const applicableCompositeRule = findArr(compositeRules, (rule) => rule.isApplicable(value, superJson));
	if (applicableCompositeRule) return {
		value: applicableCompositeRule.transform(value, superJson),
		type: applicableCompositeRule.annotation(value, superJson)
	};
	const applicableSimpleRule = findArr(simpleRules, (rule) => rule.isApplicable(value, superJson));
	if (applicableSimpleRule) return {
		value: applicableSimpleRule.transform(value, superJson),
		type: applicableSimpleRule.annotation
	};
};
var simpleRulesByAnnotation = {};
simpleRules.forEach((rule) => {
	simpleRulesByAnnotation[rule.annotation] = rule;
});
var untransformValue = (json, type, superJson) => {
	if (isArray$1(type)) switch (type[0]) {
		case "symbol": return symbolRule.untransform(json, type, superJson);
		case "class": return classRule.untransform(json, type, superJson);
		case "custom": return customRule.untransform(json, type, superJson);
		case "typed-array": return typedArrayRule.untransform(json, type, superJson);
		default: throw new Error("Unknown transformation: " + type);
	}
	else {
		const transformation = simpleRulesByAnnotation[type];
		if (!transformation) throw new Error("Unknown transformation: " + type);
		return transformation.untransform(json, superJson);
	}
};
//#endregion
//#region ../../node_modules/.pnpm/superjson@2.2.6/node_modules/superjson/dist/accessDeep.js
var getNthKey = (value, n) => {
	if (n > value.size) throw new Error("index out of bounds");
	const keys = value.keys();
	while (n > 0) {
		keys.next();
		n--;
	}
	return keys.next().value;
};
function validatePath(path) {
	if (includes(path, "__proto__")) throw new Error("__proto__ is not allowed as a property");
	if (includes(path, "prototype")) throw new Error("prototype is not allowed as a property");
	if (includes(path, "constructor")) throw new Error("constructor is not allowed as a property");
}
var getDeep = (object, path) => {
	validatePath(path);
	for (let i = 0; i < path.length; i++) {
		const key = path[i];
		if (isSet(object)) object = getNthKey(object, +key);
		else if (isMap(object)) {
			const row = +key;
			const type = +path[++i] === 0 ? "key" : "value";
			const keyOfRow = getNthKey(object, row);
			switch (type) {
				case "key":
					object = keyOfRow;
					break;
				case "value": object = object.get(keyOfRow);
			}
		} else object = object[key];
	}
	return object;
};
var setDeep = (object, path, mapper) => {
	validatePath(path);
	if (path.length === 0) return mapper(object);
	let parent = object;
	for (let i = 0; i < path.length - 1; i++) {
		const key = path[i];
		if (isArray$1(parent)) {
			const index = +key;
			parent = parent[index];
		} else if (isPlainObject$1(parent)) parent = parent[key];
		else if (isSet(parent)) {
			const row = +key;
			parent = getNthKey(parent, row);
		} else if (isMap(parent)) {
			if (i === path.length - 2) break;
			const row = +key;
			const type = +path[++i] === 0 ? "key" : "value";
			const keyOfRow = getNthKey(parent, row);
			switch (type) {
				case "key":
					parent = keyOfRow;
					break;
				case "value": parent = parent.get(keyOfRow);
			}
		}
	}
	const lastKey = path[path.length - 1];
	if (isArray$1(parent)) parent[+lastKey] = mapper(parent[+lastKey]);
	else if (isPlainObject$1(parent)) parent[lastKey] = mapper(parent[lastKey]);
	if (isSet(parent)) {
		const oldValue = getNthKey(parent, +lastKey);
		const newValue = mapper(oldValue);
		if (oldValue !== newValue) {
			parent.delete(oldValue);
			parent.add(newValue);
		}
	}
	if (isMap(parent)) {
		const row = +path[path.length - 2];
		const keyToRow = getNthKey(parent, row);
		switch (+lastKey === 0 ? "key" : "value") {
			case "key": {
				const newKey = mapper(keyToRow);
				parent.set(newKey, parent.get(keyToRow));
				if (newKey !== keyToRow) parent.delete(keyToRow);
				break;
			}
			case "value": parent.set(keyToRow, mapper(parent.get(keyToRow)));
		}
	}
	return object;
};
//#endregion
//#region ../../node_modules/.pnpm/superjson@2.2.6/node_modules/superjson/dist/plainer.js
var enableLegacyPaths = (version) => version < 1;
function traverse(tree, walker, version, origin = []) {
	if (!tree) return;
	const legacyPaths = enableLegacyPaths(version);
	if (!isArray$1(tree)) {
		forEach(tree, (subtree, key) => traverse(subtree, walker, version, [...origin, ...parsePath(key, legacyPaths)]));
		return;
	}
	const [nodeValue, children] = tree;
	if (children) forEach(children, (child, key) => {
		traverse(child, walker, version, [...origin, ...parsePath(key, legacyPaths)]);
	});
	walker(nodeValue, origin);
}
function applyValueAnnotations(plain, annotations, version, superJson) {
	traverse(annotations, (type, path) => {
		plain = setDeep(plain, path, (v) => untransformValue(v, type, superJson));
	}, version);
	return plain;
}
function applyReferentialEqualityAnnotations(plain, annotations, version) {
	const legacyPaths = enableLegacyPaths(version);
	function apply(identicalPaths, path) {
		const object = getDeep(plain, parsePath(path, legacyPaths));
		identicalPaths.map((path) => parsePath(path, legacyPaths)).forEach((identicalObjectPath) => {
			plain = setDeep(plain, identicalObjectPath, () => object);
		});
	}
	if (isArray$1(annotations)) {
		const [root, other] = annotations;
		root.forEach((identicalPath) => {
			plain = setDeep(plain, parsePath(identicalPath, legacyPaths), () => plain);
		});
		if (other) forEach(other, apply);
	} else forEach(annotations, apply);
	return plain;
}
var isDeep = (object, superJson) => isPlainObject$1(object) || isArray$1(object) || isMap(object) || isSet(object) || isError(object) || isInstanceOfRegisteredClass(object, superJson);
function addIdentity(object, path, identities) {
	const existingSet = identities.get(object);
	if (existingSet) existingSet.push(path);
	else identities.set(object, [path]);
}
function generateReferentialEqualityAnnotations(identitites, dedupe) {
	const result = {};
	let rootEqualityPaths = void 0;
	identitites.forEach((paths) => {
		if (paths.length <= 1) return;
		if (!dedupe) paths = paths.map((path) => path.map(String)).sort((a, b) => a.length - b.length);
		const [representativePath, ...identicalPaths] = paths;
		if (representativePath.length === 0) rootEqualityPaths = identicalPaths.map(stringifyPath);
		else result[stringifyPath(representativePath)] = identicalPaths.map(stringifyPath);
	});
	if (rootEqualityPaths) {
		if (isEmptyObject(result)) return [rootEqualityPaths];
		else return [rootEqualityPaths, result];
	} else return isEmptyObject(result) ? void 0 : result;
}
var walker = (object, identities, superJson, dedupe, path = [], objectsInThisPath = [], seenObjects = /* @__PURE__ */ new Map()) => {
	const primitive = isPrimitive(object);
	if (!primitive) {
		addIdentity(object, path, identities);
		const seen = seenObjects.get(object);
		if (seen) return dedupe ? { transformedValue: null } : seen;
	}
	if (!isDeep(object, superJson)) {
		const transformed = transformValue(object, superJson);
		const result = transformed ? {
			transformedValue: transformed.value,
			annotations: [transformed.type]
		} : { transformedValue: object };
		if (!primitive) seenObjects.set(object, result);
		return result;
	}
	if (includes(objectsInThisPath, object)) return { transformedValue: null };
	const transformationResult = transformValue(object, superJson);
	const transformed = transformationResult?.value ?? object;
	const transformedValue = isArray$1(transformed) ? [] : {};
	const innerAnnotations = {};
	forEach(transformed, (value, index) => {
		if (index === "__proto__" || index === "constructor" || index === "prototype") throw new Error(`Detected property ${index}. This is a prototype pollution risk, please remove it from your object.`);
		const recursiveResult = walker(value, identities, superJson, dedupe, [...path, index], [...objectsInThisPath, object], seenObjects);
		transformedValue[index] = recursiveResult.transformedValue;
		if (isArray$1(recursiveResult.annotations)) innerAnnotations[escapeKey(index)] = recursiveResult.annotations;
		else if (isPlainObject$1(recursiveResult.annotations)) forEach(recursiveResult.annotations, (tree, key) => {
			innerAnnotations[escapeKey(index) + "." + key] = tree;
		});
	});
	const result = isEmptyObject(innerAnnotations) ? {
		transformedValue,
		annotations: !!transformationResult ? [transformationResult.type] : void 0
	} : {
		transformedValue,
		annotations: !!transformationResult ? [transformationResult.type, innerAnnotations] : innerAnnotations
	};
	if (!primitive) seenObjects.set(object, result);
	return result;
};
//#endregion
//#region ../../node_modules/.pnpm/is-what@5.5.0/node_modules/is-what/dist/getType.js
/** Returns the object type of the given payload */
function getType(payload) {
	return Object.prototype.toString.call(payload).slice(8, -1);
}
//#endregion
//#region ../../node_modules/.pnpm/is-what@5.5.0/node_modules/is-what/dist/isArray.js
/** Returns whether the payload is an array */
function isArray(payload) {
	return getType(payload) === "Array";
}
//#endregion
//#region ../../node_modules/.pnpm/is-what@5.5.0/node_modules/is-what/dist/isPlainObject.js
/**
* Returns whether the payload is a plain JavaScript object (excluding special classes or objects
* with other prototypes)
*/
function isPlainObject(payload) {
	if (getType(payload) !== "Object") return false;
	const prototype = Object.getPrototypeOf(payload);
	return !!prototype && prototype.constructor === Object && prototype === Object.prototype;
}
//#endregion
//#region ../../node_modules/.pnpm/copy-anything@4.0.5/node_modules/copy-anything/dist/index.js
function assignProp(carry, key, newVal, originalObject, includeNonenumerable) {
	const propType = {}.propertyIsEnumerable.call(originalObject, key) ? "enumerable" : "nonenumerable";
	if (propType === "enumerable") carry[key] = newVal;
	if (includeNonenumerable && propType === "nonenumerable") Object.defineProperty(carry, key, {
		value: newVal,
		enumerable: false,
		writable: true,
		configurable: true
	});
}
/**
* Copy (clone) an object and all its props recursively to get rid of any prop referenced of the
* original object. Arrays are also cloned, however objects inside arrays are still linked.
*
* @param target Target can be anything
* @param [options={}] See type {@link Options} for more details.
*
*   - `{ props: ['key1'] }` will only copy the `key1` property. When using this you will need to cast
*       the return type manually (in order to keep the TS implementation in here simple I didn't
*       built a complex auto resolved type for those few cases people want to use this option)
*   - `{ nonenumerable: true }` will copy all non-enumerable properties. Default is `{}`
*
* @returns The target with replaced values
*/
function copy(target, options = {}) {
	if (isArray(target)) return target.map((item) => copy(item, options));
	if (!isPlainObject(target)) return target;
	const props = Object.getOwnPropertyNames(target);
	const symbols = Object.getOwnPropertySymbols(target);
	return [...props, ...symbols].reduce((carry, key) => {
		if (key === "__proto__") return carry;
		if (isArray(options.props) && !options.props.includes(key)) return carry;
		const val = target[key];
		assignProp(carry, key, copy(val, options), target, options.nonenumerable);
		return carry;
	}, {});
}
//#endregion
//#region ../../node_modules/.pnpm/superjson@2.2.6/node_modules/superjson/dist/index.js
var SuperJSON = class {
	/**
	* @param dedupeReferentialEqualities  If true, SuperJSON will make sure only one instance of referentially equal objects are serialized and the rest are replaced with `null`.
	*/
	constructor({ dedupe = false } = {}) {
		this.classRegistry = new ClassRegistry();
		this.symbolRegistry = new Registry((s) => s.description ?? "");
		this.customTransformerRegistry = new CustomTransformerRegistry();
		this.allowedErrorProps = [];
		this.dedupe = dedupe;
	}
	serialize(object) {
		const identities = /* @__PURE__ */ new Map();
		const output = walker(object, identities, this, this.dedupe);
		const res = { json: output.transformedValue };
		if (output.annotations) res.meta = {
			...res.meta,
			values: output.annotations
		};
		const equalityAnnotations = generateReferentialEqualityAnnotations(identities, this.dedupe);
		if (equalityAnnotations) res.meta = {
			...res.meta,
			referentialEqualities: equalityAnnotations
		};
		if (res.meta) res.meta.v = 1;
		return res;
	}
	deserialize(payload, options) {
		const { json, meta } = payload;
		let result = options?.inPlace ? json : copy(json);
		if (meta?.values) result = applyValueAnnotations(result, meta.values, meta.v ?? 0, this);
		if (meta?.referentialEqualities) result = applyReferentialEqualityAnnotations(result, meta.referentialEqualities, meta.v ?? 0);
		return result;
	}
	stringify(object) {
		return JSON.stringify(this.serialize(object));
	}
	parse(string) {
		return this.deserialize(JSON.parse(string), { inPlace: true });
	}
	registerClass(v, options) {
		this.classRegistry.register(v, options);
	}
	registerSymbol(v, identifier) {
		this.symbolRegistry.register(v, identifier);
	}
	registerCustom(transformer, name) {
		this.customTransformerRegistry.register({
			name,
			...transformer
		});
	}
	allowErrorProps(...props) {
		this.allowedErrorProps.push(...props);
	}
};
SuperJSON.defaultInstance = new SuperJSON();
SuperJSON.serialize = SuperJSON.defaultInstance.serialize.bind(SuperJSON.defaultInstance);
SuperJSON.deserialize = SuperJSON.defaultInstance.deserialize.bind(SuperJSON.defaultInstance);
SuperJSON.stringify = SuperJSON.defaultInstance.stringify.bind(SuperJSON.defaultInstance);
SuperJSON.parse = SuperJSON.defaultInstance.parse.bind(SuperJSON.defaultInstance);
SuperJSON.registerClass = SuperJSON.defaultInstance.registerClass.bind(SuperJSON.defaultInstance);
SuperJSON.registerSymbol = SuperJSON.defaultInstance.registerSymbol.bind(SuperJSON.defaultInstance);
SuperJSON.registerCustom = SuperJSON.defaultInstance.registerCustom.bind(SuperJSON.defaultInstance);
SuperJSON.allowErrorProps = SuperJSON.defaultInstance.allowErrorProps.bind(SuperJSON.defaultInstance);
SuperJSON.serialize;
SuperJSON.deserialize;
var stringify = SuperJSON.stringify;
var parse = SuperJSON.parse;
SuperJSON.registerClass;
SuperJSON.registerCustom;
SuperJSON.registerSymbol;
SuperJSON.allowErrorProps;
//#endregion
//#region src/aichat/useChat.tsx
function mapToNodeData(storeState) {
	return ({ id, data, ...node }) => {
		let icon = data.icon ?? void 0;
		if (icon === "none") icon = void 0;
		let children = storeState.parentLookup.get(id)?.values().map((child) => child.id).toArray();
		return {
			id,
			title: data.title,
			shape: data.shape,
			color: data.color,
			icon,
			parentId: node.parentId,
			children,
			x: data.x,
			y: data.y,
			width: node.measured?.width ?? node.width ?? node.initialWidth ?? 0,
			height: node.measured?.height ?? node.height ?? node.initialHeight ?? 0,
			..."modelFqn" in data && data.modelFqn && { modelFqn: data.modelFqn }
		};
	};
}
function useChatTools() {
	const $ = c(11);
	const { id: projectId } = useCurrentProject();
	const navigate = useNavigate();
	const diagram = useDiagram();
	let t0;
	if ($[0] !== diagram || $[1] !== navigate || $[2] !== projectId) {
		let t1;
		if ($[4] !== navigate) {
			t1 = (t2) => {
				const { viewId } = t2;
				navigate({
					to: "./",
					params: (current) => ({
						...current,
						viewId
					})
				});
				return {};
			};
			$[4] = navigate;
			$[5] = t1;
		} else t1 = $[5];
		let t2;
		if ($[6] !== diagram || $[7] !== projectId) {
			t2 = (params) => {
				const { view, focusedNode, xynodes, xystore, toggledFeatures, features } = diagram.getContext();
				const isReadOnly = toggledFeatures.enableReadOnly ?? features.enableReadOnly;
				const toNodeData = mapToNodeData(xystore.getState());
				const nodes = params.nodes === true && t(xynodes, toNodeData) || void 0;
				const selectedNode = params.selectedNode === true && t$1(xynodes, r((n) => !!n.selected || n.id === focusedNode), (n_0) => n_0 ? toNodeData(n_0) : void 0);
				return {
					projectId,
					editMode: !isReadOnly,
					view: {
						id: view.id,
						title: view.title ?? "",
						type: view._type
					},
					...nodes && { nodes },
					...selectedNode && { selectedNode }
				};
			};
			$[6] = diagram;
			$[7] = projectId;
			$[8] = t2;
		} else t2 = $[8];
		let t3;
		if ($[9] !== diagram) {
			t3 = (t4) => {
				const { command } = t4;
				bb50: switch (command.type) {
					case "focus":
						diagram.focusOnElement(command.elementId);
						break bb50;
					case "fitview":
						diagram.fitDiagram();
						break bb50;
					default: nonexhaustive(command);
				}
				return {};
			};
			$[9] = diagram;
			$[10] = t3;
		} else t3 = $[10];
		t0 = clientTools(navigateToDef.client(t1), readUiStateDef.client(t2), updateUiStateDef.client(t3));
		$[0] = diagram;
		$[1] = navigate;
		$[2] = projectId;
		$[3] = t0;
	} else t0 = $[3];
	return t0;
}
var storage$1 = {
	key: "likec4.ai.chat.messages",
	read() {
		try {
			const stored = sessionStorage.getItem(this.key);
			if (!stored) return [];
			return parse(stored);
		} catch {
			return [];
		}
	},
	write(messages) {
		try {
			if (messages.length === 0) {
				sessionStorage.removeItem(this.key);
				return;
			}
			sessionStorage.setItem(this.key, stringify(messages));
		} catch {}
	}
};
function useChat(options) {
	const $ = c(7);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = {
			connection: fetchServerSentEvents("/__likec4_ai"),
			initialMessages: storage$1.read()
		};
		$[0] = t0;
	} else t0 = $[0];
	const memoProps = t0;
	const t1 = useChatTools();
	let t2;
	if ($[1] !== options || $[2] !== t1) {
		t2 = {
			...memoProps,
			...options,
			tools: t1
		};
		$[1] = options;
		$[2] = t1;
		$[3] = t2;
	} else t2 = $[3];
	const chat = useChat$1(t2);
	let t3;
	let t4;
	if ($[4] !== chat.messages) {
		t3 = () => {
			storage$1.write(chat.messages);
		};
		t4 = [chat.messages];
		$[4] = chat.messages;
		$[5] = t3;
		$[6] = t4;
	} else {
		t3 = $[5];
		t4 = $[6];
	}
	useEffect(t3, t4);
	return chat;
}
//#endregion
//#region src/aichat/AIChat.tsx
var storage = {
	key: "likec4.ai.chat.position",
	read() {
		try {
			const stored = localStorage.getItem(this.key);
			if (!stored) return null;
			return JSON.parse(stored);
		} catch {
			return null;
		}
	},
	write(position) {
		try {
			if (position === null) {
				localStorage.removeItem(this.key);
				return position;
			}
			localStorage.setItem(this.key, JSON.stringify(position));
		} catch {}
		return position;
	}
};
function AIChatComponent() {
	const initialPosition = useRef(null);
	if (!initialPosition.current) initialPosition.current = storage.read() ?? {
		right: 16,
		bottom: 100
	};
	const onPositionChange = (pos) => {
		initialPosition.current = storage.write({
			left: pos.x,
			top: pos.y
		});
	};
	const [isCollapsed, setCollapsed] = useLocalStorage({
		key: "likec4.ai.chat.collapsed",
		defaultValue: true
	});
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsxs(AnimatePresence, { children: [!isCollapsed && /* @__PURE__ */ jsx(FloatingWindow, {
		w: 300,
		pos: "fixed",
		className: css({
			rounded: "md",
			padding: "xs",
			shadow: "md",
			layerStyle: "likec4.panel"
		}),
		constrainToViewport: true,
		constrainOffset: 8,
		excludeDragHandleSelector: ".chat-input",
		initialPosition: initialPosition.current,
		onPositionChange,
		children: /* @__PURE__ */ jsx(AIChatWindowContent, { onClose: () => setCollapsed(true) })
	}), isCollapsed && /* @__PURE__ */ jsx(m.div, {
		initial: {
			opacity: .1,
			translateX: "10%"
		},
		animate: {
			opacity: 1,
			translateX: 0
		},
		exit: {
			translateX: "50%",
			opacity: .1
		},
		style: {
			position: "fixed",
			right: 8,
			bottom: 60,
			zIndex: 1e3
		},
		children: /* @__PURE__ */ jsx(Tooltip, {
			label: "Show AI Assistant",
			color: "dark",
			fz: "xs",
			children: /* @__PURE__ */ jsx(ActionIcon, {
				size: "lg",
				variant: "gradient",
				onClick: () => setCollapsed(false),
				children: /* @__PURE__ */ jsx(IconSparkles, { stroke: 1.5 })
			})
		})
	}, "collapsed")] }), /* @__PURE__ */ jsx(SemanticLayoutLog, {})] });
}
function AIChatWindowContent(t0) {
	const $ = c(15);
	const { onClose } = t0;
	const scrollAnchorRef = useRef(null);
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = () => {
			scrollAnchorRef.current?.scrollIntoView();
		};
		$[0] = t1;
	} else t1 = $[0];
	const scrollIntoView = t1;
	let t2;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = () => {
			scrollIntoView();
		};
		$[1] = t2;
	} else t2 = $[1];
	useTimeoutEffect(t2, 100);
	let t3;
	if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
		t3 = { onChunk: scrollIntoView };
		$[2] = t3;
	} else t3 = $[2];
	const chat = useChat(t3);
	let t4;
	if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
		t4 = /* @__PURE__ */ jsxs(HStack, { children: [/* @__PURE__ */ jsx(Txt, {
			textStyle: "likec4.panel",
			nouserselect: true,
			children: "AI Assistant"
		}), /* @__PURE__ */ jsx(Badge, {
			size: "xs",
			radius: "sm",
			variant: "light",
			children: AIAdapter
		})] });
		$[3] = t4;
	} else t4 = $[3];
	let t5;
	if ($[4] !== onClose) {
		t5 = /* @__PURE__ */ jsxs(HStack, {
			cursor: "move",
			justify: "space-between",
			children: [t4, /* @__PURE__ */ jsx(CloseButton, {
				size: "sm",
				onClick: (e) => {
					e.stopPropagation();
					onClose();
				}
			})]
		});
		$[4] = onClose;
		$[5] = t5;
	} else t5 = $[5];
	let t6;
	if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
		t6 = { content: css({ display: "contents" }) };
		$[6] = t6;
	} else t6 = $[6];
	let t7;
	if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
		t7 = /* @__PURE__ */ jsx(ChatMessages, {});
		$[7] = t7;
	} else t7 = $[7];
	let t8;
	let t9;
	if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
		t8 = /* @__PURE__ */ jsx(ScrollAreaAutosize, {
			scrollbars: "y",
			w: "100%",
			flex: 1,
			mih: 250,
			mah: 350,
			classNames: t6,
			children: /* @__PURE__ */ jsxs(VStack, { children: [t7, /* @__PURE__ */ jsx("div", {
				ref: scrollAnchorRef,
				style: { height: 2 }
			})] })
		});
		t9 = /* @__PURE__ */ jsx(ChatInput, {});
		$[8] = t8;
		$[9] = t9;
	} else {
		t8 = $[8];
		t9 = $[9];
	}
	let t10;
	if ($[10] !== t5) {
		t10 = /* @__PURE__ */ jsxs(VStack, {
			w: "100%",
			children: [
				t5,
				t8,
				t9
			]
		});
		$[10] = t5;
		$[11] = t10;
	} else t10 = $[11];
	let t11;
	if ($[12] !== chat || $[13] !== t10) {
		t11 = /* @__PURE__ */ jsx(ChatContext, {
			value: chat,
			children: t10
		});
		$[12] = chat;
		$[13] = t10;
		$[14] = t11;
	} else t11 = $[14];
	return t11;
}
//#endregion
export { AIChatComponent as default };
