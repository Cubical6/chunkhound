import { i as __name } from "./rolldown-runtime.mjs";
import { i as useMatches, u as useParams } from "./libs/@tanstack.mjs";
import { ut as Text } from "./libs/@mantine.mjs";
import { I as cx, k as Box, o as markdownBlock } from "./styled-system.mjs";
import { n as shallowEqual, t as deepEqual } from "./libs/fast-equals.mjs";
import { t as listenKeys } from "./libs/nanostores.mjs";
import { b as invariant } from "./libs/framer.mjs";
import { n as useSelector } from "./libs/@xstate/react.mjs";
import { createContext, createElement, forwardRef, use, useCallback, useContext, useEffect, useLayoutEffect, useMemo, useRef, useState, useSyncExternalStore } from "react";
import { c } from "react/compiler-runtime";
import { jsx } from "react/jsx-runtime";
import { useLikeC4Projects } from "likec4:projects";
//#region ../../node_modules/.pnpm/remeda@2.51.0/node_modules/remeda/dist/lazyDataLastImpl--3B10z3s.js
function e$2(e, t, n) {
	let r = (n) => e(n, ...t);
	return n === void 0 ? r : Object.assign(r, {
		lazy: n,
		lazyArgs: t
	});
}
__name(e$2, "e");
//#endregion
//#region ../../node_modules/.pnpm/remeda@2.51.0/node_modules/remeda/dist/purry.js
function t$3(t, n, r) {
	let i = t.length - n.length;
	if (i === 0) return t(...n);
	if (i === 1) return e$2(t, n, r);
	throw Error(`Wrong number of arguments`);
}
__name(t$3, "t");
//#endregion
//#region ../../node_modules/.pnpm/remeda@2.51.0/node_modules/remeda/dist/utilityEvaluators-IxVD3t2o.js
var t$2 = {
	done: !1,
	hasNext: !1
};
var r$3 = /* @__PURE__ */ __name((e) => ({
	hasNext: !0,
	next: e,
	done: !1
}), "r");
//#endregion
//#region ../../node_modules/.pnpm/remeda@2.51.0/node_modules/remeda/dist/pipe.js
function t$1(e, ...t) {
	let i = e;
	let o = t.map((e) => `lazy` in e ? {
		lazyEvaluator: e.lazy(...e.lazyArgs),
		isSingle: e.lazy.single ?? !1,
		index: 0,
		items: []
	} : void 0);
	let s = 0;
	for (; s < t.length;) {
		if (o[s] === void 0 || !a$1(i)) {
			let e = t[s];
			i = e(i), s += 1;
			continue;
		}
		let e = n$1(o, s), c = r$2(i, e), { isSingle: l } = e.at(-1);
		i = l ? c[0] : c, s += e.length;
	}
	return i;
}
__name(t$1, "t");
function n$1(e, t) {
	let n = [];
	for (let r = t; r < e.length; r++) {
		let t = e[r];
		if (t === void 0 || (n.push(t), t.isSingle)) break;
	}
	return n;
}
__name(n$1, "n");
function r$2(e, t) {
	let n = [];
	for (let r of e) if (i$1(r, n, t)) break;
	return n;
}
__name(r$2, "r");
function i$1(t, n, r) {
	if (r.length === 0) return n.push(t), !1;
	let a = t;
	let o = t$2;
	let s = !1;
	for (let [e, { items: t, lazyEvaluator: c }] of r.entries()) if (t.push(a), o = c(a, t.length - 1, t), o.done && (s = !0), o.hasNext) {
		if (o.hasMany ?? !1) {
			for (let t of o.next) if (i$1(t, n, r.slice(e + 1))) return !0;
			return s;
		}
		a = o.next;
	} else break;
	return o.hasNext && n.push(a), s;
}
__name(i$1, "i");
function a$1(e) {
	return typeof e == `string` || typeof e == `object` && !!e && Symbol.iterator in e;
}
__name(a$1, "a");
//#endregion
//#region ../../node_modules/.pnpm/remeda@2.51.0/node_modules/remeda/dist/toSingle-DiQSixar.js
var e$1 = /* @__PURE__ */ __name((e) => Object.assign(e, { single: !0 }), "e");
//#endregion
//#region ../../node_modules/.pnpm/remeda@2.51.0/node_modules/remeda/dist/find.js
function r$1(...t) {
	return t$3(i, t, e$1(a));
}
__name(r$1, "r");
var i = (e, t) => e.find(t);
var a = (e) => (n, r, i) => e(n, r, i) ? {
	done: !0,
	hasNext: !0,
	next: n
} : t$2;
//#endregion
//#region ../../node_modules/.pnpm/remeda@2.51.0/node_modules/remeda/dist/isFunction.js
var e = (e) => typeof e == `function`;
//#endregion
//#region ../../node_modules/.pnpm/remeda@2.51.0/node_modules/remeda/dist/map.js
function t(...t) {
	return t$3(n, t, r);
}
var n = (e, t) => e.map(t);
var r = (e) => (t, n, r) => ({
	done: !1,
	hasNext: !0,
	next: e(t, n, r)
});
//#endregion
//#region ../../node_modules/.pnpm/@tabler+icons-react@3.49.0_react@19.3.0/node_modules/@tabler/icons-react/dist/esm/defaultAttributes.mjs
/**
* @license @tabler/icons-react v3.49.0 - MIT
*
* This source code is licensed under the MIT license.
* See the LICENSE file in the root directory of this source tree.
*/
var defaultAttributes = {
	outline: {
		xmlns: "http://www.w3.org/2000/svg",
		width: 24,
		height: 24,
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: 2,
		strokeLinecap: "round",
		strokeLinejoin: "round"
	},
	filled: {
		xmlns: "http://www.w3.org/2000/svg",
		width: 24,
		height: 24,
		viewBox: "0 0 24 24",
		fill: "currentColor",
		stroke: "none"
	}
};
//#endregion
//#region ../../node_modules/.pnpm/@tabler+icons-react@3.49.0_react@19.3.0/node_modules/@tabler/icons-react/dist/esm/createReactComponent.mjs
/**
* @license @tabler/icons-react v3.49.0 - MIT
*
* This source code is licensed under the MIT license.
* See the LICENSE file in the root directory of this source tree.
*/
var createReactComponent = (type, iconName, iconNamePascal, iconNode) => {
	const Component = forwardRef(({ color = "currentColor", size = 24, stroke = 2, title, className, children, ...rest }, ref) => createElement("svg", {
		ref,
		...defaultAttributes[type],
		width: size,
		height: size,
		className: [
			`tabler-icon`,
			`tabler-icon-${iconName}`,
			className
		].filter(Boolean).join(" "),
		...type === "filled" ? { fill: color } : {
			strokeWidth: stroke,
			stroke: color
		},
		...rest
	}, [
		title && createElement("title", { key: "svg-title" }, title),
		...iconNode.map(([tag, attrs]) => createElement(tag, attrs)),
		...Array.isArray(children) ? children : [children]
	]));
	Component.displayName = `${iconNamePascal}`;
	return Component;
};
/**
* @license @tabler/icons-react v3.49.0 - MIT
*
* This source code is licensed under the MIT license.
* See the LICENSE file in the root directory of this source tree.
*/
var IconSparkles = createReactComponent("outline", "sparkles", "Sparkles", [["path", {
	"d": "M16 18a2 2 0 0 1 2 2a2 2 0 0 1 2 -2a2 2 0 0 1 -2 -2a2 2 0 0 1 -2 2m0 -12a2 2 0 0 1 2 2a2 2 0 0 1 2 -2a2 2 0 0 1 -2 -2a2 2 0 0 1 -2 2m-7 12a6 6 0 0 1 6 -6a6 6 0 0 1 -6 -6a6 6 0 0 1 -6 6a6 6 0 0 1 6 6",
	"key": "svg-0"
}]]);
/**
* @license @tabler/icons-react v3.49.0 - MIT
*
* This source code is licensed under the MIT license.
* See the LICENSE file in the root directory of this source tree.
*/
var IconPlayerStopFilled = createReactComponent("filled", "player-stop-filled", "PlayerStopFilled", [["path", {
	"d": "M17 4h-10a3 3 0 0 0 -3 3v10a3 3 0 0 0 3 3h10a3 3 0 0 0 3 -3v-10a3 3 0 0 0 -3 -3z",
	"key": "svg-0"
}]]);
//#endregion
//#region ../../node_modules/.pnpm/@react-hookz+web@25.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/@react-hookz/web/dist/useSyncedRef/index.js
/**
* Like `useRef`, but it returns immutable ref that contains actual value.
*
* @param value
*/
function useSyncedRef(value) {
	const ref = useRef(value);
	ref.current = value;
	return useMemo(() => Object.freeze({ get current() {
		return ref.current;
	} }), []);
}
//#endregion
//#region ../../node_modules/.pnpm/@react-hookz+web@25.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/@react-hookz/web/dist/util/const.js
var noop$1 = /* @__PURE__ */ __name(() => {}, "noop");
var isBrowser = typeof globalThis !== "undefined" && typeof navigator !== "undefined" && typeof document !== "undefined";
//#endregion
//#region ../../node_modules/.pnpm/@react-hookz+web@25.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/@react-hookz/web/dist/util/misc.js
var basicDepsComparator = (d1, d2) => {
	if (d1 === d2) return true;
	if (d1.length !== d2.length) return false;
	for (const [i, element] of d1.entries()) if (element !== d2[i]) return false;
	return true;
};
//#endregion
//#region ../../node_modules/.pnpm/@react-hookz+web@25.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/@react-hookz/web/dist/useCustomCompareEffect/index.js
/**
* Like `useEffect` but uses provided comparator function to validate dependency changes.
*
* @param callback Function that will be passed to the underlying effect hook.
* @param deps Dependency list like the one passed to `useEffect`.
* @param comparator Function that compares two dependency arrays,
* and returns `true` if they're equal.
* @param effectHook Effect hook that will be used to run
* `callback`. Must match the type signature of `useEffect`, meaning that the `callback` should be
* placed as the first argument and the dependency list as second.
* @param effectHookRestArgs Extra arguments that are passed to the `effectHook`
* after the `callback` and the dependency list.
*/
function useCustomCompareEffect(callback, deps, comparator = basicDepsComparator, effectHook = useEffect, ...effectHookRestArgs) {
	const dependencies = useRef(void 0);
	if (dependencies.current === void 0 || isBrowser && !comparator(dependencies.current, deps)) dependencies.current = deps;
	effectHook(callback, dependencies.current, ...effectHookRestArgs);
}
//#endregion
//#region ../../node_modules/.pnpm/@react-hookz+web@25.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/@react-hookz/web/dist/useFirstMountState/index.js
/**
* Returns a boolean that is `true` only on first render.
*/
function useFirstMountState() {
	const isFirstMount = useRef(true);
	useEffect(() => {
		isFirstMount.current = false;
	}, []);
	return isFirstMount.current;
}
//#endregion
//#region ../../node_modules/.pnpm/@react-hookz+web@25.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/@react-hookz/web/dist/useIsomorphicLayoutEffect/index.js
/**
* Alias for `useLayoutEffect` in browser, but for `useEffect` at server side. Helps to avoid
* warning shown during SSR.
*/
var useIsomorphicLayoutEffect = isBrowser ? useLayoutEffect : useEffect;
//#endregion
//#region ../../node_modules/.pnpm/@react-hookz+web@25.3.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/@react-hookz/web/dist/useTimeoutEffect/index.js
var cancelTimeout = (id) => {
	if (id) clearTimeout(id);
};
/**
* Like `setTimeout` but in the form of a react hook.
*
* @param callback Callback to be called after the timeout. Changing this
* will not reset the timeout.
* @param ms Timeout delay in milliseconds. `undefined` disables the timeout.
* Keep in mind, that changing this parameter will re-set timeout, meaning
* that it will be set as new after the change.
*/
function useTimeoutEffect(callback, ms) {
	const cbRef = useSyncedRef(callback);
	const msRef = useSyncedRef(ms);
	const timeoutIdRef = useRef(null);
	const cancel = useCallback(() => {
		cancelTimeout(timeoutIdRef.current);
	}, []);
	const reset = useCallback(() => {
		if (msRef.current === void 0) return;
		cancel();
		timeoutIdRef.current = setTimeout(() => {
			cbRef.current();
		}, msRef.current);
	}, []);
	useEffect(() => {
		reset();
		return cancel;
	}, [ms]);
	return [cancel, reset];
}
//#endregion
//#region ../diagram/src/hooks/useUpdateEffect.ts
var noop = () => {};
var depsShallowEqual = (d1, d2) => {
	if (d1 === d2) return true;
	if (d1.length !== d2.length) return false;
	for (const [i, element] of d1.entries()) {
		if (element === d2[i] || shallowEqual(element, d2[i])) continue;
		return false;
	}
	return true;
};
function useUpdateEffect(callback, deps, equalityFn, effectHook) {
	useCustomCompareEffect(useFirstMountState() ? noop : callback, deps, equalityFn ?? depsShallowEqual, effectHook);
}
//#endregion
//#region ../../node_modules/.pnpm/@nanostores+react@2.0.1_nanostores@1.5.5_react@19.3.0/node_modules/@nanostores/react/index.js
var emit = (snapshotRef, onChange) => (value) => {
	if (snapshotRef.current === value) return;
	snapshotRef.current = value;
	onChange();
};
function useStore(store, { keys, deps = [store, keys], ssr } = {}) {
	let snapshotRef = useRef();
	snapshotRef.current = store.get();
	let subscribe = useCallback((onChange) => {
		emit(snapshotRef, onChange)(store.value);
		return keys?.length > 0 ? listenKeys(store, keys, emit(snapshotRef, onChange)) : store.listen(emit(snapshotRef, onChange));
	}, deps);
	let get = () => snapshotRef.current;
	let server = get;
	if (ssr && "init" in store) server = ssr === "initial" ? () => store.init : ssr;
	return useSyncExternalStore(subscribe, get, server);
}
//#endregion
//#region ../diagram/src/hooks/safeContext.tsx
var DiagramApiSafeContext = createContext(null);
DiagramApiSafeContext.displayName = "DiagramApiSafeContext";
var DiagramApiContextProvider = DiagramApiSafeContext.Provider;
function useDiagram() {
	const ctx = use(DiagramApiSafeContext);
	if (ctx === null) throw new Error("DiagramApi is not provided");
	return ctx;
}
/**
* Helper to create a safe context for an actor
* @example
* ```tsx
* const {
*   ContextProvider: MyActorContext,
*   useActorRef,
*   selectSnapshot,
*   useActorSelector
* } = createSafeContextForActor<MyActorRef>()
*
* const select = selectSnapshot(
*   s => ....,
*   (a, b) => a === b
* )
*
* // Later in component:
* const value = useActorSelector(select)
* ```
*/
function createSafeContextForActor(name) {
	const Ctx = createContext(null);
	function selectSnapshot(selector, compare) {
		return [selector, compare ?? shallowEqual];
	}
	function selectContext(selector, compare) {
		return [(snapshot) => selector(snapshot.context), compare ?? shallowEqual];
	}
	function useActorRef() {
		const actorRef = useContext(Ctx);
		if (actorRef === null) throw new Error(`${name}SafeContext is not provided `);
		return actorRef;
	}
	function useActorSelector(arg1, arg2) {
		let selector;
		let compare;
		if (arg2 !== void 0) [selector, compare] = [arg1, arg2];
		else if (Array.isArray(arg1)) [selector, compare] = arg1;
		else {
			selector = arg1;
			compare = shallowEqual;
		}
		compare ??= shallowEqual;
		invariant(e(selector), "selector must be a function");
		return useSelector(useActorRef(), selector, compare);
	}
	return {
		ContextProvider: Ctx.Provider,
		selectSnapshot,
		selectContext,
		useActorSelector,
		useActorRef
	};
}
var { ContextProvider: DiagramActorContextProvider, selectSnapshot: selectDiagramSnapshot, selectContext: selectDiagramContext, useActorSelector: useDiagramSelector, useActorRef: useDiagramActorRef } = createSafeContextForActor("DiagramActor");
//#endregion
//#region ../diagram/src/base-primitives/Markdown.tsx
var Markdown = forwardRef((t0, ref) => {
	const $ = c(34);
	let className;
	let fontSize;
	let props;
	let style;
	let t1;
	let t2;
	let t3;
	let t4;
	let value;
	if ($[0] !== t0) {
		({value, textScale: t1, uselikec4palette: t2, hideIfEmpty: t3, emptyText: t4, className, style, fontSize, ...props} = t0);
		$[0] = t0;
		$[1] = className;
		$[2] = fontSize;
		$[3] = props;
		$[4] = style;
		$[5] = t1;
		$[6] = t2;
		$[7] = t3;
		$[8] = t4;
		$[9] = value;
	} else {
		className = $[1];
		fontSize = $[2];
		props = $[3];
		style = $[4];
		t1 = $[5];
		t2 = $[6];
		t3 = $[7];
		t4 = $[8];
		value = $[9];
	}
	const textScale = t1 === void 0 ? 1 : t1;
	const uselikec4palette = t2 === void 0 ? false : t2;
	const hideIfEmpty = t3 === void 0 ? false : t3;
	const emptyText = t4 === void 0 ? "no content" : t4;
	if (value.isEmpty && hideIfEmpty) return null;
	let t5;
	if ($[10] !== emptyText || $[11] !== value.html || $[12] !== value.isMarkdown || $[13] !== value.nonEmpty || $[14] !== value.text) {
		t5 = value.nonEmpty ? value.isMarkdown ? { dangerouslySetInnerHTML: { __html: value.html } } : { children: /* @__PURE__ */ jsx("p", { children: value.text }) } : { children: /* @__PURE__ */ jsx(Text, {
			component: "span",
			fz: "xs",
			c: "dimmed",
			style: { userSelect: "none" },
			children: emptyText
		}) };
		$[10] = emptyText;
		$[11] = value.html;
		$[12] = value.isMarkdown;
		$[13] = value.nonEmpty;
		$[14] = value.text;
		$[15] = t5;
	} else t5 = $[15];
	const content = t5;
	let t6;
	if ($[16] !== className || $[17] !== uselikec4palette || $[18] !== value.isMarkdown) {
		t6 = cx(markdownBlock({
			uselikec4palette,
			value: value.isMarkdown ? "markdown" : "plaintext"
		}), className);
		$[16] = className;
		$[17] = uselikec4palette;
		$[18] = value.isMarkdown;
		$[19] = t6;
	} else t6 = $[19];
	let t7;
	if ($[20] !== fontSize) {
		t7 = fontSize && { "--text-fz": `var(--font-sizes-${fontSize}, var(--font-sizes-md))` };
		$[20] = fontSize;
		$[21] = t7;
	} else t7 = $[21];
	let t8;
	if ($[22] !== textScale) {
		t8 = textScale !== 1 && { "--mantine-scale": textScale };
		$[22] = textScale;
		$[23] = t8;
	} else t8 = $[23];
	let t9;
	if ($[24] !== style || $[25] !== t7 || $[26] !== t8) {
		t9 = {
			...style,
			...t7,
			...t8
		};
		$[24] = style;
		$[25] = t7;
		$[26] = t8;
		$[27] = t9;
	} else t9 = $[27];
	let t10;
	if ($[28] !== content || $[29] !== props || $[30] !== ref || $[31] !== t6 || $[32] !== t9) {
		t10 = /* @__PURE__ */ jsx(Box, {
			...props,
			ref,
			className: t6,
			style: t9,
			...content
		});
		$[28] = content;
		$[29] = props;
		$[30] = ref;
		$[31] = t6;
		$[32] = t9;
		$[33] = t10;
	} else t10 = $[33];
	return t10;
});
Markdown.displayName = "Markdown";
//#endregion
//#region src/context/safeCtx.ts
/**
* To improve experience with HMR, we move context to separate files and use as a boundary for hooks
*/
var LikeC4ModelDataContext = createContext(null);
var LikeC4ModelDataContextProvider = LikeC4ModelDataContext.Provider;
var useLikeC4ModelAtom = () => {
	const ctx = useContext(LikeC4ModelDataContext);
	if (ctx === null) throw new Error("LikeC4ModelAtom is not provided");
	return ctx;
};
//#endregion
//#region src/hooks.ts
function useTransparentBackground(t0) {
	const $ = c(3);
	const enabled = t0 === void 0 ? true : t0;
	let t1;
	let t2;
	if ($[0] !== enabled) {
		t1 = () => {
			const htmlEl = document.body.parentElement;
			if (!htmlEl || enabled !== true) return;
			htmlEl.classList.add("transparent-bg");
			return () => {
				htmlEl.classList.remove("transparent-bg");
			};
		};
		t2 = [enabled];
		$[0] = enabled;
		$[1] = t1;
		$[2] = t2;
	} else {
		t1 = $[1];
		t2 = $[2];
	}
	useIsomorphicLayoutEffect(t1, t2);
}
function useLikeC4Views() {
	const $ = c(4);
	const $likec4model = useLikeC4ModelAtom();
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = [];
		$[0] = t0;
	} else t0 = $[0];
	const [views, setViews] = useState(t0);
	let t1;
	let t2;
	if ($[1] !== $likec4model) {
		t1 = () => $likec4model.subscribe((next) => {
			setViews((prev) => {
				const nextViews = [...next.views()].map((v) => {
					const n = v.$layouted;
					const p = prev.find((_) => _.id === v.id);
					return !!p && deepEqual(n, p) ? p : n;
				});
				if (shallowEqual(prev, nextViews)) return prev;
				return nextViews;
			});
		});
		t2 = [$likec4model];
		$[1] = $likec4model;
		$[2] = t1;
		$[3] = t2;
	} else {
		t1 = $[2];
		t2 = $[3];
	}
	useEffect(t1, t2);
	return views;
}
function useCurrentViewId() {
	const $ = c(1);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = {
			select: _temp,
			strict: false
		};
		$[0] = t0;
	} else t0 = $[0];
	return useParams(t0) ?? "index";
}
function _temp(params) {
	return params.viewId;
}
/**
* Returns the current view and a function to set the layout type.
*/
function useCurrentView() {
	const $ = c(13);
	const viewId = useCurrentViewId();
	const $likec4model = useLikeC4ModelAtom();
	const [layoutType, setLayoutType] = useState("manual");
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = () => {
			setLayoutType("manual");
		};
		$[0] = t0;
	} else t0 = $[0];
	let t1;
	if ($[1] !== viewId) {
		t1 = [viewId];
		$[1] = viewId;
		$[2] = t1;
	} else t1 = $[2];
	useUpdateEffect(t0, t1);
	let t2;
	if ($[3] !== $likec4model || $[4] !== viewId) {
		t2 = () => $likec4model.get().findView(viewId)?.$layouted ?? null;
		$[3] = $likec4model;
		$[4] = viewId;
		$[5] = t2;
	} else t2 = $[5];
	const [view, setView] = useState(t2);
	let t3;
	let t4;
	if ($[6] !== $likec4model || $[7] !== layoutType || $[8] !== viewId) {
		t3 = () => $likec4model.subscribe((next, old) => {
			setView((current) => {
				const vm = next.findView(viewId);
				if (!vm) return current?.id === viewId ? current : null;
				const nextView = layoutType === "auto" ? vm.$view : vm.$layouted;
				if (deepEqual(current, nextView)) return current;
				return nextView;
			});
		});
		t4 = [
			$likec4model,
			viewId,
			layoutType
		];
		$[6] = $likec4model;
		$[7] = layoutType;
		$[8] = viewId;
		$[9] = t3;
		$[10] = t4;
	} else {
		t3 = $[9];
		t4 = $[10];
	}
	useEffect(t3, t4);
	let t5;
	if ($[11] !== view) {
		t5 = [view, setLayoutType];
		$[11] = view;
		$[12] = t5;
	} else t5 = $[12];
	return t5;
}
function useCurrentProject() {
	const $ = c(4);
	const projects = useLikeC4Projects();
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = {
			select: selectProjectIdFromContext,
			structuralSharing: false
		};
		$[0] = t0;
	} else t0 = $[0];
	const projectId = useMatches(t0);
	let t1;
	if ($[1] !== projectId || $[2] !== projects) {
		t1 = projectId && projects.find((p) => p.id === projectId) || projects[0];
		$[1] = projectId;
		$[2] = projects;
		$[3] = t1;
	} else t1 = $[3];
	return t1;
}
function selectProjectIdFromContext(matches) {
	return matches.find((m) => m.routeId === "/project/$projectId")?.params?.projectId ?? matches.at(-1)?.context.projectId ?? void 0;
}
//#endregion
export { r$1 as A, noop$1 as C, createReactComponent as D, IconSparkles as E, t$3 as F, e$2 as I, t$1 as M, r$3 as N, t as O, t$2 as P, isBrowser as S, IconPlayerStopFilled as T, useStore as _, useTransparentBackground as a, useTimeoutEffect as b, Markdown as c, createSafeContextForActor as d, selectDiagramContext as f, useDiagramSelector as g, useDiagramActorRef as h, useLikeC4Views as i, e$1 as j, e as k, DiagramActorContextProvider as l, useDiagram as m, useCurrentView as n, LikeC4ModelDataContextProvider as o, selectDiagramSnapshot as p, useCurrentViewId as r, useLikeC4ModelAtom as s, useCurrentProject as t, DiagramApiContextProvider as u, depsShallowEqual as v, useSyncedRef as w, useFirstMountState as x, useUpdateEffect as y };
